package com.preclaim.threads;

public class threadtest1 extends Thread {
	
	
	public void run() {
		
		for (int i=0; i<10; i++) {
			System.out.println("starts1  --" +i);
			try {
				System.out.println(1/0);
			} catch (Exception e) {
				System.out.println("handeled");
			}
		}
	}

}
