package com.preclaim.repository;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.preclaim.entity.Case_lists;

@Repository
public interface CaselistsPagingRepository extends JpaRepository<Case_lists, Long> {


	/*
	 * @Query(value = "\r\n" +
	 * "SELECT row_number() over (order by a.caseid) as ID ,\r\n" + "A.CASEID\r\n" +
	 * ",A.POLICYNUMBER\r\n" + ",A.NATURE_OF_INVESTIGATIONID\r\n" +
	 * ",A.ISSUEDDATE\r\n" + ",A.INSUREDMOB\r\n" + ",A.INSUREDNAME\r\n" +
	 * ",A.INSUREDDOD\r\n" + ",A.INSUREDDOB\r\n" + ",A.INSUREDDIAGNOSISDATE\r\n" +
	 * ",A.GENDER\r\n" + ",A.SUMASSURED\r\n" + ",A.INVESTIGATIONTYPE\r\n" +
	 * ",A.LOCATIONID\r\n" + ",A.PINCODE\r\n" + ",A.CASESTATUS\r\n" +
	 * ",A.CASESUBSTATUS\r\n" + ",A.NOTCLEANCATEGORY\r\n" + ",A.TRIGGER_NAME\r\n" +
	 * ",A.TRIGGER_DEPT\r\n" + ",A.DISPOSITION_NAME\r\n" + ",A.NOMINEE_NAME\r\n" +
	 * ",A.NOMINEE_CONTACTNUMBER\r\n" + ",A.NOMINEE_ADDRESS\r\n" +
	 * ",A.INSURED_ADDRESS\r\n" + ",A.CASE_DESCRIPTION\r\n" + ",A.LONGITUDE\r\n" +
	 * ",A.LATITUDE\r\n" + ",A.CREATEDBY\r\n" + ",A.CREATEDDATE\r\n" +
	 * ",A.UPDATEDDATE\r\n" + ",A.UPDATEDBY\r\n" +
	 * ",C.NATURE_OF_INVESTIGATIONTYPE AS NATURE_OF_INVESTIGATIONTYPE,\r\n" +
	 * "(select top 1(zone) from location_lists where locationId = a.locationId) as zone,\r\n"
	 * + "DATEDIFF(DAY,A.UPDATEDDATE,GETDATE()) AS TAT\r\n" +
	 * "FROM CASE_MOVEMENT B\r\n" +
	 * "INNER JOIN CASE_LISTS A ON B.CASEID = A.CASEID\r\n" +
	 * "LEFT JOIN NATURE_OF_INVESTIGATION C ON  A.NATURE_OF_INVESTIGATIONID = C.NATURE_OF_INVESTIGATIONID\r\n"
	 * + "WHERE \r\n" +
	 * "a.caseId not in (select CaseID from Bulk_Scheduler_Data  where flag !=2 and flag !=3) AND "
	 * + "A.CASEID = B.CASEID \r\n" + "AND A.CASESTATUS  <> 'Closed'\r\n" +
	 * "AND C.STATUS = 1", nativeQuery = true) Page<Case_lists> getCaselistsAdmin();
	 */
	@Query(value = "\r\n"
			+ "SELECT row_number() over (order by a.caseid) as ID ,\r\n"
			+ "A.CASEID\r\n"
			+ ",A.POLICYNUMBER\r\n"
			+ ",A.NATURE_OF_INVESTIGATIONID\r\n"
			+ ",A.ISSUEDDATE\r\n"
			+ ",A.INSUREDMOB\r\n"
			+ ",A.INSUREDNAME\r\n"
			+ ",A.INSUREDDOD\r\n"
			+ ",A.INSUREDDOB\r\n"
			+ ",A.INSUREDDIAGNOSISDATE\r\n"
			+ ",A.GENDER\r\n"
			+ ",A.SUMASSURED\r\n"
			+ ",A.INVESTIGATIONTYPE\r\n"
			+ ",A.LOCATIONID\r\n"
			+ ",A.PINCODE\r\n"
			+ ",A.CASESTATUS\r\n"
			+ ",A.CASESUBSTATUS\r\n"
			+ ",A.NOTCLEANCATEGORY\r\n"
			+ ",A.TRIGGER_NAME\r\n"
			+ ",A.TRIGGER_DEPT\r\n"
			+ ",A.DISPOSITION_NAME\r\n"
			+ ",A.NOMINEE_NAME\r\n"
			+ ",A.NOMINEE_CONTACTNUMBER\r\n"
			+ ",A.NOMINEE_ADDRESS\r\n"
			+ ",A.INSURED_ADDRESS\r\n"
			+ ",A.CASE_DESCRIPTION\r\n"
			+ ",A.LONGITUDE\r\n"
			+ ",A.LATITUDE\r\n"
			+ ",A.CREATEDBY\r\n"
			+ ",A.CREATEDDATE\r\n"
			+ ",A.UPDATEDDATE\r\n"
			+ ",A.UPDATEDBY\r\n"
			+ ",C.NATURE_OF_INVESTIGATIONTYPE AS NATURE_OF_INVESTIGATIONTYPE,\r\n"
			+ "(select top 1(zone) from location_lists where locationId = a.locationId) as zone,\r\n"
			+ "DATEDIFF(DAY,A.UPDATEDDATE,GETDATE()) AS TAT\r\n"
			+ "FROM CASE_MOVEMENT B\r\n"
			+ "INNER JOIN CASE_LISTS A ON B.CASEID = A.CASEID\r\n"
			+ "LEFT JOIN NATURE_OF_INVESTIGATION C ON  A.NATURE_OF_INVESTIGATIONID = C.NATURE_OF_INVESTIGATIONID\r\n"
			+ "WHERE \r\n"
			+ "a.caseId not in (select CaseID from Bulk_Scheduler_Data  where flag !=2 and flag !=3 and flag !=4) AND "
			+ "A.CASEID = B.CASEID \r\n"
			+ "AND A.CASESTATUS  <> 'Closed'\r\n"
			+ "AND C.STATUS = 1",
			countQuery = "SELECT count(a.caseId) FROM   case_movement b ,case_lists a"
					+ "	LEFT JOIN nature_of_investigation C on  a.nature_of_investigationId = c.nature_of_investigationId "
					+ "	where a.caseId not in (select CaseID from Bulk_Scheduler_Data  where flag !=2 and flag !=3 and flag !=4) AND "
						+ "A.CASEID = B.CASEID "
					+ "AND A.CASESTATUS  <> 'Closed'"
					+ "AND C.STATUS = 1", nativeQuery = true)
	Page<Case_lists> getCaselistsAdmin(Pageable page);
	
	

	@Query(value = "SELECT row_number() over (order by a.caseid) as ID , a.* , c.nature_of_investigationType as nature_of_investigationType "
			+ ",(select zone from location_lists where locationId = a.locationId) as zone"
			+ ", DATEDIFF(day,a.updatedDate,getDate()) AS TAT FROM   case_movement b , case_lists a"
			+ "  LEFT JOIN nature_of_investigation C on  a.nature_of_investigationId = c.nature_of_investigationId where "
			+ "a.caseId = b.caseId and a.caseStatus <> 'Closed' and c.status = 1  and (b.toId = :username  or "
			+ "(b.toRole = :user_role and b.zone = :zone and b.toId =''))  and a.caseId not in "
			+ "(select CaseID from Bulk_Scheduler_Data  where flag !=3 and flag !=2 and flag !=4)", 
			countQuery = "SELECT count(a.caseId)  FROM   case_movement b , case_lists a\r\n"
			+ "			  LEFT JOIN nature_of_investigation C on  a.nature_of_investigationId = c.nature_of_investigationId where \r\n"
			+ "			a.caseId = b.caseId and a.caseStatus <> 'Closed' and c.status = 1  and (b.toId = :username  or \r\n"
			+ "			(b.toRole = :user_role and b.zone = :zone and b.toId =''))  and a.caseId not in \r\n"
			+ "			(select CaseID from Bulk_Scheduler_Data  where flag !=3 and flag !=2 and flag !=4)"
			,nativeQuery = true)
	Page<Case_lists> getCaselistsRM(Pageable page,@Param("username") String username, @Param("user_role") String user_role,@Param("zone") String zone);
	// List<Case_lists> getCaselistsRM(@Param("username") String username,
	// @Param("zone") String zone);

	@Query(value = "SELECT row_number() over (order by a.caseid) as ID , a.* , c.nature_of_investigationType as nature_of_investigationType "
			+ ",(select zone from location_lists where locationId = a.locationId) as zone"
			+ ", DATEDIFF(day,a.updatedDate,getDate()) AS TAT FROM   case_movement b , case_lists a"
			+ "  LEFT JOIN nature_of_investigation C on  a.nature_of_investigationId = c.nature_of_investigationId "
			+ "where a.caseId = b.caseId and a.caseStatus <> 'Closed' and c.status = 1 and  b.toId = :username "
			+ "and a.caseId not in (select CaseID from Bulk_Scheduler_Data  where flag !=3 and flag !=2 and flag !=4)",
			countQuery = "SELECT count(a.caseId)  FROM   case_movement b , case_lists a\r\n"
			+ "			  LEFT JOIN nature_of_investigation C on  a.nature_of_investigationId = c.nature_of_investigationId \r\n"
			+ "			where a.caseId = b.caseId and a.caseStatus <> 'Closed' and c.status = 1 and  b.toId = :username \r\n"
			+ "			and a.caseId not in (select CaseID from Bulk_Scheduler_Data  where flag !=3 and flag !=2 and flag !=4)"
			,nativeQuery = true)
	Page<Case_lists> getCaselists(Pageable page ,@Param("username") String username);

}
