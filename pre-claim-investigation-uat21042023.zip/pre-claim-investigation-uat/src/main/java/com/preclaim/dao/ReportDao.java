package com.preclaim.dao;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.preclaim.auditdumpstring;
import com.preclaim.config.Config;
import com.preclaim.config.CustomMethods;
import com.preclaim.models.RegionwiseList;
import com.preclaim.models.TopInvestigatorList;
import com.preclaim.models.VendorwiseList;
@Component
public class ReportDao{

	@Autowired
	DataSource datasource;

	@Autowired
	JdbcTemplate template;
	
	@Autowired
	Config config;
	
	public void setTemplate(JdbcTemplate template) {
		this.template = template;
	}

	
	public List<String> getRegion() {
		try
		{
			String sql = "select DISTINCT state from location_lists";
			return template.query(sql, (ResultSet rs, int row) -> {
				return rs.getString("state");
			});
		}
		catch(Exception e)
		{
			e.printStackTrace();
			CustomMethods.logError(e);
			return null;
		}
	}

	
	public HashMap<String, String> getVendor() {
		try
		{
			String sql = "select * from admin_user where role_name = ?";
			return template.query(sql, new Object [] {config.getSUPERVISOR()}, (ResultSet rs, int row) -> 
			{
				HashMap<String, String> vendor = new HashMap<String, String>();
				vendor.put(rs.getString("username"), rs.getString("full_name"));
				while(rs.next())
					vendor.put(rs.getString("username"), rs.getString("full_name"));
				return vendor;
			}).get(0);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			CustomMethods.logError(e);
			return null;
		}
	}
	
	
	public List<String> getIntimationType() {
		try
		{
			String sql = "select * from investigation_type";
			return template.query(sql, (ResultSet rs, int row) -> {
				
				return rs.getString("investigationName");
			});
		}
		catch(Exception e)
		{
			e.printStackTrace();
			CustomMethods.logError(e);
			return null;
		}
	}

	public HashMap<String, Integer> getIntimationTypeList(String intimationType, String startDate, 
			String endDate) 
	{
		
		String sql = ""; 
		HashMap<String, Integer> intimationDetails = new HashMap<String, Integer>();
		if(intimationType.equals("All"))
		{
			sql = "SELECT investigationType, count(*) as grandTotal FROM case_lists "
				+ "WHERE CONVERT(date,createdDate) BETWEEN ? AND ? "
				+ "GROUP BY investigationType";
			try 
			{
				return template.query(sql, new Object[] {startDate, endDate} , 
						(ResultSet rs, int rowNum) -> {
							do
							{
								intimationDetails.put(rs.getString("investigationType"), 
										rs.getInt("grandTotal"));
							}while(rs.next());
							return intimationDetails;
						}).get(0);
			}
			catch(Exception e)
			{
				e.printStackTrace();
				return null;
			}
		}
		else
		{
			sql = "SELECT investigationType, count(*) as grandTotal FROM case_lists "
					+ "WHERE investigationType = ? and CONVERT(date,createdDate) BETWEEN ? AND ? "
					+ "GROUP BY investigationType";
			try
			{
				return template.query(sql, new Object[] {intimationType, startDate, endDate} , 
						(ResultSet rs, int rowNum) -> {
							do
							{
								intimationDetails.put(rs.getString("investigationType"), 
										rs.getInt("grandTotal"));
							}while(rs.next());
							return intimationDetails;
						}).get(0);
			}
			catch(Exception e)
			{
				return null;
			}
		}
	}

	
	public List<TopInvestigatorList> getTopInvestigatorList(String startDate, String endDate) {
		
		String user_lists = "";
		// Main Query - Query to get Top 15 Investigators
		List<String> investigator_list = new ArrayList<String>();
		/*
		1) Get Latest record from audit_case_movement whose role = "AGNSUP"
		2) Join the above query with case_lists where caseSubStatus is Clean , Not-Clean
		3) Get Investigator wise Total Count
		*/
		String sql = 
				"SELECT TOP 15 b.toId, count(*) as grandTotal FROM case_lists a, "
				+ "(select a.caseId, a.toId, a.updatedDate FROM audit_case_movement a, "
				+ "(select caseId,  max(updatedDate) as updatedDate FROM audit_case_movement WHERE toRole = ? "
				+ "group by  caseId ) b WHERE a.caseId = b.caseId and a.toRole = ? and a.updatedDate = b.updatedDate "
				+ ") b where a.caseId = b.caseId AND a.caseSubStatus IN ('Clean','Not-Clean') "
				+ "and CONVERT(date,b.updatedDate) BETWEEN ? AND ? "
				+ "GROUP BY b.toId "
				+ "ORDER BY count(*) desc";
				
		/* System.out.println(sql); */
		
		try
		{
			user_lists = template.query(sql, new Object[] {config.getSUPERVISOR(), config.getSUPERVISOR(), 
					startDate, endDate},
					(ResultSet rs, int rowNum) -> 
					{
						String userId = "";
						do 
						{
							investigator_list.add(rs.getString("toId"));
							userId +=  "'" + rs.getString("toId") + "',";
						}
						while(rs.next());			
						return userId;
						
					}).get(0);
		}
		catch(Exception e)
		{
			return null;
		}
		user_lists = user_lists.substring(0, user_lists.length() - 1);
		/* System.out.println(user_lists); */
		
		//Query 2 - Query to categorize Clean, Not Clean 
		
		HashMap<String, Integer> clean = new HashMap<String, Integer>();
		HashMap<String, Integer> notClean = new HashMap<String, Integer>();
		
		sql = 
				"SELECT TOP 15 b.toId, a.caseSubStatus, count(*) as substatusTotal FROM case_lists a, "
				+ "(select a.caseId, a.toId, a.updatedDate FROM audit_case_movement a, "
				+ "(select caseId,  max(updatedDate) as updatedDate FROM audit_case_movement WHERE toRole = ? "
				+ "group by  caseId ) b WHERE a.caseId = b.caseId and a.toRole = ? and a.updatedDate = b.updatedDate "
				+ ") b where a.caseId = b.caseId AND a.caseSubStatus IN ('Clean','Not-Clean') "
				+ "and CONVERT(date,b.updatedDate) BETWEEN ? AND ? "
				+ "GROUP BY b.toId, a.caseSubStatus "
				+ "ORDER BY count(*) desc";
		
		template.query(sql, new Object[] {config.getSUPERVISOR(), config.getSUPERVISOR(), startDate, endDate},
			(ResultSet rs, int rowNum) -> {
			do 
			{
				if(rs.getString("caseSubStatus").equals("Clean"))
					clean.put(rs.getString("toId"),rs.getInt("substatusTotal"));
				
				else if(rs.getString("caseSubStatus").equals("Not-Clean"))
					notClean.put(rs.getString("toId"),rs.getInt("substatusTotal"));
			}while(rs.next());
			
			return "";
		});

		//Query 3 - Query to map username & fullname 
		
		HashMap<String, String> user_mapping = new HashMap<String, String>();
		sql = "SELECT * FROM admin_user b where username in ( " + user_lists +  ")";
		template.query(sql , (ResultSet rs, int rowNum) -> {
			do
			{
				user_mapping.put(rs.getString("username"),rs.getString("full_name"));
			}while(rs.next());
			return user_mapping;
		});
		List<TopInvestigatorList> investigator = new ArrayList<TopInvestigatorList>();
		int cleanCount = 0;
		int NotCleanCount = 0;
		int totalCleanCount = 0;
		int totalNotCleanCount = 0;
		for(String user: investigator_list)
		{
			cleanCount = clean.get(user) == null ? 0 : clean.get(user);
			NotCleanCount = notClean.get(user) == null ? 0 : notClean.get(user);
			investigator.add(new TopInvestigatorList(user_mapping.get(user), cleanCount, NotCleanCount));
			totalCleanCount += cleanCount; 
			totalNotCleanCount += NotCleanCount;
		}
		investigator.add(new TopInvestigatorList("Total", totalCleanCount, totalNotCleanCount));
		
		return investigator;
	}
	
	
	public List<RegionwiseList> getRegionwiseList(String region, String startDate, String endDate) {
		System.out.println("config"+config.getSUPERVISOR());
		String user_lists = "";
		List<String> investigator_list = new ArrayList<String>();
		String sql =
				"select b.toId, count(*) as grandTotal from case_lists a, "
				+ "(select a.caseId, a.toId, a.updatedDate from audit_case_movement a, "
				+ "(select caseId,  max(updatedDate) as updatedDate from audit_case_movement where toRole = ? "
				+ "group by  caseId ) b where a.caseId = b.caseId and a.toRole = ? and a.updatedDate = b.updatedDate "
				+ ") b where a.caseId = b.caseId and a.caseStatus IN ('Closed','WIP') and  "
				+ "b.toId IN (SELECT username from admin_user where state = ?) "
				+ "and CONVERT(date,b.updatedDate) BETWEEN ? AND ? "
				+ "group by b.toId "
				+ "order by count(*) desc";
				
		/* System.out.println(sql); */
		try
		{
			user_lists = template.query(sql, new Object[] {config.getSUPERVISOR(), config.getSUPERVISOR(), 
					region, startDate, endDate}, 
					(ResultSet rs, int rowNum) -> 
					{
						String userId = "";
						do 
						{
							investigator_list.add(rs.getString("toId"));
							userId +=  "'" + rs.getString("toId") + "',";
						}
						while(rs.next());			
						return userId;
						
					}).get(0);
		}
		catch(Exception e)
		{
			return null;
		}
		user_lists = user_lists.substring(0, user_lists.length() - 1);
		/* System.out.println(user_lists); */
		
		HashMap<String, Integer> clean = new HashMap<String, Integer>();
		HashMap<String, Integer> notClean = new HashMap<String, Integer>();
		HashMap<String, Integer> pivstopped = new HashMap<String, Integer>();
		HashMap<String, Integer> wip = new HashMap<String, Integer>();
		
		sql =
				"select b.toId,  a.caseSubStatus , count(*) as substatusTotal from case_lists a, "
				+ "(select a.caseId, a.toId, a.updatedDate from audit_case_movement a, "
				+ "(select caseId,  max(updatedDate) as updatedDate from audit_case_movement where toRole = ? "
				+ "group by  caseId ) b where a.caseId = b.caseId and a.toRole = ? and a.updatedDate = b.updatedDate "
				+ ") b where a.caseId = b.caseId and a.caseStatus = 'Closed' and  "
				+ "b.toId IN (SELECT username from admin_user where state = ?) "
				+ "and CONVERT(date,b.updatedDate) BETWEEN ? AND ? "
				+ "group by b.toId, a.caseSubStatus "
				+ "order by count(*) desc";
		
		/* System.out.println(sql); */
		
		template.query(sql,new Object[] {config.getSUPERVISOR(), config.getSUPERVISOR(), region, startDate, endDate},
			(ResultSet rs, int rowNum) -> {
			do 
			{
				if(rs.getString("caseSubStatus").equals("Clean"))
					clean.put(rs.getString("toId"),rs.getInt("substatusTotal"));
				
				else if(rs.getString("caseSubStatus").equals("Not-Clean"))
					notClean.put(rs.getString("toId"),rs.getInt("substatusTotal"));
				
				else if(rs.getString("caseSubStatus").equals("PIV Stopped"))
					pivstopped.put(rs.getString("toId"),rs.getInt("substatusTotal"));
			}while(rs.next());
			
			return "";
		});
		
		sql =
				"select b.toId as toid,  a.caseSubStatus , count(*) as substatusTotal from case_lists a, "
				+ "(select a.caseId, a.toId, a.updatedDate from audit_case_movement a, "
				+ "(select caseId,  max(updatedDate) as updatedDate from audit_case_movement where toRole = ? "
				+ "group by  caseId ) b where a.caseId = b.caseId and a.toRole = ? and a.updatedDate = b.updatedDate "
				+ ") b where a.caseId = b.caseId and a.caseStatus = 'WIP' and  "
				+ "b.toId IN (SELECT username from admin_user where state = ?) "
				+ "and CONVERT(date,b.updatedDate) BETWEEN ? AND ? "
				+ "group by b.toId, a.caseSubStatus "
				+ "order by count(*) desc";
		
		template.query(sql,new Object[] {config.getSUPERVISOR(), config.getSUPERVISOR(), region, startDate, endDate},
			(ResultSet rs, int rowNum) -> {
			do 
			{
				wip.put(rs.getString("toid"),rs.getInt("substatusTotal"));
			}while(rs.next());
			
			return "";
		});
		
		HashMap<String, String> user_mapping = new HashMap<String, String>();
		sql = "SELECT * FROM admin_user b where username in ( " + user_lists +  ")";
		template.query(sql , (ResultSet rs, int rowNum) -> {
			do
			{
				user_mapping.put(rs.getString("username"),rs.getString("full_name"));
			}while(rs.next());
			return user_mapping;
		});
		List<RegionwiseList> regionwise = new ArrayList<RegionwiseList>();
		for(String user: investigator_list)
		{
			regionwise.add(new RegionwiseList(user_mapping.get(user),
					clean.get(user) == null ? 0 : clean.get(user),
					notClean.get(user) == null ? 0 : notClean.get(user),
					pivstopped.get(user) == null ? 0 : pivstopped.get(user),
					wip.get(user) == null ? 0 : wip.get(user)));
		}
		
		return regionwise;
	}

	
	public List<VendorwiseList> getVendorwistList(String vendorName, String startDate, String endDate) {
		
		List<String> monthwise = new ArrayList<String>();
		String sql = "SELECT a.toId, FORMAT(a.updatedDate,'MMM') + '-' + FORMAT(a.updatedDate,'yy') as Month, count(*) as total FROM audit_case_movement a, ("
				+ "SELECT caseId, max(updatedDate) as updatedDate FROM audit_case_movement "
				+ "WHERE caseid in (SELECT caseid FROM case_lists WHERE caseSubStatus IN ('Clean','Not-Clean')) "
				+ "and toRole = ? "
				+ "group by caseId) b "
				+ "where a.caseId = b.caseId and a.updatedDate = b.updatedDate and a.toId = ? and "
				+ "CONVERT(date, a.updatedDate) BETWEEN ? and ? "
				+ "group by a.toId, YEAR(a.updatedDate), FORMAT(a.updatedDate,'MMM') + '-' + FORMAT(a.updatedDate,'yy')";
		try
		{
			template.query(sql, new Object[] {config.getSUPERVISOR(), vendorName, startDate, endDate},
					(ResultSet rs, int rowNum) -> {
						do
						{
							monthwise.add(rs.getString("Month"));
						}while(rs.next());
					return monthwise;
					});
		}
		catch(Exception e)
		{
			e.printStackTrace();
			return null;
		}
		HashMap<String, Integer> clean = new HashMap<String, Integer>();
		HashMap<String, Integer> notClean = new HashMap<String, Integer>();
		
		sql = "SELECT a.toId, FORMAT(a.updatedDate,'MMM') + '-' + FORMAT(a.updatedDate,'yy') as Month, count(*) as cleanCount FROM audit_case_movement a, ("
				+ "SELECT caseId, max(updatedDate) as updatedDate FROM audit_case_movement "
				+ "WHERE caseid in (SELECT caseid FROM case_lists WHERE caseSubStatus = 'Clean') "
				+ "and toRole = ? "
				+ "group by caseId) b "
				+ "where a.caseId = b.caseId and a.updatedDate = b.updatedDate and a.toId = ? and "
				+ "CONVERT(date, a.updatedDate) BETWEEN ? and ? "
				+ "group by a.toId, YEAR(a.updatedDate), FORMAT(a.updatedDate,'MMM') + '-' + FORMAT(a.updatedDate,'yy')";
		
		template.query(sql, new Object[] {config.getSUPERVISOR(), vendorName, startDate, endDate}, 
				(ResultSet rs, int rowNum) -> {
					do
					{
						clean.put(rs.getString("Month"), rs.getInt("cleanCount"));
					}while(rs.next());
					return clean;
				});
		
		sql = "SELECT a.toId, FORMAT(a.updatedDate,'MMM') + '-' + FORMAT(a.updatedDate,'yy') as Month, count(*) as notCleanCount FROM audit_case_movement a, ("
				+ "SELECT caseId, max(updatedDate) as updatedDate FROM audit_case_movement "
				+ "WHERE caseid in (SELECT caseid FROM case_lists WHERE caseSubStatus = 'Not-Clean') "
				+ "and toRole = ? "
				+ "group by caseId) b "
				+ "where a.caseId = b.caseId and a.updatedDate = b.updatedDate and a.toId = ? and "
				+ "CONVERT(date, a.updatedDate) BETWEEN ? and ? "
				+ "group by a.toId, YEAR(a.updatedDate), FORMAT(a.updatedDate,'MMM') + '-' + FORMAT(a.updatedDate,'yy')";
		
		template.query(sql, new Object[] {config.getSUPERVISOR(), vendorName, startDate, endDate}, 
				(ResultSet rs, int rowNum) -> {
					do
					{
						notClean.put(rs.getString("Month"), rs.getInt("notCleanCount"));
					}while(rs.next());
					return clean;
				});
		
		List<VendorwiseList> vendorlist = new ArrayList<VendorwiseList>();
		for(String month: monthwise)
		{
			vendorlist.add(new VendorwiseList(month, 
					clean.get(month) == null ? 0: clean.get(month), 
					notClean.get(month) == null ? 0: notClean.get(month)));
		}	
		return vendorlist;
	}	
	
	public Map<Integer, Object[]> dumpReport(String startDate,String endDate) 
	{
		Map<Integer, Object[]> reportData = new HashMap<Integer, Object[]>();
		reportData.put(0, new Object[] {
				"Sr No", 
				"Case ID", 
				"Policy Number", 
				"Nature Of Investigation",
				"City",
				"State",
				"Zone",
				"Issued Date",
				"Insured Mobile Number",
				"Insured Name", 
				"Insured DOD", 
				"Insured DOB",
				"Insured Diagnosis Date",
				"Gender",
				"Sum Assured",
				"Investigation Type",
				"Pincode",
				"Case Status",
				"Case Sub Status",
				"Not Clean Category",
				"Trigger Name",
				"Trigger Department",
				"Disposition Name",
				"Nominee Name",
				"Nominee Contact Number",
				"Nominee Address",
				"Insured Address", 
				"Case Description",
				"Longitude", 
				"Latitude",
				"Created By",
				"Created Date", 
				"Updated Date",
				"TAT",
				"Updated By",
				"Regional Manager",
				"rm_alloted_Date" ,
				"RCU Remarks",
				"Agency Supervisor",
				"agency_alloted_Date",
				"regional_man_remarks",
				"investigator_mobile_number",
				"Investigator",
				"inv_alloted_date",
				"agn_sup_remarks",
				"Invtoagency_supervisor",
				"Invtoagency_alloted_Date",
				"Invtoagency_remarks",
				"Underwriter",
				"uw_alloted_date",
				"reg_man_remarks",
				"talic/claim",
				"talic/claim_alloted_date",
				"uw_remarks",
				"claim_remarks",
				"Inv Report_date",
				"as_Report_date",
	       		"uw_Report_date",
	       		"talic/clamim_Report_date"
				});
       
		
		String sql = "select main.*, (select city from location_lists where locationId = main.locationId) city,   \n" + 
				"												(select state from location_lists where locationId = main.locationId) state,   \n" + 
				"												(select zone from location_lists where locationId = main.locationId) zone,   \n" + 
				"												(select nature_of_investigationType from nature_of_investigation where nature_of_investigationId = main.nature_of_investigationId) as nature_of_investigation,   \n" + 
				"												ISNULL((select full_name from admin_user where username =  ISNULL(agnsup.fromId,'')),'') as regional_manager,    												 \n" + 
				"												ISNULL(regman.updatedDate,'') as rm_alloted_date,    \n" + 
				"												ISNULL(regman.remarks,'') as RCU_Remarks,    \n" + 
				"												case main.casestatus    \n" + 
				"												when 'Closed' then DATEDIFF(day,main.createdDate,main.updatedDate)    \n" + 
				"												else  DATEDIFF(day,main.updatedDate,getdate())   \n" + 
				"												end as TAT,   \n" + 
				"												ISNULL((select full_name from admin_user where username = ISNULL(agnsup.toId,'')),'') as agency_supervisor,    \n" + 
				"												ISNULL(agnsup.updatedDate,'') as agency_alloted_date,    \n" + 
				"												ISNULL(agnsup.remarks,'') as regional_man_remarks,    \n" + 
				"												ISNULL((select mobile_number from admin_user where username = ISNULL(inv.toId,'')),'') as investigator_mobile_number,    \n" + 
				"												ISNULL((select full_name from admin_user where username = ISNULL(inv.toId,'')),'') as investigator,    \n" + 
				"												ISNULL(inv.updatedDate,'') as inv_alloted_date,    \n" + 
				"												ISNULL(inv.remarks,'') as agn_sup_remarks,    \n" + 
				"												ISNULL((select full_name from admin_user where username = ISNULL(agnsuptorm.toId,'')),'') as Invtoagency_supervisor,    \n" + 
				"												ISNULL(agnsuptorm.updatedDate,'') as Invtoagency_alloted_date,    \n" + 
				"												ISNULL(agnsuptorm.remarks,'') as Invtoagency_remarks,    \n" + 
				"												ISNULL((select full_name from admin_user where username = ISNULL(uw.toId,'')),'') as underwriter,  \n" + 
				"												ISNULL(uw.updatedDate,'') as uw_alloted_date,    \n" + 
				"												ISNULL(uw.remarks,'') as regional_man_remarks, 				   \n" + 
				"												ISNULL((select full_name from admin_user where username = ISNULL(talicman.toId,'')),'') as talic,    \n" + 
				"												ISNULL(talicman.updatedDate,'') as talic_alloted_date,   \n" + 
				"												ISNULL(talicman.remarks,'') as uw_remarks, \n" + 
				"												ISNULL(claimman.remarks,'') as claim_remarks, \n" + 
				"												ISNULL(agnsuptorm.updatedDate,'') as Invtoagency_Report_date,  \n" + 
				"												ISNULL(regman2.updatedDate,'') as asTorm_Report_date, \n" + 
				"												ISNULL(uwreport.updatedDate,'') as uwTotalicman_Report_date, \n" + 
				"												ISNULL(talicrmreport.updatedDate,'') as talicman_Report_date \n" + 
				"												from case_lists main 			   \n" + 
				"												left outer join    \n" + 
				"												(select x.* from audit_case_movement x,    \n" + 
				"												(select caseId , min(updatedDate) as updatedDate from audit_case_movement where toRole = 'AGNSUP'   \n" + 
				"												group by caseId) y   \n" + 
				"												where x.caseId = y.caseId and x.toRole = 'AGNSUP' and x.updatedDate = y.updatedDate ) agnsup   \n" + 
				"												on main.caseId = agnsup.caseId 	   \n" + 
				"												left outer join    \n" + 
				"												(select x.* from audit_case_movement x,    \n" + 
				"												(select caseId , min(updatedDate) as updatedDate from audit_case_movement where toRole = 'REGMAN'   \n" + 
				"												group by caseId) y   \n" + 
				"												where x.caseId = y.caseId and x.toRole = 'REGMAN' and x.updatedDate = y.updatedDate ) regman   \n" + 
				"												on main.caseId = regman.caseId   \n" + 
				"												left outer join    \n" + 
				"												(select x.* from audit_case_movement x,    \n" + 
				"												(select caseId , min(updatedDate) as updatedDate from audit_case_movement where toRole = 'UW'   \n" + 
				"												group by caseId) y   \n" + 
				"												where x.caseId = y.caseId and x.toRole = 'UW' and x.updatedDate = y.updatedDate ) uw   \n" + 
				"												on main.caseId = uw.caseId  \n" + 
				"												left outer join    \n" + 
				"												(select x.* from audit_case_movement x,    \n" + 
				"												(select caseId , min(updatedDate) as updatedDate from audit_case_movement where toRole = 'INV'   \n" + 
				"												group by caseId) y   \n" + 
				"												where x.caseId = y.caseId and x.toRole = 'INV' and x.updatedDate = y.updatedDate ) inv   \n" + 
				"												on main.caseId = inv.caseId     \n" + 
				"												left outer join    \n" + 
				"												(select x.* from audit_case_movement x,    \n" + 
				"												(select caseId , min(updatedDate) as updatedDate from audit_case_movement where toRole = 'CLAMAN'   \n" + 
				"												group by caseId) y   \n" + 
				"												where x.caseId = y.caseId and x.toRole = 'CLAIMS' and x.updatedDate = y.updatedDate ) claims   \n" + 
				"												on main.caseId = claims.caseId  \n" + 
				"												left outer join    \n" + 
				"												(select x.* from audit_case_movement x,    \n" + 
				"												(select caseId , min(updatedDate) as updatedDate from audit_case_movement where toRole in( 'TALICMAN')   \n" + 
				"												group by caseId) y   \n" + 
				"												where x.caseId = y.caseId and x.toRole in( 'TALICMAN')   and x.updatedDate = y.updatedDate ) talicman   \n" + 
				"												on main.caseId = talicman.caseId\n" + 
				"												left outer join    \n" + 
				"												(select x.* from audit_case_movement x,    \n" + 
				"												(select caseId , max(updatedDate) as updatedDate from audit_case_movement where toRole='AGNSUP' and \n" + 
				"												fromId in(select username from admin_user where role_name in ('INV')) \n" + 
				"												group by caseId) y   \n" + 
				"												where x.caseId = y.caseId  and x.updatedDate = y.updatedDate) agnsuptorm   \n" + 
				"												on main.caseId = agnsuptorm.caseId 	\n" + 
				"												left outer join    \n" + 
				"												(select x.* from audit_case_movement x,    \n" + 
				"												(select caseId , max(updatedDate) as updatedDate from audit_case_movement where toRole in( 'CLAMAN','REGMAN')and\n" + 
				"												fromId in(select username from admin_user where role_name in ('AGNSUP' ))   \n" + 
				"												group by caseId) y   \n" + 
				"												where x.caseId = y.caseId  and x.updatedDate = y.updatedDate ) regman2   \n" + 
				"												on main.caseId = regman2.caseId \n" + 
				"												left outer join    \n" + 
				"												(select x.* from audit_case_movement x,    \n" + 
				"												(select caseId , max(updatedDate) as updatedDate from audit_case_movement where \n" + 
				"												fromId in(select username from admin_user where role_name in ('UW'))   \n" + 
				"												group by caseId) y   \n" + 
				"												where x.caseId = y.caseId  and x.updatedDate = y.updatedDate ) uwreport  \n" + 
				"												on main.caseId = uwreport.caseId \n" + 
				"												left outer join    \n" + 
				"												(select x.* from audit_case_movement x,    \n" + 
				"												(select caseId , min(updatedDate) as updatedDate from audit_case_movement where toId ='' and\n" + 
				"												fromId in(select username from admin_user where role_name in( 'TALICMAN','CLAMAN'))   \n" + 
				"												group by caseId) y   \n" + 
				"												where x.caseId = y.caseId and x.updatedDate = y.updatedDate) talicrmreport   \n" + 
				"												on main.caseId = talicrmreport.caseId \n" + 
				"												left outer join     \n" + 
				"												(select x.* from audit_case_movement x,     \n" + 
				"												(select caseId , min(updatedDate) as updatedDate from audit_case_movement where toRole in( 'CLAMAN')    \n" + 
				"												group by caseId) y    \n" + 
				"												where x.caseId = y.caseId and x.toRole in('CLAMAN')   and x.updatedDate = y.updatedDate ) claimman    \n" + 
				"												on main.caseId = claimman.caseId \n" + 
				"												where \n" + 
				"												CONVERT(date, main.createdDate) BETWEEN ? and ? ";
		
		
		template.query(sql, new Object[] {startDate, endDate},(ResultSet rs, int rowNum) -> {
			reportData.put(rowNum+1, new Object[] {
					rowNum + 1,
					rs.getInt("caseId"),
					rs.getString("policyNumber"),
					rs.getString("nature_of_investigation"),
					rs.getString("city"),
					rs.getString("state"),
					rs.getString("zone"),
					rs.getString("issuedDate"),
					rs.getString("insuredMob"),
					rs.getString("insuredName"),
					rs.getString("insuredDOD"),
					rs.getString("insuredDOB"),
					rs.getString("insuredDiagnosisDate"),
					rs.getString("gender"),
					rs.getString("sumAssured"),
					rs.getString("investigationType"),
					rs.getString("pincode"),
					rs.getString("caseStatus"),
					rs.getString("caseSubStatus"),
					rs.getString("notCleanCategory"),
					rs.getString("trigger_name"),
					rs.getString("trigger_dept"),
		       		rs.getString("disposition_name"),
		       		rs.getString("nominee_Name"),
		       		rs.getString("nominee_ContactNumber"),
		       		rs.getString("nominee_address"),
		       		rs.getString("insured_address"),
		       		rs.getString("case_description"),
		       		rs.getString("longitude"),
		       		rs.getString("latitude"),
		       		rs.getString("createdBy"),
		       		rs.getString("createdDate"),
		       		rs.getString("updatedDate"),
		       		rs.getString("TAT"),
		       		rs.getString("updatedBy"),
		       		rs.getString("regional_manager"),
		       		rs.getString("rm_alloted_date"),
		       		rs.getString("RCU_Remarks"),
		       		rs.getString("agency_supervisor"),
		       		rs.getString("agency_alloted_date"),
		       		rs.getString("regional_man_remarks"),
		       		rs.getString("investigator_mobile_number"),
		       		rs.getString("investigator"),
		       		rs.getString("inv_alloted_date"),
		       		rs.getString("agn_sup_remarks"),
		       		rs.getString("Invtoagency_supervisor"),
		       		rs.getString("Invtoagency_alloted_Date"),
		       		rs.getString("Invtoagency_remarks"),
		       		rs.getString("underwriter"),
		       		rs.getString("uw_alloted_date"),
		       		rs.getString("regional_man_remarks"),
		       		rs.getString("talic"),
		       		rs.getString("talic_alloted_date"),
		       		rs.getString("uw_remarks"),
		       		rs.getString("claim_remarks"),
		       		rs.getString("Invtoagency_Report_date"),
		       		rs.getString("asTorm_Report_date"),
		       		rs.getString("uwTotalicman_Report_date"),
		       		rs.getString("talicman_Report_date")
		       		
			});			
			  return null;
		});

	return reportData;
	}
	
	public Map<Integer, Object[]> dumpReportupdate(String startDate,String endDate) 
	{
		Map<Integer, Object[]> reportData = new HashMap<Integer, Object[]>();
		reportData.put(0, new Object[] {
				"Sr No", 
				"Case ID", 
				"Policy Number", 
				"Nature Of Investigation",
				"City",
				"State",
				"Zone",
				"Issued Date",
				"Insured Mobile Number",
				"Insured Name", 
				"Insured DOD", 
				"Insured DOB",
				"Insured Diagnosis Date",
				"Gender",
				"Sum Assured",
				"Investigation Type",
				"Pincode",
				"Case Status",
				"Case Sub Status",
				"Not Clean Category",
				"Trigger Name",
				"Trigger Department",
				"Disposition Name",
				"Nominee Name",
				"Nominee Contact Number",
				"Nominee Address",
				"Insured Address", 
				"Case Description",
				"Longitude", 
				"Latitude",
				"Created By",
				"Created Date", 
				"Updated Date",
				"Updated By",
				"From Mobile Number",
				"From User",
				"To User",
				"To Role",
				"Remarks",
				"Allocated Date",
				"Approved Date",
				"TAT",
				"Fees",
				"Payment status"
				});
       
		
		String sql = "select a.*,\n" + 
				"(select city from location_lists where locationId = a.locationId) city,\n" + 
				"(select state from location_lists where locationId = a.locationId) state,  \n" + 
				"(select zone from location_lists where locationId = a.locationId) zone,  \n" + 
				"(select nature_of_investigationType from nature_of_investigation where nature_of_investigationId = a.nature_of_investigationId) as nature_of_investigation,  \n" + 
				"ISNULL((select mobile_number from admin_user where username = ISNULL(b.fromId,'')),'') as mobile_number,  \n" + 
				"ISNULL((select full_name  from admin_user where username = b.fromId),'') as fromId,\n" + 
				"ISNULL((select full_name from admin_user where username = b.toId),'') as toId,   \n" + 
				"b.toRole,\n" + 
				"b.caseStatus,\n" + 
				"b.remarks,\n" + 
				"b.createdDate,\n" + 
				"Lag(b.updatedDate, 1,b.createdDate) OVER(PARTition by a.caseId ORDER BY b.updatedDate ASC) as allocated_date,\n" + 
				"b.updatedDate as approved_date,\n" + 
				"DATEDIFF(day,Lag(b.updatedDate, 1,b.createdDate) OVER(PARTition by a.caseId ORDER BY b.updatedDate ASC), b.updatedDate) as TAT,\n" + 
				"ISNULL((select fees from admin_user x left outer join user_fees y on x.username = y.username\n" + 
				"where x.username = b.toId and y.investigationType = a.investigationType and fromId in(select username from admin_user where role_name ='REGMAN') and x.role_name ='AGNSUP'),0) as fees ,\n" + 
				"case ISNULL((select fees from admin_user x left outer join user_fees y on x.username = y.username\n" + 
				"where x.username = b.toId and y.investigationType = a.investigationType and fromId in(select username from admin_user where role_name ='REGMAN') and x.role_name ='AGNSUP'\n" + 
				"and a.caseStatus = 'Closed'\n" + 
				"and a.caseId  in (select caseId from case_payment where userId = b.toId)\n" + 
				"),0)\n" + 
				"when 0.00 then ' ' else 'Y'  end as status\n" + 
				"from case_lists a\n" + 
				"left outer join\n" + 
				"audit_case_movement b on a.caseId = b.caseId \n" + 
				"where a.caseId=b.caseId and CONVERT(date, a.createdDate) BETWEEN ? and ? order by b.updatedDate\n" + 
				 
				"";
		
		
		template.query(sql, new Object[] {startDate, endDate},(ResultSet rs, int rowNum) -> {
			reportData.put(rowNum+1, new Object[] {
					rowNum + 1,
					rs.getInt("caseId"),
					rs.getString("policyNumber"),
					rs.getString("nature_of_investigation"),
					rs.getString("city"),
					rs.getString("state"),
					rs.getString("zone"),
					rs.getString("issuedDate"),
					rs.getString("insuredMob"),
					rs.getString("insuredName"),
					rs.getString("insuredDOD"),
					rs.getString("insuredDOB"),
					rs.getString("insuredDiagnosisDate"),
					rs.getString("gender"),
					rs.getString("sumAssured"),
					rs.getString("investigationType"),
					rs.getString("pincode"),
					rs.getString("caseStatus"),
					rs.getString("caseSubStatus"),
					rs.getString("notCleanCategory"),
					rs.getString("trigger_name"),
					rs.getString("trigger_dept"),
		       		rs.getString("disposition_name"),
		       		rs.getString("nominee_Name"),
		       		rs.getString("nominee_ContactNumber"),
		       		rs.getString("nominee_address"),
		       		rs.getString("insured_address"),
		       		rs.getString("case_description"),
		       		rs.getString("longitude"),
		       		rs.getString("latitude"),
		       		rs.getString("createdBy"),
		       		rs.getString("createdDate"),
		       		rs.getString("updatedDate"),
		       		rs.getString("updatedBy"),
		       		rs.getString("mobile_number"),
		       		rs.getString("fromId"),
		       		rs.getString("toId"),
		       		rs.getString("toRole"),
		       		rs.getString("remarks"),
		       		rs.getString("allocated_date"),
		       		rs.getString("approved_date"),
		       		rs.getString("TAT"),
		       		rs.getString("fees"),
		       		rs.getString("status"),
		       		
		       		
			});			
			  return null;
		});

	return reportData;
	}
	
	//added by kk
	public Map<Integer, Object[]> dumpAuditReportupdate(String startDate,String endDate) 
	{
		Map<Integer, Object[]> reportData = new HashMap<Integer, Object[]>();
		reportData.put(0, new Object[] {
	 			"Sr No", 
				"CASEID",
				"POLICY NUMBER",
				"NATURE OF INVESTIGATION", 
				"ISSUED DATE",
				"INSURED MOB",
				"INSURED NAME",
				"INSURED DOD", 
				"INSURED DOB",
				"INSURED DIAGNOSIS DATE",
				"GENDER",
				"SUM ASSURED",
				"INVESTIGATION TYPE",
				"LOCATION ID",
				"PINCODE", 
				"CASE SUB STATUS",
				"NOTCLEAN CATEGORY", 
				"TRIGGER NAME", 
				"TRIGGER DEPT",
				"DISPOSITION NAME",
				"NOMINEE NAME", 
				"NOMINEE CONTACTNUMBER", 
				"NOMINEE ADDRESS",
				"INSURED ADDRESS",
				"CASE DESCRIPTION",
				//"LONGITUDE", 
				//"LATITUDE", 
				"CREATED BY", 
				"CREATED DATE", 
				"UPDATED DATE", 
				"UPDATED BY",
				"CITY",
				"STATE", 
				"ZONE", 
				"FEES", 
				"STATUS",
				"RCU MOBILE NUMBER",
				"RCU FROMID",
				"RCU TOID",
				"RCU TOROLE", 
				"RCU CASE STATUS", 
				"RCU REMARKS",
				"RCU ALLOCATED DATE", 
				"RCU APPROVED DATE", 
				"RCU TAT",
				"REGMAN MOBILE NUMBER",
				"REGMAN FROMID", 
				"AGNSUP TOID",
				"AGNSUP TOROLE",
				"REGMAN CASE STATUS",
				"REGMAN REMARKS",
				"REGMAN ALLOCATED DATE",
				"REGMAN APPROVED DATE",
				"REGMAN TAT",
				"AGNSUP MOBILE NUMBER", 
				"AGNSUP FROMID",
				"INV TOID",
				"INV TOROLE",
                "AGNSUP CASE STATUS",
                "AGNSUP REMARKS",
				"AGNSUP ALLOCATED DATE",
				"AGNSUP APPROVED DATE",
				"AGNSUP TAT", 
				"INV MOBILE NUMBER",
				"INV FROMID",
				"AGNSUP TOID", 
				"AGNSUP TOROLE", 
				"INV CASE STATUS",
				"INV REMARKS",
				"INV ALLOCATED DATE", 
				"INV APPROVED DATE",
				"INV TAT",
				"AGNSUP MOBILE NUMBER",
				"AGNSUP FROMID",
				"REGMAN TOID",
				"REGMAN TOROLE",
				"AGNSUP CASE STATUS", 
				"AGNSUP REMARKS",
				"AGNSUP ALLOCATED DATE",
				"AGNSUP APPROVED DATE", 
				"AGNSUP TAT",
				"REGMAN MOBILE NUMBER", 
				"REGMAN FROMID",
				"UW TOID",
				"UW TOROLE",
                "REGMAN CASE STATUS", 
                "REGMAN REMARKS",
				"REGMAN ALLOCATED DATE", 
				"REGMAN APPROVED DATE",
				"REGMAN TAT",
				"UW MOBILE NUMBER",
				"UW FROMID", 
				"TALICMAN TOID",
				"TALICMAN TOROLE",
				"UW CASE STATUS",
				"UW REMARKS", 
				"UW ALLOCATED DATE",
				"UW APPROVED DATE",
                "UW TAT"
				});
		String sql = auditdumpstring.getQuery(); 
		
		        //System.out.println("audit query:::"+sql);
		
		template.query(sql, new Object[] {startDate, endDate,startDate, endDate,startDate, endDate,startDate, endDate,startDate, endDate,startDate, endDate,startDate, endDate,startDate, endDate},(ResultSet rs, int rowNum) -> {
			reportData.put(rowNum+1, new Object[] {
					rowNum + 1,
					rs.getString("CASEID"),
					rs.getString("POLICYNUMBER"),
					rs.getString("nature_of_investigation"),
					rs.getString("ISSUEDDATE"),
					rs.getString("INSUREDMOB"),
					rs.getString("INSUREDNAME"),
					rs.getString("INSUREDDOD"),
					rs.getString("INSUREDDOB"),
					rs.getString("INSUREDDIAGNOSISDATE"),
					rs.getString("GENDER"),
					rs.getString("SUMASSURED"),
					rs.getString("INVESTIGATIONTYPE"),
					rs.getString("LOCATIONID"),
					rs.getString("PINCODE"),
					rs.getString("CASESUBSTATUS"),
					rs.getString("NOTCLEANCATEGORY"),
					rs.getString("TRIGGER_NAME"),
					rs.getString("TRIGGER_DEPT"),
					rs.getString("DISPOSITION_NAME"),
					rs.getString("NOMINEE_NAME"),
					rs.getString("NOMINEE_CONTACTNUMBER"),
					rs.getString("NOMINEE_ADDRESS"),
					rs.getString("INSURED_ADDRESS"),
					rs.getString("CASE_DESCRIPTION"),
					//rs.getString("LONGITUDE"),
					//rs.getString("LATITUDE"),
					rs.getString("CREATEDBY"),
					rs.getString("CREATEDDATE"),
					rs.getString("UPDATEDDATE"),
					rs.getString("UPDATEDBY"),
					rs.getString("CITY"),
					rs.getString("STATE"),
					rs.getString("ZONE"),
					rs.getString("FEES"),
					rs.getString("STATUS"),
					rs.getString("RCU-REGMAN_MOBILE_NUMBER"),
					rs.getString("RCU-REGMAN_FROMID"),
					rs.getString("RCU-REGMAN_TOID"),
					rs.getString("RCU-REGMAN_TOROLE"),
					rs.getString("RCU-REGMAN_CASESTATUS"),
					rs.getString("RCU-REGMAN_REMARKS"),
					rs.getString("RCU-REGMAN_ALLOCATED_DATE"),
					rs.getString("RCU-REGMAN_APPROVED_DATE"),
					rs.getString("RCU-REGMAN_TAT"),
					rs.getString("REGMAN-AGNSUP_MOBILE_NUMBER"),
					rs.getString("REGMAN-AGNSUP_FROMID"),
					rs.getString("REGMAN-AGNSUP_TOID"),
					rs.getString("REGMAN-AGNSUP_TOROLE"),
					rs.getString("REGMAN-AGNSUP_CASESTATUS"),
					rs.getString("REGMAN-AGNSUP_REMARKS"),
					rs.getString("REGMAN-AGNSUP_ALLOCATED_DATE"),
					rs.getString("REGMAN-AGNSUP_APPROVED_DATE"),
					rs.getString("REGMAN-AGNSUP_TAT"),
					rs.getString("AGNSUP-INV_MOBILE_NUMBER"),
					rs.getString("AGNSUP-INV_FROMID"),
					rs.getString("AGNSUP-INV_TOID"),
					rs.getString("AGNSUP-INV_TOROLE"),
					rs.getString("AGNSUP-INV_CASESTATUS"),
					rs.getString("AGNSUP-INV_REMARKS"),
					rs.getString("AGNSUP-INV_ALLOCATED_DATE"),
					rs.getString("AGNSUP-INV_APPROVED_DATE"),
					rs.getString("AGNSUP-INV_TAT"),
					rs.getString("INV-AGNSUP_MOBILE_NUMBER"),
					rs.getString("INV-AGNSUP_FROMID"),
					rs.getString("INV-AGNSUP_TOID"),
					rs.getString("INV-AGNSUP_TOROLE"),
					rs.getString("INV-AGNSUP_CASESTATUS"),
					rs.getString("INV-AGNSUP_REMARKS"),
					rs.getString("INV-AGNSUP_ALLOCATED_DATE"),
					rs.getString("INV-AGNSUP_APPROVED_DATE"),
					rs.getString("INV-AGNSUP_TAT"),
					rs.getString("AGNSUP-REGMAN_MOBILE_NUMBER"),
					rs.getString("AGNSUP-REGMAN_FROMID"),
					rs.getString("AGNSUP-REGMAN_TOID"),
					rs.getString("AGNSUP-REGMAN_TOROLE"),
					rs.getString("AGNSUP-REGMAN_CASESTATUS"),
					rs.getString("AGNSUP-REGMAN_REMARKS"),
					rs.getString("AGNSUP-REGMAN_ALLOCATED_DATE"),
					rs.getString("AGNSUP-REGMAN_APPROVED_DATE"),
					rs.getString("AGNSUP-REGMAN_TAT"),
					rs.getString("REGMAN-UW_MOBILE_NUMBER"),
					rs.getString("REGMAN-UW_FROMID"),
					rs.getString("REGMAN-UW_TOID"),
					rs.getString("REGMAN-UW_TOROLE"),
					rs.getString("REGMAN-UW_CASESTATUS"),
					rs.getString("REGMAN-UW_REMARKS"),
					rs.getString("REGMAN-UW_ALLOCATED_DATE"),
					rs.getString("REGMAN-UW_APPROVED_DATE"),
					rs.getString("REGMAN-UW_TAT"),
					rs.getString("UW-TALICMAN_MOBILE_NUMBER"),
					rs.getString("UW-TALICMAN_FROMID"),
					rs.getString("UW-TALICMAN_TOID"),
					rs.getString("UW-TALICMAN_TOROLE"),
					rs.getString("UW-TALICMAN_CASESTATUS"),
					rs.getString("UW-TALICMAN_REMARKS"),
					rs.getString("UW-TALICMAN_ALLOCATED_DATE"),
					rs.getString("UW-TALICMAN_APPROVED_DATE"),
					rs.getString("UW-TALICMAN_TAT")
		       		
			});			
			  return null;
		});

	return reportData;
	}
	
	public Map<Integer, Object[]> getVendorclosedpending(String Status, String vendorName, String startDate,String endDate) 
	{
		String caseStatus ="";
		if(Status.contains("pending")) {
			caseStatus ="main.caseStatus<>'Closed' and";
		}
		if(Status.contains("closed")) {
			caseStatus ="main.caseStatus='Closed' and";
		}
		if(Status.contains("monthly")) {
			caseStatus ="";
		}
		
				
		
		Map<Integer, Object[]> reportData = new HashMap<Integer, Object[]>();
		reportData.put(0, new Object[] {
				"Sr No", 
				"Case ID", 
				"Policy Number", 
				"Nature Of Investigation",
				"City",
				"State",
				"Zone",
				"Issued Date",
				"Insured Mobile Number",
				"Insured Name", 
				"Insured DOD", 
				"Insured DOB",
				"Insured Diagnosis Date",
				"Gender",
				"Sum Assured",
				"Investigation Type",
				"Pincode",
				"Case Status",
				"Case Sub Status",
				"Not Clean Category",
				"Trigger Name",
				"Trigger Department",
				"Disposition Name",
				"Nominee Name",
				"Nominee Contact Number",
				"Nominee Address",
				"Insured Address", 
				"Case Description",
				"Longitude", 
				"Latitude",
				"Created By",
				"Created Date", 
				"Updated Date",
				"TAT",
				"Updated By",
				"Regional Manager",
				"rm_alloted_Date" ,
				"RCU Remarks",
				"Agency Supervisor",
				"agency_alloted_Date",
				"regional_man_remarks",
				"investigator_mobile_number",
				"Investigator",
				"inv_alloted_date",
				"agn_sup_remarks",
				"Invtoagency_supervisor",
				"Invtoagency_alloted_Date",
				"Invtoagency_remarks",
				"Underwriter",
				"uw_alloted_date",
				"reg_man_remarks",
				"talic/claim",
				"talic/claim_alloted_date",
				"uw_remarks",
				"claim_remarks",
				"Inv Report_date",
				"as_Report_date",
	       		"uw_Report_date",
	       		"talic/clamim_Report_date"
				});
       
		
		String sql = "select main.*, (select city from location_lists where locationId = main.locationId) city,   \n" + 
				"												(select state from location_lists where locationId = main.locationId) state,   \n" + 
				"												(select zone from location_lists where locationId = main.locationId) zone,   \n" + 
				"												(select nature_of_investigationType from nature_of_investigation where nature_of_investigationId = main.nature_of_investigationId) as nature_of_investigation,   \n" + 
				"												ISNULL((select full_name from admin_user where username =  ISNULL(agnsup.fromId,'')),'') as regional_manager,    												 \n" + 
				"												ISNULL(regman.updatedDate,'') as rm_alloted_date,    \n" + 
				"												ISNULL(regman.remarks,'') as RCU_Remarks,    \n" + 
				"												case main.casestatus    \n" + 
				"												when 'Closed' then DATEDIFF(day,main.createdDate,main.updatedDate)    \n" + 
				"												else  DATEDIFF(day,main.updatedDate,getdate())   \n" + 
				"												end as TAT,   \n" + 
				"												ISNULL((select full_name from admin_user where username = ISNULL(agnsup.toId,'')),'') as agency_supervisor,    \n" + 
				"												ISNULL(agnsup.updatedDate,'') as agency_alloted_date,    \n" + 
				"												ISNULL(agnsup.remarks,'') as regional_man_remarks,    \n" + 
				"												ISNULL((select mobile_number from admin_user where username = ISNULL(inv.toId,'')),'') as investigator_mobile_number,    \n" + 
				"												ISNULL((select full_name from admin_user where username = ISNULL(inv.toId,'')),'') as investigator,    \n" + 
				"												ISNULL(inv.updatedDate,'') as inv_alloted_date,    \n" + 
				"												ISNULL(inv.remarks,'') as agn_sup_remarks,    \n" + 
				"												ISNULL((select full_name from admin_user where username = ISNULL(agnsuptorm.toId,'')),'') as Invtoagency_supervisor,    \n" + 
				"												ISNULL(agnsuptorm.updatedDate,'') as Invtoagency_alloted_date,    \n" + 
				"												ISNULL(agnsuptorm.remarks,'') as Invtoagency_remarks,    \n" + 
				"												ISNULL((select full_name from admin_user where username = ISNULL(uw.toId,'')),'') as underwriter,  \n" + 
				"												ISNULL(uw.updatedDate,'') as uw_alloted_date,    \n" + 
				"												ISNULL(uw.remarks,'') as regional_man_remarks, 				   \n" + 
				"												ISNULL((select full_name from admin_user where username = ISNULL(talicman.toId,'')),'') as talic,    \n" + 
				"												ISNULL(talicman.updatedDate,'') as talic_alloted_date,   \n" + 
				"												ISNULL(talicman.remarks,'') as uw_remarks, \n" + 
				"												ISNULL(claimman.remarks,'') as claim_remarks, \n" + 
				"												ISNULL(agnsuptorm.updatedDate,'') as Invtoagency_Report_date,  \n" + 
				"												ISNULL(regman2.updatedDate,'') as asTorm_Report_date, \n" + 
				"												ISNULL(uwreport.updatedDate,'') as uwTotalicman_Report_date, \n" + 
				"												ISNULL(talicrmreport.updatedDate,'') as talicman_Report_date \n" + 
				"												from case_lists main 			   \n" + 
				"												left outer join    \n" + 
				"												(select x.* from audit_case_movement x,    \n" + 
				"												(select caseId , min(updatedDate) as updatedDate from audit_case_movement where toRole = 'AGNSUP'   \n" + 
				"												group by caseId) y   \n" + 
				"												where x.caseId = y.caseId and x.toRole = 'AGNSUP' and x.updatedDate = y.updatedDate ) agnsup   \n" + 
				"												on main.caseId = agnsup.caseId 	   \n" + 
				"												left outer join    \n" + 
				"												(select x.* from audit_case_movement x,    \n" + 
				"												(select caseId , min(updatedDate) as updatedDate from audit_case_movement where toRole = 'REGMAN'   \n" + 
				"												group by caseId) y   \n" + 
				"												where x.caseId = y.caseId and x.toRole = 'REGMAN' and x.updatedDate = y.updatedDate ) regman   \n" + 
				"												on main.caseId = regman.caseId   \n" + 
				"												left outer join    \n" + 
				"												(select x.* from audit_case_movement x,    \n" + 
				"												(select caseId , min(updatedDate) as updatedDate from audit_case_movement where toRole = 'UW'   \n" + 
				"												group by caseId) y   \n" + 
				"												where x.caseId = y.caseId and x.toRole = 'UW' and x.updatedDate = y.updatedDate ) uw   \n" + 
				"												on main.caseId = uw.caseId  \n" + 
				"												left outer join    \n" + 
				"												(select x.* from audit_case_movement x,    \n" + 
				"												(select caseId , min(updatedDate) as updatedDate from audit_case_movement where toRole = 'INV'   \n" + 
				"												group by caseId) y   \n" + 
				"												where x.caseId = y.caseId and x.toRole = 'INV' and x.updatedDate = y.updatedDate ) inv   \n" + 
				"												on main.caseId = inv.caseId     \n" + 
				"												left outer join    \n" + 
				"												(select x.* from audit_case_movement x,    \n" + 
				"												(select caseId , min(updatedDate) as updatedDate from audit_case_movement where toRole = 'CLAMAN'   \n" + 
				"												group by caseId) y   \n" + 
				"												where x.caseId = y.caseId and x.toRole = 'CLAIMS' and x.updatedDate = y.updatedDate ) claims   \n" + 
				"												on main.caseId = claims.caseId  \n" + 
				"												left outer join    \n" + 
				"												(select x.* from audit_case_movement x,    \n" + 
				"												(select caseId , min(updatedDate) as updatedDate from audit_case_movement where toRole in( 'TALICMAN')   \n" + 
				"												group by caseId) y   \n" + 
				"												where x.caseId = y.caseId and x.toRole in( 'TALICMAN')   and x.updatedDate = y.updatedDate ) talicman   \n" + 
				"												on main.caseId = talicman.caseId\n" + 
				"												left outer join    \n" + 
				"												(select x.* from audit_case_movement x,    \n" + 
				"												(select caseId , max(updatedDate) as updatedDate from audit_case_movement where toRole='AGNSUP' and \n" + 
				"												fromId in(select username from admin_user where role_name in ('INV')) \n" + 
				"												group by caseId) y   \n" + 
				"												where x.caseId = y.caseId  and x.updatedDate = y.updatedDate) agnsuptorm   \n" + 
				"												on main.caseId = agnsuptorm.caseId 	\n" + 
				"												left outer join    \n" + 
				"												(select x.* from audit_case_movement x,    \n" + 
				"												(select caseId , max(updatedDate) as updatedDate from audit_case_movement where toRole in( 'CLAMAN','REGMAN')and\n" + 
				"												fromId in(select username from admin_user where role_name in ('AGNSUP' ))   \n" + 
				"												group by caseId) y   \n" + 
				"												where x.caseId = y.caseId  and x.updatedDate = y.updatedDate ) regman2   \n" + 
				"												on main.caseId = regman2.caseId \n" + 
				"												left outer join    \n" + 
				"												(select x.* from audit_case_movement x,    \n" + 
				"												(select caseId , max(updatedDate) as updatedDate from audit_case_movement where \n" + 
				"												fromId in(select username from admin_user where role_name in ('UW'))   \n" + 
				"												group by caseId) y   \n" + 
				"												where x.caseId = y.caseId  and x.updatedDate = y.updatedDate ) uwreport  \n" + 
				"												on main.caseId = uwreport.caseId \n" + 
				"												left outer join    \n" + 
				"												(select x.* from audit_case_movement x,    \n" + 
				"												(select caseId , min(updatedDate) as updatedDate from audit_case_movement where toId ='' and\n" + 
				"												fromId in(select username from admin_user where role_name in( 'TALICMAN','CLAMAN'))   \n" + 
				"												group by caseId) y   \n" + 
				"												where x.caseId = y.caseId and x.updatedDate = y.updatedDate) talicrmreport   \n" + 
				"												on main.caseId = talicrmreport.caseId \n" + 
				"												left outer join     \n" + 
				"												(select x.* from audit_case_movement x,     \n" + 
				"												(select caseId , min(updatedDate) as updatedDate from audit_case_movement where toRole in( 'CLAMAN')    \n" + 
				"												group by caseId) y    \n" + 
				"												where x.caseId = y.caseId and x.toRole in('CLAMAN')   and x.updatedDate = y.updatedDate ) claimman    \n" + 
				"												on main.caseId = claimman.caseId \n" + 
				"												left outer join \n" + 
				"												(select caseId , min(updatedDate)as updatedDate from audit_case_movement where toId \n" + 
				"												in(select username from admin_user where role_name in (?) and username = ?)\n" + 
				"												group by caseId) vendor\n" + 
				"												on main.caseId = vendor.caseId \n" + 
				"												where "+ caseStatus  + "\n" +
				"												CONVERT(date, main.createdDate) BETWEEN ? and ? \n" + 
				"												and\n" + 
				"												main.caseId =vendor.caseId";
		
		System.out.println(sql);
		template.query(sql, new Object[] {config.getSUPERVISOR(), vendorName,startDate, endDate},(ResultSet rs, int rowNum) -> {
			reportData.put(rowNum+1, new Object[] {
					rowNum + 1,
					rs.getInt("caseId"),
					rs.getString("policyNumber"),
					rs.getString("nature_of_investigation"),
					rs.getString("city"),
					rs.getString("state"),
					rs.getString("zone"),
					rs.getString("issuedDate"),
					rs.getString("insuredMob"),
					rs.getString("insuredName"),
					rs.getString("insuredDOD"),
					rs.getString("insuredDOB"),
					rs.getString("insuredDiagnosisDate"),
					rs.getString("gender"),
					rs.getString("sumAssured"),
					rs.getString("investigationType"),
					rs.getString("pincode"),
					rs.getString("caseStatus"),
					rs.getString("caseSubStatus"),
					rs.getString("notCleanCategory"),
					rs.getString("trigger_name"),
					rs.getString("trigger_dept"),
		       		rs.getString("disposition_name"),
		       		rs.getString("nominee_Name"),
		       		rs.getString("nominee_ContactNumber"),
		       		rs.getString("nominee_address"),
		       		rs.getString("insured_address"),
		       		rs.getString("case_description"),
		       		rs.getString("longitude"),
		       		rs.getString("latitude"),
		       		rs.getString("createdBy"),
		       		rs.getString("createdDate"),
		       		rs.getString("updatedDate"),
		       		rs.getString("TAT"),
		       		rs.getString("updatedBy"),
		       		rs.getString("regional_manager"),
		       		rs.getString("rm_alloted_date"),
		       		rs.getString("RCU_Remarks"),
		       		rs.getString("agency_supervisor"),
		       		rs.getString("agency_alloted_date"),
		       		rs.getString("regional_man_remarks"),
		       		rs.getString("investigator_mobile_number"),
		       		rs.getString("investigator"),
		       		rs.getString("inv_alloted_date"),
		       		rs.getString("agn_sup_remarks"),
		       		rs.getString("Invtoagency_supervisor"),
		       		rs.getString("Invtoagency_alloted_Date"),
		       		rs.getString("Invtoagency_remarks"),
		       		rs.getString("underwriter"),
		       		rs.getString("uw_alloted_date"),
		       		rs.getString("regional_man_remarks"),
		       		rs.getString("talic"),
		       		rs.getString("talic_alloted_date"),
		       		rs.getString("uw_remarks"),
		       		rs.getString("claim_remarks"),
		       		rs.getString("Invtoagency_Report_date"),
		       		rs.getString("asTorm_Report_date"),
		       		rs.getString("uwTotalicman_Report_date"),
		       		rs.getString("talicman_Report_date")
		       		
			});			
			  return null;
		});

	return reportData;
	}
	
}
