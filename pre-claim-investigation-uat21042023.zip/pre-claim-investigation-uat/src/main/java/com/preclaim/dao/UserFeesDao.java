package com.preclaim.dao;

import java.sql.ResultSet;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;
import com.preclaim.config.CustomMethods;
import com.preclaim.models.User_fees;

@Component
public class UserFeesDao {

	@Autowired
	DataSource datasource;
	
	@Autowired
	JdbcTemplate template;
	public void setTemplate(JdbcTemplate template) {
		this.template = template;
	}
	
	String sql = "";
	
	public List<User_fees> getAllUserFees(String UserID){
		try
		{
			String sql = "select * from user_fees where username = ?";			
			List<User_fees> user_list = this.template.query(sql, new Object[] {UserID},(ResultSet rs, int count) -> {
			User_fees user = new User_fees();
			user.setSrno(count + 1);
			user.setUsername(rs.getString("username"));
			user.setInvestigationType(rs.getString("investigationType"));
			user.setFees(rs.getDouble("fees"));
			return user;
		   });
			return user_list;
		}
		catch(Exception e)
		{
			e.printStackTrace();
			CustomMethods.logError(e);
			return null;
		}		
	}
		
	
	public String updateFees(String username,String investigationType,double fees) {
		try 
		{
			sql = "update user_fees set fees = ? where investigationType = ? and username = ?";
			this.template.update(sql, fees, investigationType, username);	
		}
		catch(Exception e) 
		    {
	    		e.printStackTrace();
	    		CustomMethods.logError(e);
	    	}
	
		return "****";
	}
	
	public String addFees(String username, String InvestigationType, double userfees, String createdBy) {
		try 
		{
			if(InvestigationType.trim().equals(""))
				return "Investigation Type cannot be blank";
			sql = "select count(*) from user_fees where investigationType = ? and username = ?";
			int count = template.queryForObject(sql, Integer.class, InvestigationType, username);
			if(count > 0)
				return "Fees already added for " + InvestigationType + " Investigation Type";
			
		  	sql = "INSERT INTO user_fees(username, investigationType, fees, createdBy, createdDate) "
		  			+ "values(?, ?, ?, ?, getdate())";
	        this.template.update(sql, username, InvestigationType, userfees, createdBy);	
		}
		catch(Exception e) 
		{
			e.printStackTrace();
			CustomMethods.logError(e);
		}
		return "****";
	
	}
	
	public String checkFees(String username) {
		try 
		{
			sql = "select count(*) from user_fees where username = ?";
		    if(template.queryForObject(sql, Integer.class, username) > 0)
		    	return "****";
		    else
		    	return "Kindly add Agency fees";
				
		}
		catch(Exception e) 
		{
			e.printStackTrace();
			CustomMethods.logError(e);
			return e.getMessage();
		}
	}
}
