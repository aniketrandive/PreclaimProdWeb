package com.preclaim.dao;

import java.sql.ResultSet;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.preclaim.config.CustomMethods;
import com.preclaim.models.TriggerDepartment;
import com.preclaim.models.TriggerName;

@Component
public class TriggerDao {


	@Autowired
	DataSource datasource;

	@Autowired
	JdbcTemplate template;

	public void setTemplate(JdbcTemplate template) {
		this.template = template;
	}

	String sql ="";

	public String addTriggerName(TriggerName trigger) {

		try {
			 sql = "SELECT COUNT(*) FROM  trigger_name where trigger_name = '" + 
					trigger.getTrigger_name() + "'";
			int count = this.template.queryForObject(sql,Integer.class);
			if(count > 0)
				return "Trigger name already exists";
			//System.out.println("alreay exist");
			 sql = "INSERT INTO trigger_name(trigger_name, status, created_date,updated_date,updated_by)"
				 	  + " values(?, '0', getdate(), getdate(), ?)";
			this.template.update(sql,trigger.getTrigger_name(),trigger.getUpdated_by());
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
			CustomMethods.logError(e);
			return e.getMessage();
		}

		return "****";
	}

	
	public List<TriggerName> getActiveTriggerNameList() {
	    sql = "SELECT * from trigger_name WHERE status =  1";
		return template.query(sql, (ResultSet rs, int rowNum) -> {
			TriggerName details = new TriggerName();
			details.setTrigger_name(rs.getString("trigger_name"));
			details.setStatus(rs.getString("status"));
			return details;
		});
	}
	
	public List<String> getTriggerList() {
	    sql = "SELECT * from trigger_name WHERE status =  1";
		return template.query(sql, (ResultSet rs, int rowNum) -> {
			return rs.getString("trigger_name");
		});
	}
	
	public List<String> getTriggerDeptList() {
	    sql = "SELECT * from trigger_department WHERE status =  1";
		return template.query(sql, (ResultSet rs, int rowNum) -> {
			return rs.getString("trigger_dept");
		});
	}
	
	public List<TriggerName> getAllTriggerNameList() {
	 sql = "SELECT * from trigger_name";
		return template.query(sql, (ResultSet rs, int rowNum) -> {
			TriggerName details = new TriggerName();
			details.setTrigger_name(rs.getString("trigger_name"));
			details.setStatus(rs.getString("status"));
			return details;
		});
	}

	public String updateTriggerNameStatus(String triggerName, String status) 
	{
		try 
		{	
			sql = "INSERT INTO audit_trigger_name select * from trigger_name where trigger_name = ?";
			this.template.update(sql,triggerName);
			
			String sql = "UPDATE trigger_name SET status = ? where trigger_name = ?";
			this.template.update(sql, status, triggerName);
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
			CustomMethods.logError(e);
			return e.getMessage();
	    }
		return "****";
	}

	
	public String deleteTriggerName(String triggerName) {
		try 
		{
			sql = "INSERT INTO audit_trigger_name select * from trigger_name where trigger_name = ?";
			this.template.update(sql,triggerName);
			
		    sql = "DELETE FROM trigger_name WHERE trigger_name = ?";
			this.template.update(sql,triggerName);
		}
		catch(Exception e) 
		{
			e.printStackTrace();
			CustomMethods.logError(e);
			return e.getMessage();	
		}
		return "****";	
	}
	
	
	public String updateTriggerName(String triggerName,String triggerId) 
	{
		try
		{
			sql = "INSERT INTO audit_trigger_name select * from trigger_name where trigger_name = ?";
			this.template.update(sql,triggerName);
			
			String TriggerCheck = "select count(*) from trigger_name where trigger_name='" + triggerName + "' and trigger_name "
					+ " not in (select trigger_name from trigger_name where trigger_name = '" + triggerId + "')";
			int TriggerCount = this.template.queryForObject(TriggerCheck, Integer.class);
			if(TriggerCount > 0)
				return "Trigger already exists";
			
		
			String sql = "update trigger_name set trigger_name = ? where trigger_name = ?";
			template.update(sql, triggerName, triggerId);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			CustomMethods.logError(e);
			return e.getMessage();
		}
		return "****";
	}
	
	
	//department
	
	public String addTriggerDepartment(TriggerDepartment department) {

		try {
			
			sql = "SELECT COUNT(*) FROM  trigger_department where trigger_dept = '" + 
					department.getTrigger_dept() + "'";
			int count = this.template.queryForObject(sql,Integer.class);
			if(count > 0)
				return "Trigger department already exists";
			
			String sql = "INSERT INTO trigger_department(trigger_dept, status,updated_date,updated_by)"
				 	  + " values(?, '0',getdate(), ?)";
			this.template.update(sql,department.getTrigger_dept(),department.getUpdated_by());
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
			CustomMethods.logError(e);
			return e.getMessage();
		}

		return "****";
	}

	
	public List<TriggerDepartment> getActiveTriggerDepartmentList() {
		String query = "SELECT * from trigger_department WHERE status =  1";
		return template.query(query, (ResultSet rs, int rowNum) -> {
			TriggerDepartment details = new TriggerDepartment();
			details.setTrigger_dept(rs.getString("trigger_dept"));
			details.setStatus(rs.getString("status"));
			return details;
		});
	}
	
	public List<TriggerDepartment> getAllTriggerDepartmentList() {
		String query = "SELECT * from trigger_department";
		return template.query(query, (ResultSet rs, int rowNum) -> {
			TriggerDepartment details = new TriggerDepartment();
			details.setTrigger_dept(rs.getString("trigger_dept"));
			details.setStatus(rs.getString("status"));
			return details;
		});
	}

	public String updateTriggerDepartmentStatus(String triggerDepartment, String status) 
	{
		try 
		{
			sql = "INSERT INTO audit_trigger_department select * from trigger_department where trigger_dept = ?";
			this.template.update(sql,triggerDepartment);
			
			String sql = "UPDATE trigger_department SET status = ? where trigger_dept = ?";
			this.template.update(sql, status, triggerDepartment);
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
			CustomMethods.logError(e);
			return e.getMessage();
	    }
		return "****";
	}

	
	public String deleteTriggerDepartment(String triggerDepartment) {
		try 
		{
			sql = "INSERT INTO audit_trigger_department select * from trigger_department where trigger_dept = ?";
			this.template.update(sql,triggerDepartment);
			
			String sql = "DELETE FROM trigger_department WHERE trigger_dept = ?";
			this.template.update(sql,triggerDepartment);
		}
		catch(Exception e) 
		{
			e.printStackTrace();
			CustomMethods.logError(e);
			return e.getMessage();	
		}
		return "****";	
	}
	
	
	public String updateTriggerDepartment(String triggerDepartment,String departmentId) 
	{
		try
		{
			sql = "INSERT INTO audit_trigger_department select * from trigger_department where trigger_dept = ?";
			this.template.update(sql,triggerDepartment);
			
			sql = "select count(*) from trigger_department where trigger_dept='" + triggerDepartment + "' and trigger_dept "
					+ " not in (select trigger_dept from trigger_department where trigger_dept = '" + departmentId + "')";
			int count = this.template.queryForObject(sql, Integer.class);
			if(count > 0)
				return "Trigger Department already exists";
			
			sql = "update trigger_department set trigger_dept = ? where trigger_dept = ?";
			template.update(sql, triggerDepartment, departmentId);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			CustomMethods.logError(e);
			return e.getMessage();
		}
		return "****";
	}
	
	
}
