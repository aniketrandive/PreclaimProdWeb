package com.preclaim.dao;

import java.sql.ResultSet;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.preclaim.config.CustomMethods;
import com.preclaim.models.BillManagementList;
import com.preclaim.models.CaseDetails;
import com.preclaim.models.Case_payment;
import com.preclaim.models.UserDetails;

@Component
public class BillingManagementDao {

	@Autowired
	DataSource datasource;
	
	@Autowired
	private NatureOfInvestigationDao natureOfInvestigationDaoImpl;
	
	@Autowired
	CaseDao caseDao;
	
	@Autowired
	UserDAO userDao;

	@Autowired
	JdbcTemplate template;
	
	public List<BillManagementList> billPaymentList() 
	{
		String sql = 
			"select a.*,b.toId as username,(select full_name from admin_user where username = b.toId and role_name = 'AGNSUP') as full_name,\n"
			+ "(select nature_of_investigationType from nature_of_investigation where nature_of_investigationId in (select a.nature_of_investigationId from case_lists)) as nature_of_investigation,\n"
			+ "ISNULL((select fees from admin_user x left outer join user_fees y on x.username = y.username \n"
			+ "where x.username = b.toId and y.investigationType = a.investigationType and x.role_name ='AGNSUP'),0) as fees \n"
			+ "from case_lists a, (select caseId, toId, max(updatedDate) as latestDate \n"
			+ "from audit_case_movement a where a.toRole = 'AGNSUP' group by caseId, toId) b where a.caseId = b.caseId and a.caseStatus = 'Closed' \n"
			+ "and a.caseId not in (select caseId from case_payment where userId = b.toId)";
		return template.query(sql, (ResultSet rs, int rowNum) -> {
			BillManagementList billManagementList = new BillManagementList();
			billManagementList.setSrNo(rowNum + 1);
			billManagementList.setCaseID(rs.getInt("caseId"));
			billManagementList.setPolicyNumber(rs.getString("policyNumber"));
			billManagementList.setNature_of_investigationType(rs.getString("nature_of_investigation"));
			billManagementList.setInvestigationType(rs.getString("investigationType"));
			billManagementList.setSupervisorID(rs.getString("username"));
			billManagementList.setSupervisorName(rs.getString("full_name"));
			billManagementList.setUpdatedDate(rs.getString("updatedDate"));
			billManagementList.setCharges(rs.getDouble("fees"));
			return billManagementList;
		});
	}
		
	public List<BillManagementList> billPaymentList(String startDate,String endDate) 
	{
		String sql = 
			"select a.*,b.toId as username,(select full_name from admin_user where username = b.toId and role_name = 'AGNSUP') as full_name,\n"
			+ "(select nature_of_investigationType from nature_of_investigation where nature_of_investigationId in (select a.nature_of_investigationId from case_lists)) as nature_of_investigation,\n"
			+ "ISNULL((select fees from admin_user x left outer join user_fees y on x.username = y.username \n"
			+ "where x.username = b.toId and y.investigationType = a.investigationType and x.role_name ='AGNSUP'),0) as fees \n"
			+ "from case_lists a, (select caseId, toId, max(updatedDate) as latestDate \n"
			+ "from audit_case_movement a where a.toRole = 'AGNSUP' group by caseId, toId) b where a.caseId = b.caseId and a.caseStatus = 'Closed' \n"
			+ "and a.caseId not in (select caseId from case_payment where userId = b.toId) and\n" + 
			"CONVERT(date, a.updatedDate) BETWEEN ? and ?";
		return template.query(sql,new Object[] {startDate, endDate}, (ResultSet rs, int rowNum) -> {
			BillManagementList billManagementList = new BillManagementList();
			billManagementList.setSrNo(rowNum + 1);
			billManagementList.setCaseID(rs.getInt("caseId"));
			billManagementList.setPolicyNumber(rs.getString("policyNumber"));
			billManagementList.setNature_of_investigationType(rs.getString("nature_of_investigation"));
			billManagementList.setInvestigationType(rs.getString("investigationType"));
			billManagementList.setSupervisorID(rs.getString("username"));
			billManagementList.setSupervisorName(rs.getString("full_name"));
			billManagementList.setUpdatedDate(rs.getString("updatedDate"));
			billManagementList.setCharges(rs.getDouble("fees"));
			return billManagementList;
		});
	}
	
	
		
	public Map<Integer, Object[]> billPaymentList(List<Case_payment> className) 
	{
		HashMap<Integer, String> investigationType = natureOfInvestigationDaoImpl.getActiveNatureOfInvestigationMapping();
	 
		Map<Integer, Object[]> paidcases = new HashMap<Integer, Object[]>();
		paidcases.put(0, new Object[] {"Sr No", "Case ID", "Policy Number", "Investigation Type", 
			"Intimation Type", "Insured Name", "Insured DOB", "Insured DOD","insuredDiagnosisDate", "Insured Address",
			"Nominee Name", "Nominee Contact Number", "Nominee Address", "Sum Assured",
			"Longitude", "Latitude", "Case Description", "Captured Date",
			"Agency Supervisor", "Fees"});
        int index = 1;
		for(Case_payment payment : className) {
	    UserDetails user =  userDao.getUserDetails(String.valueOf(payment.getUserId()));	
		CaseDetails detail = caseDao.getCaseDetailByCaseId(payment.getCaseId());
		paidcases.put(index,new Object[] {index,detail.getCaseId(),detail.getPolicyNumber(),investigationType.get(detail.getNatureOfInvestigationId()),
		detail.getInvestigationType(),detail.getInsuredName(),detail.getInsuredDOB(),detail.getInsuredDOD(),detail.getDateOfDiagnosis(),
		detail.getInsured_address(),detail.getNominee_name(),detail.getNomineeContactNumber(),detail.getNominee_address(),detail.getSumAssured(),detail.getLongitude(),
		detail.getLatitude(),detail.getCase_description(),detail.getCreatedDate(),user.getFull_name(),payment.getFees()
		});
		index++;
	}
		 return paidcases;
	}
		
		
	public String UpdateFees(Case_payment casePayment) {
		try
		{
			
			String sql = "INSERT INTO case_payment (caseId, userId, fees, created_by, created_date)"
					     + "values(?, ?, ?, ?, getdate())";
			this.template.update(sql, casePayment.getCaseId(),casePayment.getUserId(),casePayment.getFees(),casePayment.getCreated_by());
		}
		catch(Exception e)
		{
			e.printStackTrace();
			CustomMethods.logError(e);
			return e.getMessage();
		}
		return "****";
	}
		
		
	public List<BillManagementList> billEnquiryList() 
	{
		String sql = 
				"select a.*,b.userId as username," + 
				"(select full_name from admin_user where username = b.userId and role_name = 'AGNSUP') as full_name," + 
				"b.fees  from case_lists a, case_payment b where a.caseId = b.caseId" + 
				"";
	 
		return template.query(sql, (ResultSet rs, int rowNum) -> {
			BillManagementList billManagementList = new BillManagementList();
			billManagementList.setSrNo(rowNum + 1);
			billManagementList.setCaseID(rs.getInt("caseId"));
			billManagementList.setPolicyNumber(rs.getString("policyNumber"));
			billManagementList.setInvestigationType(rs.getString("investigationType"));
			billManagementList.setSupervisorID(rs.getString("username"));
			billManagementList.setSupervisorName(rs.getString("full_name"));
			billManagementList.setCharges(rs.getDouble("fees"));
			return billManagementList;
		});
	}
		
}
