package com.preclaim.dao;

import java.sql.ResultSet;
import java.util.List;
import java.util.Properties;

import javax.naming.NamingException;
import javax.naming.directory.InitialDirContext;
import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.preclaim.config.Config;
import com.preclaim.config.CustomMethods;
import com.preclaim.models.Login;
import com.preclaim.models.UserDetails;
import javax.naming.Context;
@Component
public class LoginDAO{
	
	@Autowired  
	DataSource datasource;
	
	@Autowired  
	private JdbcTemplate template;
	
	@Autowired
	Config config;
	
	String sql = "";
	
	public UserDetails validateUser(Login login)	  
	{	
		String sql = "SELECT * FROM admin_user WHERE username = ? and password = ?";
		List<UserDetails> user_list = template.query(sql, 
				new Object[] {login.getUsername(),login.getPassword()},
				(ResultSet rs, int arg1) ->{
					UserDetails login_user = new UserDetails();
					login_user.setUserID(rs.getInt("user_id"));
					login_user.setUsername(rs.getString("username"));
					login_user.decodePassword(rs.getString("password"));
					login_user.setFull_name(rs.getString("full_name"));
					login_user.setStatus(rs.getInt("status"));
					login_user.setUser_email(rs.getString("user_email"));
					login_user.setAccount_type(rs.getString("role_name"));
					login_user.setUserimage(rs.getString("user_image"));
					login_user.setState(rs.getString("state"));
					login_user.setCity(rs.getString("city"));
					login_user.setUserImageb64(config.getUpload_directory() + rs.getString("user_image"));
					login_user.setCounter(rs.getInt("counter"));
					return login_user;
				});
		return user_list.size() > 0 ? user_list.get(0) : null ;
	  }

	
	public UserDetails checkUser(String username) {
		try
		{
			String sql = "SELECT * FROM admin_user WHERE username = ?";
			List<UserDetails> user_list = template.query(sql, 
					new Object[] {username},
					(ResultSet rs, int arg1) ->{
						UserDetails login_user = new UserDetails();
						login_user.setUserID(rs.getInt("user_id"));
						login_user.setAccount_type(rs.getString("role_name"));
						login_user.setUsername(rs.getString("username"));
						login_user.setVendor_id(rs.getString("vendor_id"));
						login_user.decodePassword(rs.getString("password"));
						login_user.setFull_name(rs.getString("full_name"));
						login_user.setCity(rs.getString("city"));
						login_user.setStatus(rs.getInt("status"));
						login_user.setUser_email(rs.getString("user_email"));
						login_user.setUserimage(rs.getString("user_image"));
						login_user.setUserImageb64(config.getUpload_directory() + rs.getString("user_image"));
						login_user.setCounter(rs.getInt("counter"));
						return login_user;
					});
			return user_list.size() > 0 ? user_list.get(0) : null ;
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
			CustomMethods.logError(ex);
			return null;
		}
	}

	
	public String updatePassword(String username, String password,int counter) {
		try
		{
			String sql = "UPDATE admin_user SET password = ?, updatedBy = ?, counter=? ,updatedDate = getdate() WHERE username = ?";
			template.update(sql, password, username,counter ,username);
		}
		catch(Exception ex)
		{
			CustomMethods.logError(ex);
			return ex.getMessage();
		}
		return "****";
	}
	
    // LDAP Logic 
	public boolean NTLoginold(String username, String password) throws NamingException 
	{
        try
        {
            InitialDirContext context = null;
            Properties props = new Properties();
            props.put(Context.INITIAL_CONTEXT_FACTORY,config.getINITIAL_CONTEXT_FACTORY());
            props.put(Context.PROVIDER_URL, config.getPROVIDER_URL());
            props.put(Context.SECURITY_PRINCIPAL, "CN=" + username.trim() + config.getSECURITY_PRINCIPAL());
            props.put(Context.SECURITY_CREDENTIALS, password);
            context = new InitialDirContext(props);
            context.close();
            return true;	  
        }
        catch(NamingException e)
        {
        	CustomMethods.logError(e);
            e.printStackTrace();
            return false;
        }
    }
	
	public boolean NTLogin(String username, String password) throws NamingException 
	{
        try
        {
        	
    		InitialDirContext context = null;
			final Properties props = new Properties();
			props.put("java.naming.factory.initial", config.getINITIAL_CONTEXT_FACTORY());
			props.put("java.naming.provider.url",config.getPROVIDER_URL());
			props.put("java.naming.SECURITY.AUTHENTICATION","simple");
			props.put("java.naming.security.principal", "CN=" + username.trim() + config.getSECURITY_PRINCIPAL());
			props.put("java.naming.security.credentials", password);
			context = new InitialDirContext(props);
			context.close();
            return true;	  
        }
        catch(NamingException e)
        {
        	CustomMethods.logError(e);
            e.printStackTrace();
            return false;
        }
    }
}

