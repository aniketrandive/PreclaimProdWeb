package com.preclaim.dao;

import java.sql.ResultSet;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.preclaim.config.CustomMethods;
import com.preclaim.models.CaseDetails;
import com.preclaim.models.CaseHistory;
import com.preclaim.models.CaseMovement;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class Case_movementDao{

	@Autowired
	DataSource datasource;

	@Autowired
	private JdbcTemplate template;

	public void setTemplate(JdbcTemplate template) {
		this.template = template;
	}

	
	public String CreatecaseMovement(CaseMovement caseMovement) {
		try
		{
		   String query="INSERT INTO case_movement(caseId, fromID, toId, caseStatus, remarks, toRole, zone,"
		   		+ "createdDate, updatedDate) values(?, ?, ?, ?, ?, ?, ?, getdate(), getdate()) ";
		   this.template.update(query,caseMovement.getCaseId(), caseMovement.getFromId(), 
				   caseMovement.getToId(), caseMovement.getCaseStatus(), caseMovement.getRemarks(), caseMovement.getToRole(), caseMovement.getZone());

		   query = "INSERT INTO audit_case_movement SELECT * FROM case_movement where caseId = ?";
		   this.template.update(query,caseMovement.getCaseId());
	    }
		catch(Exception e) 
		{	
			e.printStackTrace();
			log.error(caseMovement.toString());
			CustomMethods.logError(e);
			return e.getMessage();	
		}
		return "****";
	}

	
	public CaseMovement getCaseById(long caseId) {
		String sql = "SELECT * FROM case_movement where caseId = ?";	
		return template.query(sql, new Object[] {caseId}, (ResultSet rs, int rowNum) -> {
			CaseMovement case_movement = new CaseMovement();
			case_movement.setCaseId(caseId);
			case_movement.setFromId(rs.getString("fromId"));
			case_movement.setToId(rs.getString("toId"));
			case_movement.setCaseStatus(rs.getString("caseStatus"));
			case_movement.setRemarks(rs.getString("Remarks"));
			case_movement.setZone(rs.getString("zone"));
			return case_movement;
		}).get(0);
	}

	
	public String updateCaseMovement(CaseMovement caseMovement) {
		try
		{
		   String query = "UPDATE case_movement SET fromID = ?, toId = ?, caseStatus = ?, remarks = ?, "
		   		+ "toRole = ?, updatedDate = getdate() where caseId = ?";
		   this.template.update(query,caseMovement.getFromId(), caseMovement.getToId(), 
				   caseMovement.getCaseStatus(),caseMovement.getRemarks(), 
				   caseMovement.getToRole(), caseMovement.getCaseId());
		 
		   query = "INSERT INTO audit_case_movement SELECT * FROM case_movement where caseId = ?";
			   this.template.update(query,caseMovement.getCaseId());
	    }
		catch(Exception e) 
		{	
			e.printStackTrace();
			log.error(caseMovement.toString());
			CustomMethods.logError(e);
			return e.getMessage();
		}		
		return "****";
	}
	
	
	public String BulkupdateCaseMovement(CaseMovement caseMovement,String list) {
		try
		{
		   String query = "UPDATE case_movement SET fromID = ?, toId = ?, caseStatus = ?, remarks = ?, "
		   		+ "toRole = ?, updatedDate = getdate() where caseId in(" + list + ")";
		   this.template.update(query,caseMovement.getFromId(), caseMovement.getToId(), 
				   caseMovement.getCaseStatus(),caseMovement.getRemarks(), 
				   caseMovement.getToRole());
		 
		   query = "INSERT INTO audit_case_movement SELECT * FROM case_movement where caseId in(" + list + ")";
			   this.template.update(query);
	    }
		catch(Exception e) 
		{	
			e.printStackTrace();
			log.error(caseMovement.toString());
			CustomMethods.logError(e);
			return e.getMessage();
		}		
		return "****";
	}
	
	

	
	public List<CaseHistory> getCaseMovementHistory(long caseId) {
		String sql = "SELECT * FROM audit_case_movement where caseId = ? order by updatedDate";	
		List<CaseHistory> case_details = template.query(sql, new Object[] {caseId}, 
				(ResultSet rs, int rowNum) -> 
		{
			CaseHistory case_history = new CaseHistory();
			case_history.setCaseId(caseId);
			case_history.setFromId(rs.getString("fromId"));
			case_history.setToId(rs.getString("toId"));
			case_history.setCaseStatus(rs.getString("caseStatus"));
			case_history.setRemarks(rs.getString("Remarks"));
			case_history.setCreatedDate(rs.getString("createdDate"));
			case_history.setUpdatedDate(rs.getString("updatedDate"));
			return case_history;
		});
		if(case_details!=null) {
		for(int i = 0; i < case_details.size(); i++)
		{
			sql = "SELECT full_name from admin_user where username = '" + case_details.get(i).getFromId() + "'";
			case_details.get(i).setFromUserName(template.queryForObject(sql, String.class));
			
		}
		
		for(int i = 0; i < case_details.size(); i++)
		{
			sql = "SELECT role from admin_user a, user_role b where a.role_name = b.role_code and "
					+ "a.username = '" + case_details.get(i).getFromId() + "'";
			case_details.get(i).setRole(template.queryForObject(sql, String.class));
		}
	}
		return case_details;
	}

	public CaseHistory getCaseMovement(long caseId) {
		String sql = "SELECT * FROM case_movement where caseId = ?";	
		CaseHistory case_details = template.query(sql, new Object[] {caseId}, 
				(ResultSet rs, int rowNum) -> 
		{
			CaseHistory case_history = new CaseHistory();
			case_history.setCaseId(caseId);
			case_history.setFromId(rs.getString("fromId"));
			case_history.setToId(rs.getString("toId"));
			case_history.setRole(rs.getString("toRole"));
			case_history.setCaseStatus(rs.getString("caseStatus"));
			case_history.setRemarks(rs.getString("Remarks"));
			case_history.setCreatedDate(rs.getString("createdDate"));
			case_history.setUpdatedDate(rs.getString("updatedDate"));
			return case_history;
		}).get(0);
		
		if(!case_details.getToId().equals(""))
		{
			sql = "SELECT full_name from admin_user where username = '" + case_details.getToId()
				+ "'";
			case_details.setFromUserName(template.queryForObject(sql, String.class));
		}
		if(!case_details.getRole().equals(""))
		{
		sql = "SELECT role from user_role where role_code = '" + case_details.getRole() + "'";
		case_details.setRole(template.queryForObject(sql, String.class));
		case_details.setRemarks(" ");;
		}
		if(!case_details.getCaseStatus().equals("Closed")) {
			case_details.setCaseStatus("pending");}
	
		return case_details;
	}
	
	public CaseHistory getauditCaseMovement(CaseDetails caseDetail) {
		String sql = 
				/*"SELECT * FROM audit_case_movement where  caseId = ( select max(caseId)from case_lists where \n" + 
				"policyNumber = '?' and caseStatus <> 'Closed' group by policyNumber)  and toRole ='AGNSUP'";*/	
				"SELECT top 1 * FROM audit_case_movement where  caseId = ( select top 1 (caseId) from case_lists where \n" + 
				"policyNumber = ? and caseStatus <> 'Closed' order by  updatedDate desc)  and toRole ='AGNSUP' order by  updatedDate desc";
				
		List<CaseHistory>  case_details = template.query(sql, new Object[] {caseDetail.getPolicyNumber()}, 
				(ResultSet rs, int rowNum) -> 
		{
			CaseHistory case_history = new CaseHistory();
			case_history.setCaseId(rs.getInt("caseId"));
			case_history.setFromId(rs.getString("fromId"));
			case_history.setToId(rs.getString("toId"));
			case_history.setRole(rs.getString("toRole"));
			case_history.setCaseStatus(rs.getString("caseStatus"));
			case_history.setRemarks(rs.getString("Remarks"));
			case_history.setCreatedDate(rs.getString("createdDate"));
			case_history.setUpdatedDate(rs.getString("updatedDate"));
			return case_history;
		});
		if(case_details.size() < 0) {
		if(!case_details.get(0).getToId().equals(""))
		{
			sql = "SELECT full_name from admin_user where username = '" + case_details.get(0).getToId()
				+ "'";
			case_details.get(0).setFromUserName(template.queryForObject(sql, String.class));
		}
		if(!case_details.get(0).getRole().equals(""))
		{
		sql = "SELECT role from user_role where role_code = '" + case_details.get(0).getRole() + "'";
		case_details.get(0).setRole(template.queryForObject(sql, String.class));
		case_details.get(0).setRemarks(" ");;
		}
		
		System.out.println(case_details.get(0));
		return case_details.get(0);
		}
		else
		return new CaseHistory();
		}
		
	
		
		

	
	public CaseHistory getauditCaseMovementdate(CaseDetails caseDetail) {
		String sql = "select a.*,c.investigationType as investigationType, c.updatedDate as closedDate from audit_case_movement a, (\n" + 
				"SELECT caseId, max(updatedDate) as updatedDate FROM audit_case_movement where  caseId =(\n" + 
				"select max(caseId)from case_lists as c\n" + 
				"where policyNumber = ? and caseStatus = 'Closed' \n" + 
				"group by policyNumber)  and toRole ='AGNSUP'\n" + 
				"  group by caseId  ) b , case_lists c where a.caseId = b.caseId and a.toRole = 'AGNSUP' and a.updatedDate = b.updatedDate\n" + 
				"  and a.caseId = c.caseId";	
		List<CaseHistory> case_details = template.query(sql, new Object[] {caseDetail.getPolicyNumber()}, 
				(ResultSet rs, int rowNum) -> 
		{
			CaseHistory case_history = new CaseHistory();
			case_history.setCaseId(rs.getInt("caseId"));
			case_history.setFromId(rs.getString("fromId"));
			case_history.setToId(rs.getString("toId"));
			case_history.setRole(rs.getString("toRole"));
			case_history.setCaseStatus(rs.getString("caseStatus"));
			case_history.setRemarks(rs.getString("Remarks"));
			case_history.setCreatedDate(rs.getString("investigationType"));
			case_history.setUpdatedDate(rs.getString("closedDate"));
			
			return case_history;
		});
		if(case_details.size() < 0) {
		if(!case_details.get(0).getToId().equals(""))
		{
			sql = "SELECT full_name from admin_user where username = '" + case_details.get(0).getToId()
				+ "'";
			case_details.get(0).setFromUserName(template.queryForObject(sql, String.class));
		}
		if(!case_details.get(0).getRole().equals(""))
		{
		sql = "SELECT role from user_role where role_code = '" + case_details.get(0).getRole() + "'";
		case_details.get(0).setRole(template.queryForObject(sql, String.class));
		case_details.get(0).setRemarks(" ");;
		}
		
		
		return case_details.get(0);
		}
		else
			return new CaseHistory();	
	}


}
