package com.preclaim;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.session.web.http.CookieSerializer;
import org.springframework.session.web.http.DefaultCookieSerializer;

import com.preclaim.config.Config;

@SpringBootApplication
@EnableConfigurationProperties(Config.class)
public class PreClaimInvestigationApplication {

	public static void main(String[] args) {
		SpringApplication.run(PreClaimInvestigationApplication.class, args);
	}


}
