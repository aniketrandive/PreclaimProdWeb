package com.preclaim.controller;

import java.util.List;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.preclaim.config.CustomMethods;
import com.preclaim.dao.CaseDao;
import com.preclaim.dao.UserDAO;
import com.preclaim.models.CaseDetails;
import com.preclaim.models.ScreenDetails;
import com.preclaim.models.UserDetails;
import com.preclaim.models.User_locations;

@Controller
@RequestMapping(value = "/livetracking")
public class LivetrackingController {

	@Autowired
	CaseDao caseDao;
	
	@Autowired
	UserDAO userDao;
	
    @RequestMapping(value = "/index", method = RequestMethod.GET)
    public String index(HttpSession session,HttpServletRequest request) {
    	UserDetails user = (UserDetails) session.getAttribute("User_Login");
    	if(user == null)
    		return "redirect:/login";

    	Cookie[] cookies = request.getCookies();
    	if(!CustomMethods.iscookiesandsessionisvalid(user,cookies)) {
    		return "redirect:/login";
    	}

    	session.removeAttribute("ScreenDetails");    	
    	ScreenDetails details = new ScreenDetails();
    	details.setScreen_title("App Users Lists");
    	try {
    		details.setScreen_name("../livetracking/index.jsp");

    		details.setMain_menu("Live Tracking");
    		session.setAttribute("investigator_list", userDao.getActiveInvestigatorList(user));


    	}catch(Exception e) {
    		details.setScreen_name("../message/error.jsp");
    		details.setError_message1("Contct Administrator error :-"+e.getMessage());	
    		CustomMethods.logError(e);
    	}
    	session.setAttribute("ScreenDetails", details);
		return "common/templatecontent";
    }   
    
    
    @RequestMapping(value = "/userlocation", method = RequestMethod.POST)
    public @ResponseBody User_locations userlocation(HttpServletRequest request) 
    {
    	return caseDao.getLiveUserList(request.getParameter("investigator"));
    }    
    
    @RequestMapping(value = "/caselocation", method = RequestMethod.POST)
    public  @ResponseBody List<CaseDetails> caseLocation(HttpSession session)
    {
    	UserDetails user = (UserDetails) session.getAttribute("User_Login");
    	List<CaseDetails> caselocation=  caseDao.getLiveCaseList(user.getUsername());
		return caselocation;
    } 
    
}
    
 
