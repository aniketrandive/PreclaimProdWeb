 package com.preclaim.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.preclaim.config.CustomMethods;
import com.preclaim.dao.InvestigationTypeDao;
import com.preclaim.dao.UserDAO;
import com.preclaim.models.InvestigationType;
import com.preclaim.models.InvestigationTypeList;
import com.preclaim.models.ScreenDetails;
import com.preclaim.models.UserDetails;

@Controller
@RequestMapping(value = "/investigationType")
public class InvestigationTypeController {
	
    @Autowired
	private InvestigationTypeDao investigationTypeDao;
    
    @Autowired
    private UserDAO userDao;

    @RequestMapping(value = "/add", method = RequestMethod.GET)
    public String add(HttpSession session,HttpServletRequest request) {
    	UserDetails user = (UserDetails) session.getAttribute("User_Login");
    	if(user == null)
    		return "redirect:/login";

    	Cookie[] cookies = request.getCookies();
    	if(!CustomMethods.iscookiesandsessionisvalid(user,cookies)) {
    		return "redirect:/login";
    	}

    	List<String> permission =(ArrayList<String>)session.getAttribute("user_permission");
    	if(!permission.contains("investigationType"))
    		return "common/login";

    	session.removeAttribute("ScreenDetails");
    	ScreenDetails details = new ScreenDetails();
    	details.setScreen_title("Add Investigation Type");
    	try {
    		details.setScreen_name("../investigationType/addInvestigationType.jsp");

    		details.setMain_menu("Investigation Type");
    		details.setSub_menu1("Add Investigation Type");
    		details.setSub_menu2("Manage Investigation");
    		details.setSub_menu2_path("/investigationType/pending");
    		if(session.getAttribute("success_message") != null)
    		{
    			details.setSuccess_message1((String)session.getAttribute("success_message"));
    			session.removeAttribute("success_message");
    		}


    	}catch(Exception e) {
    		details.setScreen_name("../message/error.jsp");
    		details.setError_message1("Contct Administrator error :-"+e.getMessage());	
    		CustomMethods.logError(e);
    	}
    	session.setAttribute("ScreenDetails", details);
    	return "common/templatecontent";
    }
   
    @RequestMapping(value = "/pending",method = RequestMethod.GET)
    public String pending(HttpSession session, HttpServletRequest request) {
    	UserDetails user = (UserDetails) session.getAttribute("User_Login");
    	if(user == null)
    		return "redirect:/login";


    	Cookie[] cookies = request.getCookies();
    	if(!CustomMethods.iscookiesandsessionisvalid(user,cookies)) {
    		return "redirect:/login";
    	}

    	List<String> permission =(ArrayList<String>)session.getAttribute("user_permission");
    	if(!permission.contains("investigationType"))
    		return "common/login";

    	session.removeAttribute("ScreenDetails");
    	ScreenDetails details=new ScreenDetails();
    	details.setScreen_title("Pending Investigation Type");
    	try {
    		details.setScreen_name("../investigationType/pendingInvestigationType.jsp");

    		details.setMain_menu("Investigation Type");
    		details.setSub_menu1("Pending Investigation");
    		if(session.getAttribute("success_message") != null)
    		{
    			details.setSuccess_message1((String)session.getAttribute("success_message"));
    			session.removeAttribute("success_message");
    		}

    		List<InvestigationTypeList> pending_list= investigationTypeDao.investigationType_list(0);
    		session.setAttribute("pending_investigationType", pending_list);

    		if(request.getParameter("investigationtypeName")!= null && request.getParameter("investigationId") != null)
    		{
    			InvestigationTypeList investigationTypeList = new InvestigationTypeList();
    			investigationTypeList.setInvestigationId(Integer.parseInt(request.getParameter("investigationId")));
    			investigationTypeList.setInvestigationName(request.getParameter("investigationtypeName"));
    			session.setAttribute("investigationTypeList", investigationTypeList);
    		}


    	}catch(Exception e) {
    		details.setScreen_name("../message/error.jsp");
    		details.setError_message1("Contct Administrator error :-"+e.getMessage());	
    		CustomMethods.logError(e);
    	}
    	session.setAttribute("ScreenDetails", details);
    	return "common/templatecontent";
    }
    
    @RequestMapping(value="/active",method = RequestMethod.GET)
    public String active(HttpSession session,HttpServletRequest request) {
    	UserDetails user = (UserDetails) session.getAttribute("User_Login");
    	if(user == null)
    		return "redirect:/login";

    	Cookie[] cookies = request.getCookies();
    	if(!CustomMethods.iscookiesandsessionisvalid(user,cookies)) {
    		return "redirect:/login";
    	}

    	List<String> permission =(ArrayList<String>)session.getAttribute("user_permission");
    	if(!permission.contains("investigationType"))
    		return "common/login";

    	session.removeAttribute("ScreenDetails");
    	ScreenDetails details=new ScreenDetails();
    	details.setScreen_title("Active Investigation");
    	try {
    		details.setScreen_name("../investigationType/activeInvestigationType.jsp");;

    		details.setMain_menu("Investigation Type");
    		details.setSub_menu1("Active Investigation");
    		if(session.getAttribute("success_message") != null)
    		{
    			details.setSuccess_message1((String)session.getAttribute("success_message"));
    			session.removeAttribute("success_message");
    		}
    		List<InvestigationTypeList> active_list = investigationTypeDao.investigationType_list(1);
    		session.setAttribute("active_list", active_list);


    	}catch(Exception e) {
    		details.setScreen_name("../message/error.jsp");
    		details.setError_message1("Contct Administrator error :-"+e.getMessage());	
    		CustomMethods.logError(e);
    	}
    	session.setAttribute("ScreenDetails", details);
    	return "common/templatecontent";
    }
    
    @RequestMapping(value = "/deleteInvestigationType", method = RequestMethod.POST)
	public @ResponseBody String deleteInvestigationType(HttpSession session, HttpServletRequest request)
	{
		int InvestigationId = Integer.parseInt(request.getParameter("investigationId"));
		UserDetails user = (UserDetails) session.getAttribute("User_Login");
		String message = investigationTypeDao.deleteInvestigationType(InvestigationId);
		if(message.equals("****"))
		{
			session.setAttribute("success_message", "Investigation Type deleted successfully");
			userDao.activity_log("InvestigationType ", String.valueOf(InvestigationId), "DELETE", 
					user.getUsername());
		}
		return message;
	}
    
    @RequestMapping(value = "/addInvestigationType",method = RequestMethod.POST)
	public @ResponseBody String addInvestigationType(HttpSession session, HttpServletRequest request) 
	{	
		UserDetails user = (UserDetails) session.getAttribute("User_Login");
		String InvestigationTypeName = request.getParameter("InvestigationtypeName");
		if (CustomMethods.isStringContainsSpecialCharacter(request.getParameter("InvestigationtypeName")))
			return "InvestigationtypeName Remove Special charchters [-?*'\'<>{}/+$?()=%]";
		else {
		InvestigationType investigationType = new InvestigationType();
		investigationType.setInvestigationName(InvestigationTypeName);
		investigationType.setCreatedBy(user.getUsername());
		String message = investigationTypeDao.add_investigationType(investigationType);
		if(message.equals("****"))
		{
			session.setAttribute("success_message", "Investigation Type added successfully");
			userDao.activity_log("InvestigationType", InvestigationTypeName, "ADD", user.getUsername());
		}
		return message;
		}
	}
	
	@RequestMapping(value = "/updateInvestigationType",method = RequestMethod.POST)
	public @ResponseBody String updateInvestigationType(HttpSession session, HttpServletRequest request) 
	{	
		int InvestigationId = Integer.parseInt(request.getParameter("investigationId"));
		System.out.println(InvestigationId);
		String InvestigationType = request.getParameter("investigationtypeName");
		System.out.println(InvestigationType);
		if (CustomMethods.isStringContainsSpecialCharacter(request.getParameter("investigationtypeName")))
			return "InvestigationtypeName Remove Special charchters [-?*'\'<>{}/+$?()=%]";
		else {
		UserDetails user = (UserDetails) session.getAttribute("User_Login");
		String message = investigationTypeDao.updateInvestigationType(InvestigationId, InvestigationType);
		if(message.equals("****"))
		{
			session.setAttribute("success_message", "Investigation Type updated successfully");
			userDao.activity_log("InvestigationType", InvestigationType, "UPDATE", user.getUsername());
		}
		return message;
		}
	}
	
	@RequestMapping(value = "/updateInvestigationTypeStatus",method = RequestMethod.POST)
	public @ResponseBody String updateInvestigationTypeStatus(HttpSession session, HttpServletRequest request) 
	{	
		int InvestigationId=Integer.parseInt(request.getParameter("investigationId"));	
		int status=Integer.parseInt(request.getParameter("status"));
		UserDetails user = (UserDetails) session.getAttribute("User_Login");
		String message = investigationTypeDao.updateInvestigationTypeStatus(InvestigationId, status);
		if(message.equals("****"))
		{
			session.setAttribute("success_message", "Investigation Type status changed successfully");
			userDao.activity_log("InvestigationType", String.valueOf(InvestigationId), 
					status == 1 ? "ACTIVE" : "DEACTIVE", user.getUsername());
		}
		return message;
	}
	
}
