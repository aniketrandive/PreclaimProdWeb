package com.preclaim.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.preclaim.config.CustomMethods;
import com.preclaim.dao.CaseSubstatusDao;
import com.preclaim.dao.UserDAO;
import com.preclaim.models.CaseSubStatus;
import com.preclaim.models.ScreenDetails;
import com.preclaim.models.UserDetails;

@Controller
@RequestMapping(value = "/caseSubStatus")
public class CaseSubStatusController {

	@Autowired
	CaseSubstatusDao caseSubstatusDao;
	
    @Autowired
    private UserDAO userDao;
	
    @RequestMapping(value = "/add", method = RequestMethod.GET)
    public String add(HttpSession session,HttpServletRequest request) {
    	UserDetails user = (UserDetails) session.getAttribute("User_Login");
    	if(user == null)
    		return "redirect:/login";

    	Cookie[] cookies = request.getCookies();
    	if(!CustomMethods.iscookiesandsessionisvalid(user,cookies)) {
    		return "redirect:/login";
    	}

    	List<String> permission =(ArrayList<String>)session.getAttribute("user_permission");
    	if(!permission.contains("caseSubStatus"))
    		return "common/login";

    	session.removeAttribute("ScreenDetails");
    	ScreenDetails details = new ScreenDetails();
    	details.setScreen_title("Add Case Sub-Status");
    	try {
    		details.setScreen_name("../caseSubStatus/addCaseSubStatus.jsp");
    		details.setMain_menu("Case Sub-Status");
    		details.setSub_menu1("Add Case Sub-Status");
    		details.setSub_menu2("Manage Case Sub-Status");
    		details.setSub_menu2_path("/caseSubStatus/pending");
    		session.setAttribute("user_roles", userDao.role_lists());
    		if(session.getAttribute("success_message") != null)
    		{
    			details.setSuccess_message1((String)session.getAttribute("success_message"));
    			session.removeAttribute("success_message");
    		}

    		if(request.getParameter("caseSubStatusId") != null )
    			session.setAttribute("caseSubStatus",caseSubstatusDao.getCaseSubStatusById(Integer.parseInt(request.getParameter("caseSubStatusId"))));



    	}catch(Exception e) {
    		details.setScreen_name("../message/error.jsp");
    		details.setError_message1("Contct Administrator error :-"+e.getMessage());	
    		CustomMethods.logError(e);
    	}
    	session.setAttribute("ScreenDetails", details);
    	return "common/templatecontent";
    }
   
    @RequestMapping(value="/active",method = RequestMethod.GET)
    public String active(HttpSession session,HttpServletRequest request) {
    	UserDetails user = (UserDetails) session.getAttribute("User_Login");
    	if(user == null)
    		return "redirect:/login";

    	Cookie[] cookies = request.getCookies();
    	if(!CustomMethods.iscookiesandsessionisvalid(user,cookies)) {
    		return "redirect:/login";
    	}

    	List<String> permission =(ArrayList<String>)session.getAttribute("user_permission");
    	if(!permission.contains("caseSubStatus"))
    		return "common/login";
    	session.removeAttribute("ScreenDetails");
    	ScreenDetails details=new ScreenDetails();
    	details.setScreen_title("Active Case Status & Sub-status");
    	try {
    		details.setScreen_name("../caseSubStatus/activeCaseSubStatus.jsp");;

    		details.setMain_menu("Case Sub-Status");
    		details.setSub_menu1("Active Case Sub-Status");
    		if(session.getAttribute("success_message") != null)
    		{
    			details.setSuccess_message1((String)session.getAttribute("success_message"));
    			session.removeAttribute("success_message");
    		}
    		List<CaseSubStatus> active_list = caseSubstatusDao.getActiveCaseSubStatus_list();
    		session.setAttribute("active_list", active_list);


    	}catch(Exception e) {
    		details.setScreen_name("../message/error.jsp");
    		details.setError_message1("Contct Administrator error :-"+e.getMessage());	
    		CustomMethods.logError(e);
    	}
    	session.setAttribute("ScreenDetails", details);
    	return "common/templatecontent";
    }
    
    @RequestMapping(value = "/addCaseSubStatus",method = RequestMethod.POST)
	public @ResponseBody String addCaseSubStatus(HttpSession session, HttpServletRequest request) 
	{	
		UserDetails user = (UserDetails) session.getAttribute("User_Login");
		String caseSubStatus =request.getParameter("caseSubStatus"); 
		CaseSubStatus case_Substatus = new CaseSubStatus();
		case_Substatus.setCase_status(request.getParameter("caseStatus"));
		case_Substatus.setFromRole(request.getParameter("fromRole"));
		case_Substatus.setToRole(request.getParameter("toRole"));
		case_Substatus.setCaseSubStatus(caseSubStatus);
		if (CustomMethods.isStringContainsSpecialCharacter(request.getParameter("caseSubStatus")))
			return "caseSubStatus Remove Special charchters [-?*'\'<>{}/+$?()=%]";
		if (CustomMethods.isStringContainsSpecialCharacter(request.getParameter("fromRole")))
			return "fromRole Remove Special charchters [-?*'\'<>{}/+$?()=%]";
		if (CustomMethods.isStringContainsSpecialCharacter(request.getParameter("toRole")))
			return "toRole Remove Special charchters [-?*'\'<>{}/+$?()=%]";
		if (CustomMethods.isStringContainsSpecialCharacter(request.getParameter("caseStatus")))
			return "caseStatus Remove Special charchters [-?*'\'<>{}/+$?()=%]";
		else {
		String message = caseSubstatusDao.add_caseSubstatus(case_Substatus);
		if(message.equals("****"))
		{
			session.setAttribute("success_message", "Case Substatus added successfully");
			userDao.activity_log("CaseStatus", caseSubStatus, "ADD", user.getUsername());
		}
		return message;
		}
	}
	
    
    @RequestMapping(value = "/deleteCaseSubstatus", method = RequestMethod.POST)
	public @ResponseBody String deleteCaseSubstatus(HttpSession session, HttpServletRequest request)
	{
		int caseSubstatusId = Integer.parseInt(request.getParameter("caseSubStatusId"));
		UserDetails user = (UserDetails) session.getAttribute("User_Login");
		String message = caseSubstatusDao.deleteCaseSubStatus(caseSubstatusId);
		if(message.equals("****"))
		{
			session.setAttribute("success_message", "Case Sub-status deleted successfully");
			userDao.activity_log("Case Sub-status", String.valueOf(caseSubstatusId), "DELETE", 
					user.getUsername());
		}
		return message;
	}
    
    
	@RequestMapping(value = "/updateCaseSubStatus",method = RequestMethod.POST)
	public @ResponseBody String updateCaseSubStatus(HttpSession session, HttpServletRequest request) 
	{	
		int caseSubStatusId =  Integer.parseInt(request.getParameter("caseSubStatusId"));	
		String CaseStatus = request.getParameter("caseStatus");
		String caseSubStatus = request.getParameter("caseSubStatus");
		if (CustomMethods.isStringContainsSpecialCharacter(request.getParameter("caseSubStatus")))
			return "caseSubStatus Remove Special charchters [-?*'\'<>{}/+$?()=%]";
		if (CustomMethods.isStringContainsSpecialCharacter(request.getParameter("caseStatus")))
			return "caseStatus Remove Special charchters [-?*'\'<>{}/+$?()=%]";
		else {
        UserDetails user = (UserDetails) session.getAttribute("User_Login");
		String message = caseSubstatusDao.updateCaseSubStatus(caseSubStatusId, CaseStatus, caseSubStatus);
		if(message.equals("****"))
		{
			session.setAttribute("success_message", "Case Sub-status updated successfully");
			userDao.activity_log("Case Sub-status", CaseStatus, "UPDATE", user.getUsername());
		}
		return message;
		}
	}
	
}
