package com.preclaim.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.preclaim.config.CustomMethods;
import com.preclaim.dao.NatureOfInvestigationDao;
import com.preclaim.dao.UserDAO;
import com.preclaim.models.NatureOfInvestigation;
import com.preclaim.models.NatureOfInvestigationList;
import com.preclaim.models.ScreenDetails;
import com.preclaim.models.UserDetails;

@Controller
@RequestMapping(value = "/natureOfInvestigation")
public class NatureOfInvestigationController {

	@Autowired
	private NatureOfInvestigationDao natureOfInvestigationDaoImpl;
	
	@Autowired
	private UserDAO userDao;

	@RequestMapping(value = "/addNatureofInvestigation", method = RequestMethod.GET)
	public String addNatureofInvestigation(HttpSession session,HttpServletRequest request) {
		UserDetails user = (UserDetails) session.getAttribute("User_Login");
		if(user == null)
			return "redirect:/login";

		Cookie[] cookies = request.getCookies();
		if(!CustomMethods.iscookiesandsessionisvalid(user,cookies)) {
			return "redirect:/login";
		}

		List<String> permission =(ArrayList<String>)session.getAttribute("user_permission");
		if(!permission.contains("natureOfInvestigation"))
			return "common/login";
		session.removeAttribute("ScreenDetails");
		ScreenDetails details = new ScreenDetails();
		details.setScreen_title("Add Nature Of Investigation");
		try {
			details.setScreen_name("../natureOfInvestigation/addNatureOfInvestigation.jsp");

			details.setMain_menu("Nature Of Investigation");
			details.setSub_menu1("Add Nature of Investigation");
			details.setSub_menu2("Manage Nature of Investigation");
			details.setSub_menu2_path("/natureOfInvestigation/pendingNatureOfInvestigation");
			if(session.getAttribute("success_message") != null)
			{
				details.setSuccess_message1((String)session.getAttribute("success_message"));
				session.removeAttribute("success_message");
			}



		}catch(Exception e) {
			details.setScreen_name("../message/error.jsp");
			details.setError_message1("Contct Administrator error :-"+e.getMessage());	
			CustomMethods.logError(e);
		}
		session.setAttribute("ScreenDetails", details);
		return "common/templatecontent";
	}

	@RequestMapping(value = "/pendingNatureofInvestigation", method = RequestMethod.GET)
	public String pendingNatureofInvestigation(HttpSession session,HttpServletRequest request) {
		UserDetails user = (UserDetails) session.getAttribute("User_Login");
		if(user == null)
			return "redirect:/login";

		Cookie[] cookies = request.getCookies();
		if(!CustomMethods.iscookiesandsessionisvalid(user,cookies)) {
			return "redirect:/login";
		}

		List<String> permission =(ArrayList<String>)session.getAttribute("user_permission");
		if(!permission.contains("natureOfInvestigation"))
			return "common/login";
		session.removeAttribute("ScreenDetails");
		ScreenDetails details = new ScreenDetails();
		details.setScreen_title("Nature Of Investigation Lists");
		try {
			details.setScreen_name("../natureOfInvestigation/pendingNatureOfInvestigation.jsp");

			details.setMain_menu("Nature Of Investigation");
			details.setSub_menu1("Pending Nature Of Investigation");
			if(session.getAttribute("success_message") != null)
			{
				details.setSuccess_message1((String)session.getAttribute("success_message"));
				session.removeAttribute("success_message");
			}

			List<NatureOfInvestigationList> pendingInvestigationType = natureOfInvestigationDaoImpl.getNatureOfInvestigationList(0);
			session.setAttribute("pendingInvestigationType", pendingInvestigationType);

			if(request.getParameter("investigationId")!=null)
			{
				int investigationId = Integer.parseInt(request.getParameter("investigationId"));
				String investigationType = request.getParameter("investigationType");
				NatureOfInvestigation editNatureOfInvestigation = new NatureOfInvestigation(investigationId, investigationType);
				session.setAttribute("editInvestigation",editNatureOfInvestigation);
			}


		}catch(Exception e) {
			details.setScreen_name("../message/error.jsp");
			details.setError_message1("Contct Administrator error :-"+e.getMessage());	
			CustomMethods.logError(e);
		}
		session.setAttribute("ScreenDetails", details);
		return "common/templatecontent";
	}

	@RequestMapping(value = "/activeNatureofInvestigation", method = RequestMethod.GET)
	public String activeNatureofInvestigation(HttpSession session,HttpServletRequest request) {
		UserDetails user = (UserDetails) session.getAttribute("User_Login");
		if(user == null)
			return "redirect:/login";

		Cookie[] cookies = request.getCookies();
		if(!CustomMethods.iscookiesandsessionisvalid(user,cookies)) {
			return "redirect:/login";
		}

		List<String> permission =(ArrayList<String>)session.getAttribute("user_permission");
		if(!permission.contains("natureOfInvestigation"))
			return "common/login";
		session.removeAttribute("ScreenDetails");
		ScreenDetails details = new ScreenDetails();
		details.setScreen_title("Nature Of Investigation Lists");
		try {
			details.setScreen_name("../natureOfInvestigation/activeNatureOfInvestigation.jsp");

			details.setMain_menu("Nature Of Investigation");
			details.setSub_menu1("Active Nature Of Investigation");
			if(session.getAttribute("success_message") != null)
			{
				details.setSuccess_message1((String)session.getAttribute("success_message"));
				session.removeAttribute("success_message");
			}
			List<NatureOfInvestigationList> activeList = natureOfInvestigationDaoImpl.getNatureOfInvestigationList(1);
			session.setAttribute("active_list", activeList);


		}catch(Exception e) {
			details.setScreen_name("../message/error.jsp");
			details.setError_message1("Contct Administrator error :-"+e.getMessage());	
			CustomMethods.logError(e);
		}
		session.setAttribute("ScreenDetails", details);
		return "common/templatecontent";
	}

	@RequestMapping(value = "/addNatureOfInvestigation", method = RequestMethod.POST)
	public @ResponseBody String addInvestigation(HttpSession session, HttpServletRequest request) {
		UserDetails user = (UserDetails) session.getAttribute("User_Login");
		if (CustomMethods.isStringContainsSpecialCharacter(request.getParameter("natureOfInvestigationType")))
			return "natureOfInvestigationType Remove Special charchters [-?*'\'<>{}/+$?()=%]";
	
		else {
		NatureOfInvestigation natureOfInvestigation = new NatureOfInvestigation();
		natureOfInvestigation.setNature_of_investigationType(request.getParameter("natureOfInvestigationType"));
		natureOfInvestigation.setCreatedBy(user.getUsername());
		String message = natureOfInvestigationDaoImpl.addNatureOfInvestigation(natureOfInvestigation);
		if(message.equals("****"))
		{
			userDao.activity_log("NATURE OF INV", natureOfInvestigation.getNature_of_investigationType(), "ADD", 
				user.getUsername());
		}
		return message;
		}
	
	
	}
	
	@RequestMapping(value ="/updateNatureOfInvestigation",method = RequestMethod.POST )
    public @ResponseBody String updateInvestigation(HttpSession session, HttpServletRequest request) {
	 int natureOfInvestigationId = Integer.parseInt(request.getParameter("natureOfinvestigationId"));
	 String natureOfInvestigationType = request.getParameter("natureOfInvestigationType");
	 if (CustomMethods.isStringContainsSpecialCharacter(request.getParameter("natureOfInvestigationType")))
			return "natureOfInvestigationType Remove Special charchters [-?*'\'<>{}/+$?()=%]";
	 else {
	 System.out.println(natureOfInvestigationId+natureOfInvestigationType);
	 UserDetails user = (UserDetails) session.getAttribute("User_Login");
	 String message = natureOfInvestigationDaoImpl.updateNatureOfInvestigation(natureOfInvestigationType,
			 natureOfInvestigationId);
	 if(message.equals("****"))
	 {
		 session.setAttribute("success_message", "Nature of Investigation updated successfully");
		 userDao.activity_log("NATURE OF INV", natureOfInvestigationType, "UPDATE", user.getUsername());
	 }
	 return message;
	 }
	}
	
	@RequestMapping(value ="/deleteNatureOfInvestigationStatus",method = RequestMethod.POST )
    public @ResponseBody String deleteInvestigation(HttpSession session, HttpServletRequest request) {
	 int natureOfInvestigationId = Integer.parseInt(request.getParameter("natureOfInvestigationId"));
	 
     String message = natureOfInvestigationDaoImpl.deleteNatureOfInvestigation(natureOfInvestigationId);	
     UserDetails user = (UserDetails) session.getAttribute("User_Login");
     if(message.equals("****"))
     {
    	 session.setAttribute("success_message", "Nature of Investigation deleted successfully");
    	 userDao.activity_log("NATURE OF INV",String.valueOf(natureOfInvestigationId), "DELETE", 
    			 user.getUsername());
     }
     return message;
	}
	
	@RequestMapping(value = "/updateNatureOfInvestigationStatus",method = RequestMethod.POST)
	public @ResponseBody String updateCategoryStatus(HttpSession session, HttpServletRequest request) {
		int status = Integer.parseInt(request.getParameter("status"));
		int natureOfInvestigationId = Integer.parseInt(request.getParameter("natureOfInvestigationId"));
		UserDetails user = (UserDetails) session.getAttribute("User_Login");		 
		String message = natureOfInvestigationDaoImpl.updateNatureOfInvestigationStatus(natureOfInvestigationId, status);
		if(message.equals("****"))
		{
			session.setAttribute("success_message", "Nature of Investigation status changed successfully");
			userDao.activity_log("NATURE OF INV", String.valueOf(natureOfInvestigationId), status == 1 ? "ACTIVE" : "DEACTIVE", 
				user.getUsername());
		}
		return message;
	}
	  
   
}
