package com.preclaim.controller;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.preclaim.config.CustomMethods;
import com.preclaim.models.CaseDetails;

public class test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		CaseDetails caseid = new CaseDetails();
		caseid.setCaseId(12);
		String name = "";
		System.out.println(name = caseid.getCaseId()!=0 ? "True" : "False");
		
		String inputString = "Alive is Awesome";
        Pattern pattern = Pattern.compile("[-?*'\'<>{}/+$?()=%]");
        Matcher matcher = pattern.matcher(inputString);
//        boolean isStringContainsSpecialCharacter = matcher.find();
        if(!CustomMethods.isStringContainsSpecialCharacter(inputString)) 
        System.out.println("aniket"+matcher.find());
        
	}

}
