package com.preclaim.controller;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Base64.Encoder;
import java.util.List;

import javax.naming.NamingException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang.RandomStringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import com.preclaim.config.AuthenticateUser;
import com.preclaim.config.Config;
import com.preclaim.config.CustomMethods;
import com.preclaim.dao.LoginDAO;
import com.preclaim.dao.MailConfigDao;
import com.preclaim.dao.UserDAO;
import com.preclaim.models.MailConfig;
import com.preclaim.models.UserDetails;

@Controller
//@SessionAttributes({"User_Login","user_role","user_permission"})
public class LoginController {

	@Autowired
	LoginDAO dao;

	@Autowired
	UserDAO userDao;

	@Autowired
	MailConfigDao mailConfigDao;

	@Autowired
	Config config;

	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String login(HttpSession session,HttpServletRequest request,HttpServletResponse response) {
		session.setAttribute("config", config);
		response.setHeader("SET-COOKIE", "JSESSIONID=" + session.getId() + ";HttpOnly;SameSite=strict");
		return "common/login";
	}

	@RequestMapping(value = "/error", method = RequestMethod.GET)
	public String error(HttpSession session) {
		session.setAttribute("config", config);
		System.out.println("error");
		return "common/login";
	}

	@RequestMapping(value = "/login", method = RequestMethod.GET)
	public String login_method(HttpSession session, HttpServletResponse response) {
		if (session.getAttribute("config") == null)
			session.setAttribute("config", config);
		response.setHeader("SET-COOKIE", "JSESSIONID=" + session.getId() + ";HttpOnly ;SameSite=strict");
//		response.setHeader("X-Frame-Options","SAMEORIGIN");
//		response.setHeader("Content-Security-Policy","None");
		return "common/login";
	}

	@RequestMapping(value = "/logout", method = RequestMethod.GET)
	public String logout(HttpSession session) {
		session.removeAttribute("User_Login");
		session.removeAttribute("user_role");
		session.invalidate();
		
		return "redirect:/login";
	}

	@RequestMapping(value = "/login_validate", method = RequestMethod.POST)
	public @ResponseBody String login_validate(HttpSession session, HttpServletRequest request,
			HttpServletResponse response, ModelMap model) throws NamingException {
		String username = request.getParameter("username");
		String password = request.getParameter("password");
		String encodedPassword = Base64.getEncoder().encodeToString(password.getBytes());
		request.changeSessionId();

		if (CustomMethods.isStringContainsSpecialCharacter(username))
			return "username Remove Special charchters [-?*'\'<>{}/+$?()=%]";
		/*
		 * if (CustomMethods.isStringContainsSpecialCharacter(password)) return
		 * "password Remove Special charchters [-'\'<>{}/+()=%]";
		 */

		boolean validateFlag = false;
		UserDetails user = dao.checkUser(username);

		if (user == null)
			return "The entered Credentials was not connected to the account.";

		if (user.getStatus() == 0)
			return "User ID disabled. Kindly contact system administrator";
		/*
		 * if (!user.getAccount_type().equals(config.getSUPERVISOR())) return
		 * "Invalid credentials";
		 */
		if (config.getLDAP_AUTHENTICATION().equals("Y"))
		validateFlag = dao.NTLogin(username, password);
//			validateFlag= AuthenticateUser.NTLogin(username, password);
		else {
			if (user.getPassword().equals(encodedPassword))
				validateFlag = true;

		}
		if (validateFlag) {
//			model.addAttribute("User_Login", new UserDetails(user));
//			model.addAttribute("user_role",  userDao.getUserRole(new UserDetails(user).getAccount_type()));
//			model.addAttribute("user_permission",  userDao.retrievePermission(new UserDetails(user).getAccount_type()));
			System.out.println("session" + session.getId());
			response.setHeader("X-Frame-Options", "SAMEORIGIN");
			response.setHeader("Content-Security-Policy", "localhost:8081/pre-claim-investigation");
			response.setHeader("SET-COOKIE", "JSESSIONID=" + session.getId() + ";HttpOnly ;SameSite=strict");
			session.setAttribute("User_Login", new UserDetails(user));
			session.setAttribute("user_role", userDao.getUserRole(new UserDetails(user).getAccount_type()));
			List<String> user_permission = new ArrayList<>();
			session.setAttribute("user_permission",
					userDao.retrievePermission(new UserDetails(user).getAccount_type()));
			session.setMaxInactiveInterval(900);
			
			String remember_me = request.getParameter("remember_me");

			if (remember_me.equals("true")) {
				Cookie cookie_username = new Cookie("cHJlLWNsYWltLXVzZXI", username);
				Cookie cookie_password = new Cookie("cHJlLWNsYWltLXBhc3N3b3Jk", encodedPassword);
				cookie_username.setMaxAge(60 * 60 * 24 * 365 * 10);
				cookie_password.setMaxAge(60 * 60 * 24 * 365 * 10);
				cookie_username.setHttpOnly(true);
				cookie_password.setHttpOnly(true);
				cookie_password.setSecure(true);
				cookie_username.setSecure(true);
			

				response.addCookie(cookie_username);
				response.addCookie(cookie_password);
				
				
			}
			return "****";
		} else
			return "The password you entered is incorrect";
	}

	@RequestMapping(value = "/forgotpass", method = RequestMethod.GET)
	public String forgotpass(HttpSession session) {
		return "common/forgotpass";
	}

	@RequestMapping(value = "/uploadFile", method = RequestMethod.POST)
	public @ResponseBody String fileuploader(@RequestParam("file[]") ArrayList<MultipartFile> multipartFiles,
			HttpServletRequest request) {
		String prefix = request.getParameter("prefix");
		for (MultipartFile item : multipartFiles) {
			try {
				byte[] temp = item.getBytes();
				String filename = item.getOriginalFilename();
				filename = prefix == null ? filename : prefix + "_" + filename;
				Path path = Paths.get(config.getUpload_directory() + filename);
				Files.write(path, temp);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		return "****";
	}

	@RequestMapping(value = "/changePassword", method = RequestMethod.POST)
	public @ResponseBody String changePassword(HttpServletRequest request) {
		String username = request.getParameter("username");
		Encoder encoder = Base64.getEncoder();
		String pass = RandomStringUtils.random(6, true, true);
		String message;
		int coun = 0;
		if (CustomMethods.isStringContainsSpecialCharacter(username))
			return "username Remove Special charchters [-?*'\'<>{}/+$?()=%]";
		UserDetails user = dao.checkUser(username);
		if (user == null)
			return "Username not found";
		if (user.getUser_email().equals(""))
			return "Email ID not present. Kindly contact system administrator to reset the password";
		if (!(user.getAccount_type().equals("AGNSUP") || (user.getAccount_type().equals("INV"))))
			return "Forget password authority is not available";
		if (user.getCounter() == 5)
			return "Kindly contact with admin your acount is disable";

		MailConfig mail = mailConfigDao.getActiveConfig();
		if (mail == null)
			return "Mail ID not setup. Kindly contact system administrator";
		if (user.getCounter() < 5) {
			mail.setReceipent(user.getUser_email());
			mail.setSubject("Forgot Password - " + user.getUsername());
			user.setPassword(encoder.encodeToString(pass.getBytes()));
			mail.setMessageBody("Your resetted password is " + pass);
//		message = mailConfigDao.sendMail(mail);
			message = "****";
			if (!message.equals("****"))
				return message;
		}
		if (user.getCounter() < 5)
			coun = user.getCounter() + 1;

		message = dao.updatePassword(username, encoder.encodeToString(pass.getBytes()), coun);
		if (user.getCounter() < 5 && coun == 5) {
			userDao.updateUserStatus(user.getUserID(), 0, user.getUsername());
			userDao.activity_log("USER", String.valueOf(user.getUserID()),
					user.getStatus() == 1 ? "ACTIVE" : "DEACTIVE", user.getUsername());
		}
		return message;

	}

}
