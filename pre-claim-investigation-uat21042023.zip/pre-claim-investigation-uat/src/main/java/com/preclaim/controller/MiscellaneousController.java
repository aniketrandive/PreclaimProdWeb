package com.preclaim.controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletContext;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import com.preclaim.config.Config;
import com.preclaim.config.CustomMethods;
import com.preclaim.models.ScreenDetails;
import com.preclaim.models.UserDetails;

@Controller
@RequestMapping("miscellaneous")
public class MiscellaneousController {

	@Autowired
	Config config;
	
	@GetMapping("updateTemplate")
	public String updateTemplate(HttpSession session,HttpServletRequest request)
	{
		UserDetails user = (UserDetails) session.getAttribute("User_Login");
		if(user == null)
			return "redirect:/login";

		Cookie[] cookies = request.getCookies();
		if(!CustomMethods.iscookiesandsessionisvalid(user,cookies)) {
			return "redirect:/login";
		}

		List<String> permission =(ArrayList<String>)session.getAttribute("user_permission");
		if(!permission.contains("miscellaneous"))
			return "common/login";

		session.removeAttribute("ScreenDetails");
		ScreenDetails details = new ScreenDetails();
		details.setScreen_title("Update Template");
		try {
			details.setScreen_name("../miscellaneous/import_template.jsp");
			details.setMain_menu("Miscellaneous");			
			details.setSub_menu1("Update Template");


		}catch(Exception e) {
			details.setScreen_name("../message/error.jsp");
			details.setError_message1("Contct Administrator error :-"+e.getMessage());	
			CustomMethods.logError(e);
		}
		session.setAttribute("ScreenDetails", details);
		return "common/templatecontent";
	}
	
	@PostMapping("updateAppointmentLetter")
	public @ResponseBody String updateAppointmentLetter(
			@RequestParam("appointment_letter") MultipartFile appointment_letter)
	{
		Path path = Paths.get(config.getTemplate_directory() + "Appointment Letter.docx");
		try 
		{
			Files.write(path, appointment_letter.getBytes());
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
			CustomMethods.logError(e);
			return e.getMessage();
		}
		return "****";
	}
	
	@PostMapping("updateAuthorizationLetter")
	public @ResponseBody String updateAuthorizationLetter(
			@RequestParam("authorization_letter") MultipartFile authorization_letter)
	{
		Path path = Paths.get(config.getTemplate_directory() + "Authorization Letter.docx");
		try 
		{
			Files.write(path, authorization_letter.getBytes());
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
			CustomMethods.logError(e);
			return e.getMessage();
		}
		return "****";
	}
	
	@GetMapping("downloadAppointmentLetter")
	public void downloadAppointmentLetter(HttpServletRequest request,
			HttpServletResponse response)
	{
		try 
		{
			downloadFile(request, response, "Appointment Letter.docx");
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
			CustomMethods.logError(e);
		}
	}
	
	@GetMapping("downloadAuthorizationLetter")
	public void downloadAuthorizationLetter(HttpServletRequest request,
			HttpServletResponse response)
	{
		try 
		{
			downloadFile(request, response, "Authorization Letter.docx");
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
			CustomMethods.logError(e);
		}
	}
	
	
	private void downloadFile(HttpServletRequest request, HttpServletResponse response, String fileName)
            throws IOException {
    	
    	//Logic replicated from downloadFile() method.
        // get absolute path of the application
        ServletContext context = request.getSession().getServletContext();

    	String rootPath = config.getTemplate_directory() + fileName;
        File downloadFile = new File(rootPath);
        FileInputStream inputStream = new FileInputStream(downloadFile);

        // get MIME type of the file
        String mimeType = context.getMimeType(rootPath);
        if (mimeType == null) {
            // set to binary type if MIME mapping not found
            mimeType = "application/octet-stream";
        }
        System.out.println("MIME type: " + mimeType);

        // set content attributes for the response
        response.setContentType(mimeType);
        response.setContentLength((int) downloadFile.length());

        // set headers for the response
        String headerKey = "Content-Disposition";
        String headerValue = String.format("attachment; filename=\"%s\"", downloadFile.getName());
        response.setHeader(headerKey, headerValue);

        // get output stream of the response
        OutputStream outStream = response.getOutputStream();

        byte[] buffer = new byte[4096];
        int bytesRead = -1;

        // write bytes read from the input stream into the output stream
        while ((bytesRead = inputStream.read(buffer)) != -1) {
            outStream.write(buffer, 0, bytesRead);
        }

        inputStream.close();
        outStream.close();

    }
}
