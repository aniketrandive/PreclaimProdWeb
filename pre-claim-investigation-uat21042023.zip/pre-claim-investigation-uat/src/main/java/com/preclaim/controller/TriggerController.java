package com.preclaim.controller;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.preclaim.config.CustomMethods;
import com.preclaim.dao.TriggerDao;
import com.preclaim.dao.UserDAO;
import com.preclaim.models.ScreenDetails;
import com.preclaim.models.TriggerDepartment;
import com.preclaim.models.TriggerName;
import com.preclaim.models.UserDetails;


	@Controller
	@RequestMapping(value = "/trigger")
	public class TriggerController {

		@Autowired
		TriggerDao triggerDao;
		
		@Autowired
		UserDAO userDao;

		@RequestMapping(value = "/name", method = RequestMethod.GET)
		public String name(HttpSession session,HttpServletRequest request) {
			UserDetails user = (UserDetails) session.getAttribute("User_Login");
			if(user == null)
				return "redirect:/login";

			Cookie[] cookies = request.getCookies();
			if(!CustomMethods.iscookiesandsessionisvalid(user,cookies)) {
				return "redirect:/login";
			}

			List<String> permission =(ArrayList<String>)session.getAttribute("user_permission");
			if(!permission.contains("triggerName"))
				return "common/login";
			session.removeAttribute("ScreenDetails");
			ScreenDetails details = new ScreenDetails();
			details.setScreen_title("Add Trigger Name");
			try {
				details.setScreen_name("../Trigger/addTriggerName.jsp");

				details.setMain_menu("Trigger");
				details.setSub_menu1("Add Trigger Name");
				details.setSub_menu2("Manage Trigger Name");
				//details.setSub_menu2_path("/Trigger/addTriggerName");
				if(session.getAttribute("success_message") != null)
				{
					details.setSuccess_message1((String)session.getAttribute("success_message"));
					session.removeAttribute("success_message");
				}
				if(request.getParameter("triggerName") != null) {

					String TriggerName = request.getParameter("triggerName");
					TriggerName trigger = new TriggerName(TriggerName);
					session.setAttribute("TriggerName", trigger);
				}

				session.setAttribute("TriggerList", triggerDao.getAllTriggerNameList());


			}catch(Exception e) {
				details.setScreen_name("../message/error.jsp");
				details.setError_message1("Contct Administrator error :-"+e.getMessage());	
				CustomMethods.logError(e);
			}
			session.setAttribute("ScreenDetails", details);
			return "common/templatecontent";
		}

		@RequestMapping(value = "/department", method = RequestMethod.GET)
		public String department(HttpSession session,HttpServletRequest request) {
			UserDetails user = (UserDetails) session.getAttribute("User_Login");
			if(user == null)
				return "redirect:/login";

			Cookie[] cookies = request.getCookies();
			if(!CustomMethods.iscookiesandsessionisvalid(user,cookies)) {
				return "redirect:/login";
			}

			List<String> permission =(ArrayList<String>)session.getAttribute("user_permission");
			if(!permission.contains("triggerName"))
				return "common/login";
			session.removeAttribute("ScreenDetails");
			ScreenDetails details = new ScreenDetails();
			details.setScreen_title("Trigger Department");
			try {
				details.setScreen_name("../Trigger/addTriggerDepartment.jsp");

				details.setMain_menu("Trigger");
				details.setSub_menu1("Add Trigger Department");
				details.setSub_menu2("ManageTrigger Department");
				if(session.getAttribute("success_message") != null)
				{
					details.setSuccess_message1((String)session.getAttribute("success_message"));
					session.removeAttribute("success_message");
				}
				if (request.getParameter("triggerDepartment") !=null) {
					String TriggerDepartment = request.getParameter("triggerDepartment");
					TriggerDepartment triggerDepartment = new TriggerDepartment(TriggerDepartment);
					session.setAttribute("TriggerDepartment", triggerDepartment);
				}
				session.setAttribute("departmentList", triggerDao.getAllTriggerDepartmentList());	


			}catch(Exception e) {
				details.setScreen_name("../message/error.jsp");
				details.setError_message1("Contct Administrator error :-"+e.getMessage());	
				CustomMethods.logError(e);
			}
			session.setAttribute("ScreenDetails", details);
			return "common/templatecontent";
		}
		
		@RequestMapping(value = "/addTrigger", method = RequestMethod.POST)
		public @ResponseBody String addTrigger(HttpSession session, HttpServletRequest request) {
			UserDetails user = (UserDetails) session.getAttribute("User_Login");
			TriggerName triggerName = new TriggerName();
            triggerName.setTrigger_name(request.getParameter("triggerName"));
            triggerName.setUpdated_by(user.getUsername());
            String message = triggerDao.addTriggerName(triggerName);        
			if(message.equals("****"))
			{
				session.setAttribute("success_message", "Trigger Name added successfully");
				userDao.activity_log("TRIGGER NAME", triggerName.getTrigger_name(), "ADD", 
					user.getUsername());
			}
			return message;
		}
		
		@RequestMapping(value ="/updateTrigger",method = RequestMethod.POST )
	    public @ResponseBody String updateTrigger(HttpSession session, HttpServletRequest request) {
	     String triggerName = request.getParameter("triggerName");		
		 String triggerid = request.getParameter("triggerId");
	
		 String message = triggerDao.updateTriggerName(triggerName,triggerid);
		 UserDetails user = (UserDetails) session.getAttribute("User_Login");
         if(message.equals("****"))
		 {
			 session.setAttribute("success_message", "Trigger Name updated successfully");
			 userDao.activity_log("TRIGGER NAME", triggerName, "UPDATE", user.getUsername());
		 }
		 return message;
		}
		
		
		@RequestMapping(value ="/deleteTrigger",method = RequestMethod.POST )
	    public @ResponseBody String deleteTrigger(HttpSession session, HttpServletRequest request) {
	     String triggerName = request.getParameter("triggerName");
		 String message = triggerDao.deleteTriggerName(triggerName);
		 UserDetails user = (UserDetails) session.getAttribute("User_Login");
         if(message.equals("****"))
		 {
			 session.setAttribute("success_message", "Trigger Name deleted successfully");
			 userDao.activity_log("TRIGGER NAME", triggerName, "Delete", user.getUsername());
		 }
		 return message;
		}
		
		@RequestMapping(value = "/updateTriggerStatus",method = RequestMethod.POST)
		public @ResponseBody String updateTriggerStatus(HttpSession session, HttpServletRequest request) {
			String status = request.getParameter("status");
			String triggerName = request.getParameter("triggerName");
			UserDetails user = (UserDetails) session.getAttribute("User_Login");		 
			String message = triggerDao.updateTriggerNameStatus(triggerName, status);
			if(message.equals("****"))
			{
				session.setAttribute("success_message", "Trigger status changed successfully");
				userDao.activity_log("TRIGGER NAME", triggerName, status.equals("1") ? "ACTIVE" : "DEACTIVE", 
					user.getUsername());
			}
			return message;
		}
		
		
		//department
		
		@RequestMapping(value = "/addDepartment", method = RequestMethod.POST)
		public @ResponseBody String addDepartment(HttpSession session, HttpServletRequest request) {
			UserDetails user = (UserDetails) session.getAttribute("User_Login");
			TriggerDepartment triggerDepartment = new TriggerDepartment();
			triggerDepartment.setTrigger_dept(request.getParameter("triggerDepartment"));
			triggerDepartment.setUpdated_by(user.getUsername());
            String message = triggerDao.addTriggerDepartment(triggerDepartment);        
			if(message.equals("****"))
			{
				session.setAttribute("success_message", " Trigger Department added successfully");
				userDao.activity_log("TRIGGER DEPARTMENT", triggerDepartment.getTrigger_dept(), "ADD", 
					user.getUsername());
			}
			return message;
		}
		
		@RequestMapping(value ="/updateDepartment",method = RequestMethod.POST )
	    public @ResponseBody String updateDepartment(HttpSession session, HttpServletRequest request) {
	     String triggerDepartment = request.getParameter("triggerDepartment");		
		 String departmentid = request.getParameter("departmentId");
	
		 String message = triggerDao.updateTriggerDepartment(triggerDepartment,departmentid);
		 UserDetails user = (UserDetails) session.getAttribute("User_Login");
         if(message.equals("****"))
		 {
			 session.setAttribute("success_message", "Trigger Department updated successfully");
			 userDao.activity_log("TRIGGER DEPARTMENT", triggerDepartment, "UPDATE", user.getUsername());
		 }
		 return message;
		}
		
		
		@RequestMapping(value ="/deleteDepartment",method = RequestMethod.POST )
	    public @ResponseBody String deleteDepartment(HttpSession session, HttpServletRequest request) {
	     String triggerDepartment = request.getParameter("triggerDepartment");
		 String message = triggerDao.deleteTriggerDepartment(triggerDepartment);
		 UserDetails user = (UserDetails) session.getAttribute("User_Login");
         if(message.equals("****"))
		 {
			 session.setAttribute("success_message", "Trigger Department deletd successfully");
			 userDao.activity_log("TRIGGER DEPARTMENT", triggerDepartment, "Delete", user.getUsername());
		 }
		 return message;
		}
		
		@RequestMapping(value = "/updateDepartmentStatus",method = RequestMethod.POST)
		public @ResponseBody String updateDepartmentStatus(HttpSession session, HttpServletRequest request) {
			String status = request.getParameter("status");
			String triggerDepartment = request.getParameter("triggerDepartment");
			UserDetails user = (UserDetails) session.getAttribute("User_Login");		 
			String message = triggerDao.updateTriggerDepartmentStatus(triggerDepartment, status);
			if(message.equals("****"))
			{
				session.setAttribute("success_message", "Trigger Department status changed successfully");
				userDao.activity_log("TRIGGER DEPARTMENT", triggerDepartment, status.equals("1") ? "ACTIVE" : "DEACTIVE", 
					user.getUsername());
			}
			return message;
		}
		
		

}
