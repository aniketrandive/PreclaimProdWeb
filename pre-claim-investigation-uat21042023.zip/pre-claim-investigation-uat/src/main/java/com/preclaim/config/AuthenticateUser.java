package com.preclaim.config;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;

import javax.naming.NamingException;

import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.ssl.SSLContextBuilder;
import org.apache.http.ssl.TrustStrategy;

public class AuthenticateUser {

	public static boolean NTLogin(String username, String password) throws NamingException {

//		boolean isValidUser = false;
//		String userid ="\""+"osaah02"+"\"";
//		String userid =username;
//		String pass =password;
//		System.out.println(req);
//		String encodedpass= test.encrypt(pass);
//		String req="\""+encodedpass+"\"";
//		String req="\""+encodedpass+"\"";
//		String reqpass ="{\"appId\":\"GCUBE\",\"userId\":"+userid+",\"password\":"+req+"}";
//		System.out.println(reqpass);

		boolean isValidUser = false;
		String userid = username;
		String pass = password;

		//Will encrypt the pass and encoded value
		String encodedpass = test.encrypt(pass);

		try {

			org.apache.http.client.HttpClient client = createClient();
			//set APi URL in request
			HttpPost postRequest = new HttpPost("https://naaf.tataaia.com/SISOM/Authenticate"); // https://naafuat.tataaia.com/SISOM/Authenticate

			postRequest.setHeader("Authorization", "e0AG5Uq836GsIPxQNNS70A7QsR1rkmz7m/vfYfobjPGihhd+4ogLRR7hjFmFyMmF"); // e0AG5Uq836GsIPxQNNS70A7QsR1rkmz7m/vfYfobjPGihhd+4ogLRR7hjFmFyMmF

			StringEntity input = new StringEntity(
					"{\"appId\":\"GCUBE\",\"userId\":\"" + userid + "\",\"password\":\"" + encodedpass + "\"}");

			input.setContentType("application/json");

			postRequest.setEntity(input);

			HttpResponse response = client.execute(postRequest);

			int returnCode = response.getStatusLine().getStatusCode();

			BufferedReader br = new BufferedReader(new InputStreamReader((response.getEntity().getContent())));

			String output;

			StringBuilder builder = new StringBuilder();

			while ((output = br.readLine()) != null) {

				builder.append(output);

			}

			String resp = builder.toString();

			org.json.JSONObject jsonResp = new org.json.JSONObject(resp);

			if (jsonResp.has("isValidUser") && jsonResp.get("isValidUser").toString().equals("true")) {

				isValidUser = true;
				System.out.println("in");
			}

			System.out.println(isValidUser);

		} catch (Exception e) {

			e.printStackTrace();

		}
		return isValidUser;
	}

	public static CloseableHttpClient createClient() {

		try {

			SSLContextBuilder builder = new SSLContextBuilder();

			builder.useProtocol("TLSv1.2");

			builder.loadTrustMaterial(null, new TrustStrategy() {

				@Override

				public boolean isTrusted(X509Certificate[] chain, String authType) throws CertificateException {

					return true;

				}

			});

			SSLConnectionSocketFactory sslsf = new SSLConnectionSocketFactory(

					builder.build());

			HttpClientBuilder hcBuilder = HttpClients.custom();

			// HttpHost httpProxy = new HttpHost(prop.getProxyIP(),
			// Integer.parseInt(prop.getProxyPort()));

			// DefaultProxyRoutePlanner routePlanner = new
			// DefaultProxyRoutePlanner(httpProxy);

			// hcBuilder.setRoutePlanner(routePlanner);

			CloseableHttpClient httpclient = hcBuilder

					.setSSLSocketFactory(sslsf).build();

			return httpclient;

		} catch (Exception e) {

			throw new RuntimeException(e);

		}

	}

}
