package com.preclaim.config;
import java.util.Arrays;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.http.Cookie;

import com.preclaim.models.UserDetails;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class CustomMethods {
	
	public static String sepcical_char = "[#‘^]";
	
	public static List<String> importCaseHeader()
	{
		List<String> header_list = (List<String>) Arrays.asList(
				"Policy Number", "Nature of Investigation", "Investigation Type","Issued Date",
				"Insured Name","Insured Contact Number", "Insured DOD", "Insured DOB","Gender", "Sum Assured",
				"Insured City", "Nominee Name", "Nominee Mob", "Nominee Address",
				"Insured Pincode", "Insured Address", "Trigger Name", "Trigger Department","Remark");
		return header_list;
	}
	
	
	public static List<String> importCDPCaseHeader()
	{
		List<String> header_list = (List<String>) Arrays.asList(
				"Policy Number", "Nature of Investigation", "Investigation Type","Issued Date",
				"Insured Name","Insured Contact Number", "Insured DOD", "Insured DOB","Gender", "Sum Assured",
				"Insured City", "Nominee Name", "Nominee Mob", "Nominee Address",
				"Insured Pincode", "Insured Address","Remark");
		return header_list;
	}
	
	public static void logError(Exception e)
	{
		log.error("Exception occurred ------ #####", e);	
	}
	
	public static boolean isStringContainsSpecialCharacter(String string) {
		
		Pattern pattern = Pattern.compile("[#‘^]");
        Matcher matcher = pattern.matcher(string);
		
		return matcher.find();	
	}

public static boolean iscookiesandsessionisvalid(UserDetails user,Cookie[] cookies) {
	String username = "";
	String password= "";
	if(cookies != null)
	{
		for(int i = 0; i < cookies.length ;i++)
		{
			if(cookies[i].getName().equals("cHJlLWNsYWltLXVzZXI")){
				username = cookies[i].getValue();}
			}
		if(user.getUsername().equalsIgnoreCase(username)) {
			return true;
		}	
		
		return true;
	}
	return true;
	}
	
	
}
