//package com.preclaim.service;
//
//import javax.servlet.http.HttpServletRequest;
//import javax.servlet.http.HttpSession;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.data.domain.Page;
//import org.springframework.data.domain.PageRequest;
//import org.springframework.data.domain.Pageable;
//import org.springframework.stereotype.Service;
//import org.springframework.web.bind.annotation.RequestBody;
//import org.springframework.web.bind.annotation.ResponseBody;
//
//import com.preclaim.config.Config;
//import com.preclaim.entity.Case_lists;
//import com.preclaim.entity.Data;
//import com.preclaim.entity.LoginRequest;
//import com.preclaim.models.Location;
//import com.preclaim.repository.CaselistsPagingRepository;
//import com.preclaim.repository.CaselistsRepository;
//
//@Service
//public class CaseListService {
//	
//	@Autowired
//	CaselistsPagingRepository   caserepo;
//	
//	@Autowired
//	Config config;
//	
//
//
//	public Page<Case_lists> getPedingDatapagination(HttpServletRequest request, HttpSession session) {
//		
//		/*
//		 * UserDetails user = (UserDetails) session.getAttribute("User_Login"); Location
//		 * location = locationDao.getActiveLocationList(user.getCity());
//		 */
//			
//		Location location = locationDao.getActiveLocationList(user.getCity());
//			System.err.println("inside ADMIN");
//			int pagen = pagenumber.getPagenumber();
//			Pageable Page=	PageRequest.of(pagen, 25);
//			
//			Page<Case_lists>  case1 = caserepo.getCaselistsAdmin(Page);
//			
//			
//			if (user.getAccount_type().equalsIgnoreCase(config.getADMIN())) {
//				System.err.println("inside ADMIN");
//		    case1 = caserepo.getCaselistsAdmin(Page);
//		}
//			else if (user.getAccount_type().equalsIgnoreCase(config.getREGIONAL_MANAGER())) {
//				System.err.println("inside REGIONAL_MANAGER");
//				System.err.println("user.getUsername(), user.getAccount_type(), location.getZone()"+user.getUsername()+" "+user.getAccount_type()+" "+ location.getZone());
//			   case1 = caserepo.getCaselistsRM(user.getUsername(), user.getAccount_type(), location.getZone());
//				//case1 = caserepo.getCaselistsRM(user.getUsername(),location.getZone());
//			}
//			else {
//				System.err.println("inside user");
//				 case1 = caserepo.getCaselists(user.getUsername());
//			}
//			
//			
//			
//			
//			
//			
//			
//			
//			
//		
//		 return case1;
//	
//	
//	
//	}	
//}
