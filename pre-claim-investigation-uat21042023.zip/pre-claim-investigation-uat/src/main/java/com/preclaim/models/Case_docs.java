package com.preclaim.models;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class Case_docs {

	private long caseId = 0;
	private String doc_type = "";
	private String doc_name = "";
	private String created_by = "";
	private String created_on = "";
	private String updated_by = "";
	private UserDetails userdetails ;
}
