package com.preclaim.models;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class TriggerDepartment {

	private String trigger_dept = "";
	private String status = "";
	private String updated_by = "";
	private String updated_date = "";
	
	
	public TriggerDepartment(String Triggerdepartment) {
		this.trigger_dept = Triggerdepartment;
	}
}
