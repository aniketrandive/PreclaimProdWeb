package com.preclaim.models;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class Case_payment {

	private long caseId = 0;
	private String userId = "";
	private double fees = 0;
	private String created_by = "";
	private String created_date = "";
	
}
