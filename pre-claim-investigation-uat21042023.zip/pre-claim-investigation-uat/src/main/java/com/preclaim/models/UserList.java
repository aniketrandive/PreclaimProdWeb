package com.preclaim.models;

import java.util.Base64;
import java.util.Base64.Decoder;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class UserList {

	private int srno = 0;
	private int user_id = 0;
	private String full_name = "";
	private String account_type = "";
	private String account_code = "";
	private String username = "";
	private String user_email = "";
	private String password = "";
	private int user_status = 0;
	
	public void decodePassword(String password)
	{
		Decoder decoder = Base64.getDecoder();
		this.password = new String(decoder.decode(password));
	}
}
