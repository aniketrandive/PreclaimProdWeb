package com.preclaim.models;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class BillManagementList {

	private int srNo = 0;
	private long caseID = 0;
	private String policyNumber = "";
	private String nature_of_investigationType = "";
	private String investigationType = "";
	private String supervisorID = "";
	private String SupervisorName = "";
	private String UpdatedDate = "";
	private double Charges = 0;
	
}
