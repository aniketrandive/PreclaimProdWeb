package com.preclaim.models;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@ToString
@NoArgsConstructor
public class RegionwiseList {
	
	private String investigator  = "";
	private int clean = 0;
	private int notClean = 0;
	private int piv = 0;
	private int wip = 0;
	private int total = 0;
	private float notCleanRate = 0;
	
	public RegionwiseList(String investigator, int clean, int notClean, int piv, int wip) {
		super();
		this.investigator = investigator;
		this.clean = clean;
		this.notClean = notClean;
		this.piv = piv;
		this.wip = wip;
		this.total = clean + notClean + piv + wip;
		this.notCleanRate = notClean *100 / total;
	}
}
