package com.preclaim.models;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class CaseDetails {

	private long caseId = 0;
	private String policyNumber = "";
	private int natureOfInvestigationId = 0;
	private String natureOfInvestigationCategory = "";
	private String issuedDate = "";
	private String insuredMob = "";
	private String insuredName = "";
	private String insuredDOD = "";
	private String insuredDOB = "";
	private String dateOfDiagnosis = "";
	private String gender = "";
	private double sumAssured = 0.0;
	private String investigationType = "";
	private int locationId = 0;
	private String pincode = "";
	private String claimantCity = "";
	private String claimantZone = "";
	private String claimantState = "";
	private String caseStatus = "";
	private String nominee_name = "";
	private String nomineeContactNumber = "";
	private String nominee_address = "";
	private String insured_address = "";
	private String case_description = "";
	private String longitude = "";
	private String latitude = "";
	private String approvedStatus = "";
	private String assignerRole = "";
	private String assignerName = "";
	private String assignerStatus = "";
	private String assignerRemarks = "";
	private String createdBy = "";
	private String createdDate = "";
	private String updatedDate = "";
	private String updatedBy = "";
	private String caseSubStatus = "";
	private String notCleanCategory = "";
    private String triggerName = "";
    private String trigger_dept = "";
    private String disposition = "";
}
