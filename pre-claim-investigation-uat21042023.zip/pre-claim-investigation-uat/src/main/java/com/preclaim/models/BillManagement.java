package com.preclaim.models;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class BillManagement {

	private long caseID = 0;
	private String policyNumber = "";
	private int investigationId= 0;
	private String initimationType= "";
	private String supervisorID= "";
	private String SupervisorName= "";
	private double Charges= 0;
	private String createdBy= "";
	private String createdDate= "";
	private String updatedDate= "";
	private String updatedBy= "";
}
