package com.preclaim.models;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class ScreenDetails {

	private String screen_name = "";
	private String screen_title = "";
	private String main_menu = "";
	private String sub_menu1 = "";
	private String sub_menu2 = "";
	private String sub_menu2_path = "";
	private String error_message1 = "";
	private String error_message2 = "";
	private String success_message1 = "";
	private String success_message2 = "";

		
}
