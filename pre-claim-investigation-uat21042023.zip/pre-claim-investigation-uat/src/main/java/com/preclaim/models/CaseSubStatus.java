package com.preclaim.models;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class CaseSubStatus {

	private long id = 0;
	private String fromRole = "";
	private String toRole = "";
	private String Case_status = "";
	private String caseSubStatus= "";
	private String user_action = "";
	private String role_code = "";
}
