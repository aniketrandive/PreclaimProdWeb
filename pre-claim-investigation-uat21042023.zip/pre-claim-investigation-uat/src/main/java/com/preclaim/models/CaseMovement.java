package com.preclaim.models;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class CaseMovement {

	private long caseId = 0;
	private String fromId = "";
	private String toId = "";
	private String caseStatus = "";
	private String remarks = "";
	private String createdDate = "";
	private String updatedDate = "";
	private String toRole = "";
	private String zone = "";

	public CaseMovement(long caseId, String fromId, String toId, String caseStatus, String remarks, String toRole) {
		super();
		this.caseId = caseId;
		this.fromId = fromId;
		this.toId = toId;
		this.caseStatus = caseStatus;
		this.remarks = remarks;
		this.toRole = toRole;

	}

	

}
