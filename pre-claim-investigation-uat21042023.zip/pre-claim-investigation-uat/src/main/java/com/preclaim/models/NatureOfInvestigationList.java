package com.preclaim.models;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class NatureOfInvestigationList {

	private int srNo  = 0;
	private int nature_of_investigationId = 0;
	private String nature_of_investigationType = "";
	private int createdBy = 0;
	private int updatedBy = 0;
	private int status = 0;  
}

