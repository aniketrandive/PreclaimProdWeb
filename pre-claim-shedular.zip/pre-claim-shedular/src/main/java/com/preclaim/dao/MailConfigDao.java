package com.preclaim.dao;

import java.io.FileOutputStream;
import java.sql.ResultSet;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Properties;

import javax.activation.DataHandler;
import javax.activation.FileDataSource;
import javax.mail.Authenticator;
import javax.mail.BodyPart;
import javax.mail.Message;
import javax.mail.Multipart;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import javax.sql.DataSource;

import org.apache.poi.openxml4j.opc.OPCPackage;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFParagraph;
import org.apache.poi.xwpf.usermodel.XWPFRun;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.preclaim.config.Config;
import com.preclaim.config.CustomMethods;
import com.preclaim.models.CaseDetails;
import com.preclaim.models.MailConfig;
import com.preclaim.models.MailConfigList;
import com.preclaim.models.UserDetails;
@Component
public class MailConfigDao{

	@Autowired
	DataSource datasource;

	@Autowired
	private JdbcTemplate template;

	@Autowired
	Config config;
	
	public void setTemplate(JdbcTemplate template) {
		this.template = template;
	}

	String sql = "";
	
	public String add(MailConfigList mailConfig) {
		try 
		{
			String sql = "INSERT INTO mail_config(username, password, outgoingServer, outgoingPort, "
					+ "encryptionType, status, createdBy, created_on, updatedBy, updated_on)"
					+ "VALUES(?, ?, ?, ? ,? , 0, ?, getDate(), '', getDate())";
			template.update(sql, mailConfig.getUsername(), mailConfig.getPassword(), mailConfig.getOutgoingServer(),
					mailConfig.getOutgoingPort(), mailConfig.getEncryptionType(), mailConfig.getCreatedBy());
			return "****";
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
			CustomMethods.logError(e);
			return e.getMessage();
		}
	}

	
	public List<MailConfigList> getMailConfigList(int status) {
		try {
			String sql = "";
			if (status == 0)
				sql = "SELECT * FROM mail_config where status = 0";
			else
				sql = "SELECT * FROM mail_config where status = 1 or status = 2";
			return template.query(sql, (ResultSet rs, int rowNum) -> {

				MailConfigList mailConfig = new MailConfigList();
				mailConfig.setMailConfigId(rs.getInt("mailConfigId"));
				mailConfig.setUsername(rs.getString("username"));
				mailConfig.setPassword(rs.getString("password"));
				mailConfig.setOutgoingServer(rs.getString("outgoingServer"));
				mailConfig.setOutgoingPort(rs.getInt("outgoingPort"));
				mailConfig.setEncryptionType(rs.getString("encryptionType"));
				mailConfig.setStatus(rs.getInt("status"));
				return mailConfig;
			});
		} catch (Exception e) {
			e.printStackTrace();
			CustomMethods.logError(e);
			return null;
		}
	}

	
	public String delete(int mailConfigId) {
		try 
		{
			sql = "insert into audit_mail_config select * from mail_config where mailConfigId = ?";
			template.update(sql, mailConfigId);
			sql = "DELETE FROM mail_config where mailConfigId = ?";
			template.update(sql, mailConfigId);
			return "****";
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
			CustomMethods.logError(e);
			return e.getMessage();
		}
	}

	
	public String update(MailConfigList mailConfig) {
		try 
		{
			sql = "insert into audit_mail_config select * from mail_config where mailConfigId = ?";
			template.update(sql, mailConfig.getMailConfigId());
			
			String sql = "UPDATE mail_config SET username = ?, password = ?, outgoingServer = ?, "
					+ "outgoingPort = ?, encryptionType = ?, updatedBy = ?, updated_on = getDate() where "
					+ "mailConfigId = ?";
			template.update(sql, mailConfig.getUsername(), mailConfig.getPassword(), mailConfig.getOutgoingServer(),
					mailConfig.getOutgoingPort(), mailConfig.getEncryptionType(), mailConfig.getUpdatedBy(),
					mailConfig.getMailConfigId());
			return "****";
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
			CustomMethods.logError(e);
			return "Error updating configuration. Kindly contact system administrator";
		}
	}

	
	public String updateStatus(int mailConfigId, int status, String username) {
		try 
		{
			
			if (status == 1) 
			{
				sql = "SELECT count(*) FROM mail_config where status = 1";
				int activeCount = template.queryForObject(sql, Integer.class);
				if (activeCount > 0)
					return "Only one mail configuration can be active at a time";
			}
			
			sql = "insert into audit_mail_config select * from mail_config where mailConfigId = ?";
			template.update(sql, mailConfigId);
			
			sql = "UPDATE mail_config SET status = ?, updatedBy = ?, updated_on = getDate() where"
					+ " mailConfigId = ?";
			template.update(sql, status, username, mailConfigId);
			return "****";
		} catch (Exception e) {
			e.printStackTrace();
			CustomMethods.logError(e);
			return e.getMessage();
		}
	}

	
	public MailConfigList getActiveConfigList() {
		try {
			String sql = "SELECT * FROM mail_config where status = 1";
			return template.query(sql, (ResultSet rs, int rowNum) -> {

				MailConfigList mailConfig = new MailConfigList();
				mailConfig.setMailConfigId(rs.getInt("mailConfigId"));
				mailConfig.setUsername(rs.getString("username"));
				mailConfig.setPassword(rs.getString("password"));
				mailConfig.setOutgoingServer(rs.getString("outgoingServer"));
				mailConfig.setOutgoingPort(rs.getInt("outgoingPort"));
				mailConfig.setEncryptionType(rs.getString("encryptionType"));
				mailConfig.setStatus(rs.getInt("status"));
				return mailConfig;
			}).get(0);
		} catch (Exception e) {
			e.printStackTrace();
			CustomMethods.logError(e);
			return null;
		}
	}

	
	public MailConfig getActiveConfig() {
		try 
		{
			String sql = "SELECT * FROM mail_config where status = 1";
			return template.query(sql, (ResultSet rs, int rowNum) -> {

				MailConfig mailConfig = new MailConfig();
				mailConfig.setUsername(rs.getString("username"));
				mailConfig.setPassword(rs.getString("password"));
				mailConfig.setHost(rs.getString("outgoingServer"));
				mailConfig.setPort(rs.getInt("outgoingPort"));
				mailConfig.setEncryptionType(rs.getString("encryptionType"));
				return mailConfig;
			}).get(0);
		} catch (Exception e) {
			e.printStackTrace();
			CustomMethods.logError(e);
			return null;
		}
	}

	
	public MailConfigList getMailConfigListById(int mailConfigId) {
		try {
			String sql = "SELECT * FROM mail_config where mailConfigId = " + mailConfigId;
			return template.query(sql, (ResultSet rs, int rowNum) -> {

				MailConfigList mailConfig = new MailConfigList();
				mailConfig.setMailConfigId(rs.getInt("mailConfigId"));
				mailConfig.setUsername(rs.getString("username"));
				mailConfig.setPassword(rs.getString("password"));
				mailConfig.setOutgoingServer(rs.getString("outgoingServer"));
				mailConfig.setOutgoingPort(rs.getInt("outgoingPort"));
				mailConfig.setEncryptionType(rs.getString("encryptionType"));
				mailConfig.setStatus(rs.getInt("status"));
				return mailConfig;
			}).get(0);
		} catch (Exception e) {
			e.printStackTrace();
			CustomMethods.logError(e);
			return null;
		}
	}

	
	public String sendMail(MailConfig mail) {
		Properties properties = System.getProperties();
		/*
		 * properties.put("mail.smtp.auth", "true"); properties.put("mail.smtp.host",
		 * mail.getHost()); properties.put("mail.smtp.port", mail.getPort());
		 * properties.put("mail.smtp.starttls.enable", "true");
		 * properties.put("mail.smtp.ssl.enable", "true");
		 */
		    properties.put("mail.transport.protocol", "smtp");
			properties.put("mail.smtp.auth", mail.getPassword().trim().equals("") ? "false" : "true");
			properties.put("mail.smtp.host", mail.getHost());
			properties.put("mail.smtp.port", mail.getPort());
			if(mail.getEncryptionType().equals("SSL"))
				properties.put("mail.smtp.starttls.enable", "false");
			else
				properties.put("mail.smtp.starttls.enable", "true");
			
			properties.put("mail.debug", "false");
			
		// Get the default Session object.
		Session session = Session.getInstance(properties, new Authenticator() {
			@Override
			protected PasswordAuthentication getPasswordAuthentication() {
				return new PasswordAuthentication(
						mail.getPassword().trim().equals("") ? "" : mail.getUsername(), 
						mail.getPassword().trim().equals("") ? "" : mail.getPassword());
			}
		});

		try {
			MimeMessage message = new MimeMessage(session);
			message.setFrom(new InternetAddress(mail.getUsername(),"Tata AIA Life"));
			message.addRecipient(Message.RecipientType.TO, new InternetAddress(mail.getReceipent()));
			message.setSubject(mail.getSubject());

			BodyPart messageBodyPart = new MimeBodyPart();
			messageBodyPart.setText(mail.getMessageBody());

			Multipart multipart = new MimeMultipart();
			multipart.addBodyPart(messageBodyPart);
			// Send the complete message parts
						
			if(!mail.getAppointmentPath().equals("")) 
			{
				
				messageBodyPart = new MimeBodyPart();
				javax.activation.DataSource source = new FileDataSource(mail.getAppointmentPath());
				messageBodyPart.setDataHandler(new DataHandler(source));
				messageBodyPart.setFileName("Appointment Letter.docx");
				multipart.addBodyPart(messageBodyPart);
			}
			
			if(!mail.getAuthorizationPath().equals(""))
			{
				messageBodyPart = new MimeBodyPart();
				javax.activation.DataSource source1 = new FileDataSource(mail.getAuthorizationPath());
				messageBodyPart.setDataHandler(new DataHandler(source1));
				messageBodyPart.setFileName("Authorization Letter.docx");
				multipart.addBodyPart(messageBodyPart);
			}
						
			message.setContent(multipart);
			// Send message
			Transport.send(message);
			return "****";
		} catch (Exception mex) {
//			mex.printStackTrace();
			CustomMethods.logError(mex);
			return "***";
		}
	}
	
	public String textReplaceForAppointment(String path, CaseDetails caselist, UserDetails toUser)
	{
		try {
			XWPFDocument doc = new XWPFDocument(OPCPackage.open(path));
			for (XWPFParagraph p : doc.getParagraphs()) {
				List<XWPFRun> runs = p.getRuns();

				if (runs != null) {

					for (XWPFRun r : runs) {

						String text = r.getText(0);

						if (text != null && text.contains("POLY000")) {
							text = text.replace("POLY000", caselist.getPolicyNumber());// your content
							r.setText(text, 0);
						}

						if (text != null && text.contains("DATEEE")) {
							text = text.replace("DATEEE", caselist.getCreatedDate().substring(8, 10)
									+ caselist.getCreatedDate().substring(4, 8) + 
									caselist.getCreatedDate().substring(0, 4));
							System.out.println(caselist.getCreatedDate());
							r.setText(text, 0);
						}

						if (text != null && text.contains("USER000")) {
							text = text.replace("USER000", toUser.getFull_name());
							r.setText(text, 0);
						}

						if (text != null && text.contains("ADD000")) {
							text = text.replace("ADD000", toUser.getAddress1());
							r.setText(text, 0);
						}

						if (text != null && text.contains("INS000")) {
							text = text.replace("INS000", caselist.getInsuredName());
							r.setText(text, 0);
						}

						if (text != null && text.contains("NOM000")) {
							text = text.replace("NOM000", caselist.getNominee_name());
							r.setText(text, 0);
						}
					}
				}
			}
			doc.write(new FileOutputStream(config.getUpload_directory() + caselist.getCaseId() + "_Appointment Letter.docx"));
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
			CustomMethods.logError(e);
		}
		return "****";
	}

	public String textReplaceForAuthorization(String path, CaseDetails caselist, UserDetails toUser)
	{
		try 
		{
			XWPFDocument doc = new XWPFDocument(OPCPackage.open(path));

			for (XWPFParagraph p : doc.getParagraphs()) 
			{
				List<XWPFRun> runs = p.getRuns();
				if (runs != null) 
				{
					for (XWPFRun r : runs) 
					{
						String text = r.getText(0);
						if (text != null && text.contains("DATEEE")) {
							text = text.replace("DATEEE", caselist.getCreatedDate().substring(8, 10)
									+ caselist.getCreatedDate().substring(4, 8) + 
									caselist.getCreatedDate().substring(0, 4));
							r.setText(text, 0);
						}
						if (text != null && text.contains("VDATE000")) {
							LocalDate startDate = LocalDate.parse(caselist.getCreatedDate().substring(0, 10), 
									DateTimeFormatter.ofPattern("yyyy-MM-dd"));
							LocalDate endDate = startDate.plusMonths(2);
							String validity = startDate.format(DateTimeFormatter.ofPattern("dd/MMM/yyyy")) + " to " +
									endDate.format(DateTimeFormatter.ofPattern("dd/MMM/yyyy"));
							text = text.replace("VDATE000", validity);
							r.setText(text, 0);
						}
						if (text != null && text.contains("USER000")) {
							text = text.replace("USER000", toUser.getFull_name());
							r.setText(text, 0);
						}
						if (text != null && text.contains("AGSUP000")) {
							text = text.replace("AGSUP000", toUser.getFull_name());
							r.setText(text, 0);
						}
						if (text != null && text.contains("ADD000")) {
							text = text.replace("ADD000", toUser.getAddress1());
							r.setText(text, 0);
						}
					}
				}
			}
			doc.write(new FileOutputStream(config.getUpload_directory() + caselist.getCaseId() + "_Authorization Letter.docx"));
		} 
		catch(Exception e)
		{
			e.printStackTrace();
			CustomMethods.logError(e);
		}
		return "****";

	}

}
