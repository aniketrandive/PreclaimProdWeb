package com.preclaim.dao;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.preclaim.config.Config;
import com.preclaim.config.CustomMethods;
import com.preclaim.models.RegionwiseList;
import com.preclaim.models.TopInvestigatorList;
import com.preclaim.models.VendorwiseList;
@Component
public class ReportDao{

	@Autowired
	DataSource datasource;

	@Autowired
	JdbcTemplate template;
	
	@Autowired
	Config config;
	
	public void setTemplate(JdbcTemplate template) {
		this.template = template;
	}

	
	public List<String> getRegion() {
		try
		{
			String sql = "select DISTINCT state from location_lists";
			return template.query(sql, (ResultSet rs, int row) -> {
				return rs.getString("state");
			});
		}
		catch(Exception e)
		{
			e.printStackTrace();
			CustomMethods.logError(e);
			return null;
		}
	}

	
	public HashMap<String, String> getVendor() {
		try
		{
			String sql = "select * from admin_user where role_name = ?";
			return template.query(sql, new Object [] {config.getSUPERVISOR()}, (ResultSet rs, int row) -> 
			{
				HashMap<String, String> vendor = new HashMap<String, String>();
				vendor.put(rs.getString("username"), rs.getString("full_name"));
				while(rs.next())
					vendor.put(rs.getString("username"), rs.getString("full_name"));
				return vendor;
			}).get(0);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			CustomMethods.logError(e);
			return null;
		}
	}
	
	
	public List<String> getIntimationType() {
		try
		{
			String sql = "select * from investigation_type";
			return template.query(sql, (ResultSet rs, int row) -> {
				
				return rs.getString("investigationName");
			});
		}
		catch(Exception e)
		{
			e.printStackTrace();
			CustomMethods.logError(e);
			return null;
		}
	}

	public HashMap<String, Integer> getIntimationTypeList(String intimationType, String startDate, 
			String endDate) 
	{
		
		String sql = ""; 
		HashMap<String, Integer> intimationDetails = new HashMap<String, Integer>();
		if(intimationType.equals("All"))
		{
			sql = "SELECT investigationType, count(*) as grandTotal FROM case_lists "
				+ "WHERE CONVERT(date,createdDate) BETWEEN ? AND ? "
				+ "GROUP BY investigationType";
			try 
			{
				return template.query(sql, new Object[] {startDate, endDate} , 
						(ResultSet rs, int rowNum) -> {
							do
							{
								intimationDetails.put(rs.getString("investigationType"), 
										rs.getInt("grandTotal"));
							}while(rs.next());
							return intimationDetails;
						}).get(0);
			}
			catch(Exception e)
			{
				e.printStackTrace();
				return null;
			}
		}
		else
		{
			sql = "SELECT investigationType, count(*) as grandTotal FROM case_lists "
					+ "WHERE investigationType = ? and CONVERT(date,createdDate) BETWEEN ? AND ? "
					+ "GROUP BY investigationType";
			try
			{
				return template.query(sql, new Object[] {intimationType, startDate, endDate} , 
						(ResultSet rs, int rowNum) -> {
							do
							{
								intimationDetails.put(rs.getString("investigationType"), 
										rs.getInt("grandTotal"));
							}while(rs.next());
							return intimationDetails;
						}).get(0);
			}
			catch(Exception e)
			{
				return null;
			}
		}
	}

	
	public List<TopInvestigatorList> getTopInvestigatorList(String startDate, String endDate) {
		
		String user_lists = "";
		// Main Query - Query to get Top 15 Investigators
		List<String> investigator_list = new ArrayList<String>();
		/*
		1) Get Latest record from audit_case_movement whose role = "AGNSUP"
		2) Join the above query with case_lists where caseSubStatus is Clean , Not-Clean
		3) Get Investigator wise Total Count
		*/
		String sql = 
				"SELECT TOP 15 b.toId, count(*) as grandTotal FROM case_lists a, "
				+ "(select a.caseId, a.toId, a.updatedDate FROM audit_case_movement a, "
				+ "(select caseId,  max(updatedDate) as updatedDate FROM audit_case_movement WHERE toRole = ? "
				+ "group by  caseId ) b WHERE a.caseId = b.caseId and a.toRole = ? and a.updatedDate = b.updatedDate "
				+ ") b where a.caseId = b.caseId AND a.caseSubStatus IN ('Clean','Not-Clean') "
				+ "and CONVERT(date,b.updatedDate) BETWEEN ? AND ? "
				+ "GROUP BY b.toId "
				+ "ORDER BY count(*) desc";
				
		/* System.out.println(sql); */
		
		try
		{
			user_lists = template.query(sql, new Object[] {config.getSUPERVISOR(), config.getSUPERVISOR(), 
					startDate, endDate},
					(ResultSet rs, int rowNum) -> 
					{
						String userId = "";
						do 
						{
							investigator_list.add(rs.getString("toId"));
							userId +=  "'" + rs.getString("toId") + "',";
						}
						while(rs.next());			
						return userId;
						
					}).get(0);
		}
		catch(Exception e)
		{
			return null;
		}
		user_lists = user_lists.substring(0, user_lists.length() - 1);
		/* System.out.println(user_lists); */
		
		//Query 2 - Query to categorize Clean, Not Clean 
		
		HashMap<String, Integer> clean = new HashMap<String, Integer>();
		HashMap<String, Integer> notClean = new HashMap<String, Integer>();
		
		sql = 
				"SELECT TOP 15 b.toId, a.caseSubStatus, count(*) as substatusTotal FROM case_lists a, "
				+ "(select a.caseId, a.toId, a.updatedDate FROM audit_case_movement a, "
				+ "(select caseId,  max(updatedDate) as updatedDate FROM audit_case_movement WHERE toRole = ? "
				+ "group by  caseId ) b WHERE a.caseId = b.caseId and a.toRole = ? and a.updatedDate = b.updatedDate "
				+ ") b where a.caseId = b.caseId AND a.caseSubStatus IN ('Clean','Not-Clean') "
				+ "and CONVERT(date,b.updatedDate) BETWEEN ? AND ? "
				+ "GROUP BY b.toId, a.caseSubStatus "
				+ "ORDER BY count(*) desc";
		
		template.query(sql, new Object[] {config.getSUPERVISOR(), config.getSUPERVISOR(), startDate, endDate},
			(ResultSet rs, int rowNum) -> {
			do 
			{
				if(rs.getString("caseSubStatus").equals("Clean"))
					clean.put(rs.getString("toId"),rs.getInt("substatusTotal"));
				
				else if(rs.getString("caseSubStatus").equals("Not-Clean"))
					notClean.put(rs.getString("toId"),rs.getInt("substatusTotal"));
			}while(rs.next());
			
			return "";
		});

		//Query 3 - Query to map username & fullname 
		
		HashMap<String, String> user_mapping = new HashMap<String, String>();
		sql = "SELECT * FROM admin_user b where username in ( " + user_lists +  ")";
		template.query(sql , (ResultSet rs, int rowNum) -> {
			do
			{
				user_mapping.put(rs.getString("username"),rs.getString("full_name"));
			}while(rs.next());
			return user_mapping;
		});
		List<TopInvestigatorList> investigator = new ArrayList<TopInvestigatorList>();
		int cleanCount = 0;
		int NotCleanCount = 0;
		int totalCleanCount = 0;
		int totalNotCleanCount = 0;
		for(String user: investigator_list)
		{
			cleanCount = clean.get(user) == null ? 0 : clean.get(user);
			NotCleanCount = notClean.get(user) == null ? 0 : notClean.get(user);
			investigator.add(new TopInvestigatorList(user_mapping.get(user), cleanCount, NotCleanCount));
			totalCleanCount += cleanCount; 
			totalNotCleanCount += NotCleanCount;
		}
		investigator.add(new TopInvestigatorList("Total", totalCleanCount, totalNotCleanCount));
		
		return investigator;
	}
	
	
	public List<RegionwiseList> getRegionwiseList(String region, String startDate, String endDate) {
		System.out.println("config"+config.getSUPERVISOR());
		String user_lists = "";
		List<String> investigator_list = new ArrayList<String>();
		String sql =
				"select b.toId, count(*) as grandTotal from case_lists a, "
				+ "(select a.caseId, a.toId, a.updatedDate from audit_case_movement a, "
				+ "(select caseId,  max(updatedDate) as updatedDate from audit_case_movement where toRole = ? "
				+ "group by  caseId ) b where a.caseId = b.caseId and a.toRole = ? and a.updatedDate = b.updatedDate "
				+ ") b where a.caseId = b.caseId and a.caseStatus IN ('Closed','WIP') and  "
				+ "b.toId IN (SELECT username from admin_user where state = ?) "
				+ "and CONVERT(date,b.updatedDate) BETWEEN ? AND ? "
				+ "group by b.toId "
				+ "order by count(*) desc";
				
		/* System.out.println(sql); */
		try
		{
			user_lists = template.query(sql, new Object[] {config.getSUPERVISOR(), config.getSUPERVISOR(), 
					region, startDate, endDate}, 
					(ResultSet rs, int rowNum) -> 
					{
						String userId = "";
						do 
						{
							investigator_list.add(rs.getString("toId"));
							userId +=  "'" + rs.getString("toId") + "',";
						}
						while(rs.next());			
						return userId;
						
					}).get(0);
		}
		catch(Exception e)
		{
			return null;
		}
		user_lists = user_lists.substring(0, user_lists.length() - 1);
		/* System.out.println(user_lists); */
		
		HashMap<String, Integer> clean = new HashMap<String, Integer>();
		HashMap<String, Integer> notClean = new HashMap<String, Integer>();
		HashMap<String, Integer> pivstopped = new HashMap<String, Integer>();
		HashMap<String, Integer> wip = new HashMap<String, Integer>();
		
		sql =
				"select b.toId,  a.caseSubStatus , count(*) as substatusTotal from case_lists a, "
				+ "(select a.caseId, a.toId, a.updatedDate from audit_case_movement a, "
				+ "(select caseId,  max(updatedDate) as updatedDate from audit_case_movement where toRole = ? "
				+ "group by  caseId ) b where a.caseId = b.caseId and a.toRole = ? and a.updatedDate = b.updatedDate "
				+ ") b where a.caseId = b.caseId and a.caseStatus = 'Closed' and  "
				+ "b.toId IN (SELECT username from admin_user where state = ?) "
				+ "and CONVERT(date,b.updatedDate) BETWEEN ? AND ? "
				+ "group by b.toId, a.caseSubStatus "
				+ "order by count(*) desc";
		
		/* System.out.println(sql); */
		
		template.query(sql,new Object[] {config.getSUPERVISOR(), config.getSUPERVISOR(), region, startDate, endDate},
			(ResultSet rs, int rowNum) -> {
			do 
			{
				if(rs.getString("caseSubStatus").equals("Clean"))
					clean.put(rs.getString("toId"),rs.getInt("substatusTotal"));
				
				else if(rs.getString("caseSubStatus").equals("Not-Clean"))
					notClean.put(rs.getString("toId"),rs.getInt("substatusTotal"));
				
				else if(rs.getString("caseSubStatus").equals("PIV Stopped"))
					pivstopped.put(rs.getString("toId"),rs.getInt("substatusTotal"));
			}while(rs.next());
			
			return "";
		});
		
		sql =
				"select b.toId as toid,  a.caseSubStatus , count(*) as substatusTotal from case_lists a, "
				+ "(select a.caseId, a.toId, a.updatedDate from audit_case_movement a, "
				+ "(select caseId,  max(updatedDate) as updatedDate from audit_case_movement where toRole = ? "
				+ "group by  caseId ) b where a.caseId = b.caseId and a.toRole = ? and a.updatedDate = b.updatedDate "
				+ ") b where a.caseId = b.caseId and a.caseStatus = 'WIP' and  "
				+ "b.toId IN (SELECT username from admin_user where state = ?) "
				+ "and CONVERT(date,b.updatedDate) BETWEEN ? AND ? "
				+ "group by b.toId, a.caseSubStatus "
				+ "order by count(*) desc";
		
		template.query(sql,new Object[] {config.getSUPERVISOR(), config.getSUPERVISOR(), region, startDate, endDate},
			(ResultSet rs, int rowNum) -> {
			do 
			{
				wip.put(rs.getString("toid"),rs.getInt("substatusTotal"));
			}while(rs.next());
			
			return "";
		});
		
		HashMap<String, String> user_mapping = new HashMap<String, String>();
		sql = "SELECT * FROM admin_user b where username in ( " + user_lists +  ")";
		template.query(sql , (ResultSet rs, int rowNum) -> {
			do
			{
				user_mapping.put(rs.getString("username"),rs.getString("full_name"));
			}while(rs.next());
			return user_mapping;
		});
		List<RegionwiseList> regionwise = new ArrayList<RegionwiseList>();
		for(String user: investigator_list)
		{
			regionwise.add(new RegionwiseList(user_mapping.get(user),
					clean.get(user) == null ? 0 : clean.get(user),
					notClean.get(user) == null ? 0 : notClean.get(user),
					pivstopped.get(user) == null ? 0 : pivstopped.get(user),
					wip.get(user) == null ? 0 : wip.get(user)));
		}
		
		return regionwise;
	}

	
	public List<VendorwiseList> getVendorwistList(String vendorName, String startDate, String endDate) {
		
		List<String> monthwise = new ArrayList<String>();
		String sql = "SELECT a.toId, FORMAT(a.updatedDate,'MMM') + '-' + FORMAT(a.updatedDate,'yy') as Month, count(*) as total FROM audit_case_movement a, ("
				+ "SELECT caseId, max(updatedDate) as updatedDate FROM audit_case_movement "
				+ "WHERE caseid in (SELECT caseid FROM case_lists WHERE caseSubStatus IN ('Clean','Not-Clean')) "
				+ "and toRole = ? "
				+ "group by caseId) b "
				+ "where a.caseId = b.caseId and a.updatedDate = b.updatedDate and a.toId = ? and "
				+ "CONVERT(date, a.updatedDate) BETWEEN ? and ? "
				+ "group by a.toId, YEAR(a.updatedDate), FORMAT(a.updatedDate,'MMM') + '-' + FORMAT(a.updatedDate,'yy')";
		try
		{
			template.query(sql, new Object[] {config.getSUPERVISOR(), vendorName, startDate, endDate},
					(ResultSet rs, int rowNum) -> {
						do
						{
							monthwise.add(rs.getString("Month"));
						}while(rs.next());
					return monthwise;
					});
		}
		catch(Exception e)
		{
			e.printStackTrace();
			return null;
		}
		HashMap<String, Integer> clean = new HashMap<String, Integer>();
		HashMap<String, Integer> notClean = new HashMap<String, Integer>();
		
		sql = "SELECT a.toId, FORMAT(a.updatedDate,'MMM') + '-' + FORMAT(a.updatedDate,'yy') as Month, count(*) as cleanCount FROM audit_case_movement a, ("
				+ "SELECT caseId, max(updatedDate) as updatedDate FROM audit_case_movement "
				+ "WHERE caseid in (SELECT caseid FROM case_lists WHERE caseSubStatus = 'Clean') "
				+ "and toRole = ? "
				+ "group by caseId) b "
				+ "where a.caseId = b.caseId and a.updatedDate = b.updatedDate and a.toId = ? and "
				+ "CONVERT(date, a.updatedDate) BETWEEN ? and ? "
				+ "group by a.toId, YEAR(a.updatedDate), FORMAT(a.updatedDate,'MMM') + '-' + FORMAT(a.updatedDate,'yy')";
		
		template.query(sql, new Object[] {config.getSUPERVISOR(), vendorName, startDate, endDate}, 
				(ResultSet rs, int rowNum) -> {
					do
					{
						clean.put(rs.getString("Month"), rs.getInt("cleanCount"));
					}while(rs.next());
					return clean;
				});
		
		sql = "SELECT a.toId, FORMAT(a.updatedDate,'MMM') + '-' + FORMAT(a.updatedDate,'yy') as Month, count(*) as notCleanCount FROM audit_case_movement a, ("
				+ "SELECT caseId, max(updatedDate) as updatedDate FROM audit_case_movement "
				+ "WHERE caseid in (SELECT caseid FROM case_lists WHERE caseSubStatus = 'Not-Clean') "
				+ "and toRole = ? "
				+ "group by caseId) b "
				+ "where a.caseId = b.caseId and a.updatedDate = b.updatedDate and a.toId = ? and "
				+ "CONVERT(date, a.updatedDate) BETWEEN ? and ? "
				+ "group by a.toId, YEAR(a.updatedDate), FORMAT(a.updatedDate,'MMM') + '-' + FORMAT(a.updatedDate,'yy')";
		
		template.query(sql, new Object[] {config.getSUPERVISOR(), vendorName, startDate, endDate}, 
				(ResultSet rs, int rowNum) -> {
					do
					{
						notClean.put(rs.getString("Month"), rs.getInt("notCleanCount"));
					}while(rs.next());
					return clean;
				});
		
		List<VendorwiseList> vendorlist = new ArrayList<VendorwiseList>();
		for(String month: monthwise)
		{
			vendorlist.add(new VendorwiseList(month, 
					clean.get(month) == null ? 0: clean.get(month), 
					notClean.get(month) == null ? 0: notClean.get(month)));
		}	
		return vendorlist;
	}	
	
	public Map<Integer, Object[]> dumpReport(String startDate,String endDate) 
	{
		Map<Integer, Object[]> reportData = new HashMap<Integer, Object[]>();
		reportData.put(0, new Object[] {
				"Sr No", 
				"Case ID", 
				"Policy Number", 
				"Nature Of Investigation",
				"City",
				"State",
				"Zone",
				"Issued Date",
				"Insured Mobile Number",
				"Insured Name", 
				"Insured DOD", 
				"Insured DOB",
				"Insured Diagnosis Date",
				"Gender",
				"Sum Assured",
				"Investigation Type",
				"Pincode",
				"Case Status",
				"Case Sub Status",
				"Not Clean Category",
				"Trigger Name",
				"Trigger Department",
				"Disposition Name",
				"Nominee Name",
				"Nominee Contact Number",
				"Nominee Address",
				"Insured Address", 
				"Case Description",
				"Longitude", 
				"Latitude",
				"Created By",
				"Created Date", 
				"Updated Date",
				"TAT",
				"Updated By",
				"Regional Manager",
				"rm_alloted_Date" ,
				"RCU Remarks",
				"Agency Supervisor",
				"agency_alloted_Date",
				"regional_man_remarks",
				"investigator_mobile_number",
				"Investigator",
				"inv_alloted_date",
				"agn_sup_remarks",
				"Invtoagency_supervisor",
				"Invtoagency_alloted_Date",
				"Invtoagency_remarks",
				"Underwriter",
				"uw_alloted_date",
				"reg_man_remarks",
				"talic/claim",
				"talic/claim_alloted_date",
				"uw_remarks",
				"claim_remarks",
				"Inv Report_date",
				"as_Report_date",
	       		"uw_Report_date",
	       		"talic/clamim_Report_date"
				});
       
		
		String sql = "select main.*, (select city from location_lists where locationId = main.locationId) city,   \n" + 
				"												(select state from location_lists where locationId = main.locationId) state,   \n" + 
				"												(select zone from location_lists where locationId = main.locationId) zone,   \n" + 
				"												(select nature_of_investigationType from nature_of_investigation where nature_of_investigationId = main.nature_of_investigationId) as nature_of_investigation,   \n" + 
				"												ISNULL((select full_name from admin_user where username =  ISNULL(agnsup.fromId,'')),'') as regional_manager,    												 \n" + 
				"												ISNULL(regman.updatedDate,'') as rm_alloted_date,    \n" + 
				"												ISNULL(regman.remarks,'') as RCU_Remarks,    \n" + 
				"												case main.casestatus    \n" + 
				"												when 'Closed' then DATEDIFF(day,main.createdDate,main.updatedDate)    \n" + 
				"												else  DATEDIFF(day,main.updatedDate,getdate())   \n" + 
				"												end as TAT,   \n" + 
				"												ISNULL((select full_name from admin_user where username = ISNULL(agnsup.toId,'')),'') as agency_supervisor,    \n" + 
				"												ISNULL(agnsup.updatedDate,'') as agency_alloted_date,    \n" + 
				"												ISNULL(agnsup.remarks,'') as regional_man_remarks,    \n" + 
				"												ISNULL((select mobile_number from admin_user where username = ISNULL(inv.toId,'')),'') as investigator_mobile_number,    \n" + 
				"												ISNULL((select full_name from admin_user where username = ISNULL(inv.toId,'')),'') as investigator,    \n" + 
				"												ISNULL(inv.updatedDate,'') as inv_alloted_date,    \n" + 
				"												ISNULL(inv.remarks,'') as agn_sup_remarks,    \n" + 
				"												ISNULL((select full_name from admin_user where username = ISNULL(agnsuptorm.toId,'')),'') as Invtoagency_supervisor,    \n" + 
				"												ISNULL(agnsuptorm.updatedDate,'') as Invtoagency_alloted_date,    \n" + 
				"												ISNULL(agnsuptorm.remarks,'') as Invtoagency_remarks,    \n" + 
				"												ISNULL((select full_name from admin_user where username = ISNULL(uw.toId,'')),'') as underwriter,  \n" + 
				"												ISNULL(uw.updatedDate,'') as uw_alloted_date,    \n" + 
				"												ISNULL(uw.remarks,'') as regional_man_remarks, 				   \n" + 
				"												ISNULL((select full_name from admin_user where username = ISNULL(talicman.toId,'')),'') as talic,    \n" + 
				"												ISNULL(talicman.updatedDate,'') as talic_alloted_date,   \n" + 
				"												ISNULL(talicman.remarks,'') as uw_remarks, \n" + 
				"												ISNULL(claimman.remarks,'') as claim_remarks, \n" + 
				"												ISNULL(agnsuptorm.updatedDate,'') as Invtoagency_Report_date,  \n" + 
				"												ISNULL(regman2.updatedDate,'') as asTorm_Report_date, \n" + 
				"												ISNULL(uwreport.updatedDate,'') as uwTotalicman_Report_date, \n" + 
				"												ISNULL(talicrmreport.updatedDate,'') as talicman_Report_date \n" + 
				"												from case_lists main 			   \n" + 
				"												left outer join    \n" + 
				"												(select x.* from audit_case_movement x,    \n" + 
				"												(select caseId , min(updatedDate) as updatedDate from audit_case_movement where toRole = 'AGNSUP'   \n" + 
				"												group by caseId) y   \n" + 
				"												where x.caseId = y.caseId and x.toRole = 'AGNSUP' and x.updatedDate = y.updatedDate ) agnsup   \n" + 
				"												on main.caseId = agnsup.caseId 	   \n" + 
				"												left outer join    \n" + 
				"												(select x.* from audit_case_movement x,    \n" + 
				"												(select caseId , min(updatedDate) as updatedDate from audit_case_movement where toRole = 'REGMAN'   \n" + 
				"												group by caseId) y   \n" + 
				"												where x.caseId = y.caseId and x.toRole = 'REGMAN' and x.updatedDate = y.updatedDate ) regman   \n" + 
				"												on main.caseId = regman.caseId   \n" + 
				"												left outer join    \n" + 
				"												(select x.* from audit_case_movement x,    \n" + 
				"												(select caseId , min(updatedDate) as updatedDate from audit_case_movement where toRole = 'UW'   \n" + 
				"												group by caseId) y   \n" + 
				"												where x.caseId = y.caseId and x.toRole = 'UW' and x.updatedDate = y.updatedDate ) uw   \n" + 
				"												on main.caseId = uw.caseId  \n" + 
				"												left outer join    \n" + 
				"												(select x.* from audit_case_movement x,    \n" + 
				"												(select caseId , min(updatedDate) as updatedDate from audit_case_movement where toRole = 'INV'   \n" + 
				"												group by caseId) y   \n" + 
				"												where x.caseId = y.caseId and x.toRole = 'INV' and x.updatedDate = y.updatedDate ) inv   \n" + 
				"												on main.caseId = inv.caseId     \n" + 
				"												left outer join    \n" + 
				"												(select x.* from audit_case_movement x,    \n" + 
				"												(select caseId , min(updatedDate) as updatedDate from audit_case_movement where toRole = 'CLAMAN'   \n" + 
				"												group by caseId) y   \n" + 
				"												where x.caseId = y.caseId and x.toRole = 'CLAIMS' and x.updatedDate = y.updatedDate ) claims   \n" + 
				"												on main.caseId = claims.caseId  \n" + 
				"												left outer join    \n" + 
				"												(select x.* from audit_case_movement x,    \n" + 
				"												(select caseId , min(updatedDate) as updatedDate from audit_case_movement where toRole in( 'TALICMAN')   \n" + 
				"												group by caseId) y   \n" + 
				"												where x.caseId = y.caseId and x.toRole in( 'TALICMAN')   and x.updatedDate = y.updatedDate ) talicman   \n" + 
				"												on main.caseId = talicman.caseId\n" + 
				"												left outer join    \n" + 
				"												(select x.* from audit_case_movement x,    \n" + 
				"												(select caseId , max(updatedDate) as updatedDate from audit_case_movement where toRole='AGNSUP' and \n" + 
				"												fromId in(select username from admin_user where role_name in ('INV')) \n" + 
				"												group by caseId) y   \n" + 
				"												where x.caseId = y.caseId  and x.updatedDate = y.updatedDate) agnsuptorm   \n" + 
				"												on main.caseId = agnsuptorm.caseId 	\n" + 
				"												left outer join    \n" + 
				"												(select x.* from audit_case_movement x,    \n" + 
				"												(select caseId , max(updatedDate) as updatedDate from audit_case_movement where toRole in( 'CLAMAN','REGMAN')and\n" + 
				"												fromId in(select username from admin_user where role_name in ('AGNSUP' ))   \n" + 
				"												group by caseId) y   \n" + 
				"												where x.caseId = y.caseId  and x.updatedDate = y.updatedDate ) regman2   \n" + 
				"												on main.caseId = regman2.caseId \n" + 
				"												left outer join    \n" + 
				"												(select x.* from audit_case_movement x,    \n" + 
				"												(select caseId , max(updatedDate) as updatedDate from audit_case_movement where \n" + 
				"												fromId in(select username from admin_user where role_name in ('UW'))   \n" + 
				"												group by caseId) y   \n" + 
				"												where x.caseId = y.caseId  and x.updatedDate = y.updatedDate ) uwreport  \n" + 
				"												on main.caseId = uwreport.caseId \n" + 
				"												left outer join    \n" + 
				"												(select x.* from audit_case_movement x,    \n" + 
				"												(select caseId , min(updatedDate) as updatedDate from audit_case_movement where toId ='' and\n" + 
				"												fromId in(select username from admin_user where role_name in( 'TALICMAN','CLAMAN'))   \n" + 
				"												group by caseId) y   \n" + 
				"												where x.caseId = y.caseId and x.updatedDate = y.updatedDate) talicrmreport   \n" + 
				"												on main.caseId = talicrmreport.caseId \n" + 
				"												left outer join     \n" + 
				"												(select x.* from audit_case_movement x,     \n" + 
				"												(select caseId , min(updatedDate) as updatedDate from audit_case_movement where toRole in( 'CLAMAN')    \n" + 
				"												group by caseId) y    \n" + 
				"												where x.caseId = y.caseId and x.toRole in('CLAMAN')   and x.updatedDate = y.updatedDate ) claimman    \n" + 
				"												on main.caseId = claimman.caseId \n" + 
				"												where \n" + 
				"												CONVERT(date, main.createdDate) BETWEEN ? and ? ";
		
		
		template.query(sql, new Object[] {startDate, endDate},(ResultSet rs, int rowNum) -> {
			reportData.put(rowNum+1, new Object[] {
					rowNum + 1,
					rs.getInt("caseId"),
					rs.getString("policyNumber"),
					rs.getString("nature_of_investigation"),
					rs.getString("city"),
					rs.getString("state"),
					rs.getString("zone"),
					rs.getString("issuedDate"),
					rs.getString("insuredMob"),
					rs.getString("insuredName"),
					rs.getString("insuredDOD"),
					rs.getString("insuredDOB"),
					rs.getString("insuredDiagnosisDate"),
					rs.getString("gender"),
					rs.getString("sumAssured"),
					rs.getString("investigationType"),
					rs.getString("pincode"),
					rs.getString("caseStatus"),
					rs.getString("caseSubStatus"),
					rs.getString("notCleanCategory"),
					rs.getString("trigger_name"),
					rs.getString("trigger_dept"),
		       		rs.getString("disposition_name"),
		       		rs.getString("nominee_Name"),
		       		rs.getString("nominee_ContactNumber"),
		       		rs.getString("nominee_address"),
		       		rs.getString("insured_address"),
		       		rs.getString("case_description"),
		       		rs.getString("longitude"),
		       		rs.getString("latitude"),
		       		rs.getString("createdBy"),
		       		rs.getString("createdDate"),
		       		rs.getString("updatedDate"),
		       		rs.getString("TAT"),
		       		rs.getString("updatedBy"),
		       		rs.getString("regional_manager"),
		       		rs.getString("rm_alloted_date"),
		       		rs.getString("RCU_Remarks"),
		       		rs.getString("agency_supervisor"),
		       		rs.getString("agency_alloted_date"),
		       		rs.getString("regional_man_remarks"),
		       		rs.getString("investigator_mobile_number"),
		       		rs.getString("investigator"),
		       		rs.getString("inv_alloted_date"),
		       		rs.getString("agn_sup_remarks"),
		       		rs.getString("Invtoagency_supervisor"),
		       		rs.getString("Invtoagency_alloted_Date"),
		       		rs.getString("Invtoagency_remarks"),
		       		rs.getString("underwriter"),
		       		rs.getString("uw_alloted_date"),
		       		rs.getString("regional_man_remarks"),
		       		rs.getString("talic"),
		       		rs.getString("talic_alloted_date"),
		       		rs.getString("uw_remarks"),
		       		rs.getString("claim_remarks"),
		       		rs.getString("Invtoagency_Report_date"),
		       		rs.getString("asTorm_Report_date"),
		       		rs.getString("uwTotalicman_Report_date"),
		       		rs.getString("talicman_Report_date")
		       		
			});			
			  return null;
		});

	return reportData;
	}
	
	public Map<Integer, Object[]> dumpReportupdate(String startDate,String endDate) 
	{
		Map<Integer, Object[]> reportData = new HashMap<Integer, Object[]>();
		reportData.put(0, new Object[] {
				"Sr No", 
				"Case ID", 
				"Policy Number", 
				"Nature Of Investigation",
				"City",
				"State",
				"Zone",
				"Issued Date",
				"Insured Mobile Number",
				"Insured Name", 
				"Insured DOD", 
				"Insured DOB",
				"Insured Diagnosis Date",
				"Gender",
				"Sum Assured",
				"Investigation Type",
				"Pincode",
				"Case Status",
				"Case Sub Status",
				"Not Clean Category",
				"Trigger Name",
				"Trigger Department",
				"Disposition Name",
				"Nominee Name",
				"Nominee Contact Number",
				"Nominee Address",
				"Insured Address", 
				"Case Description",
				"Longitude", 
				"Latitude",
				"Created By",
				"Created Date", 
				"Updated Date",
				"Updated By",
				"From Mobile Number",
				"From User",
				"To User",
				"To Role",
				"Remarks",
				"Allocated Date",
				"Approved Date",
				"TAT",
				"Fees",
				"Payment status"
				});
       
		
		String sql = "select a.*,\n" + 
				"(select city from location_lists where locationId = a.locationId) city,\n" + 
				"(select state from location_lists where locationId = a.locationId) state,  \n" + 
				"(select zone from location_lists where locationId = a.locationId) zone,  \n" + 
				"(select nature_of_investigationType from nature_of_investigation where nature_of_investigationId = a.nature_of_investigationId) as nature_of_investigation,  \n" + 
				"ISNULL((select mobile_number from admin_user where username = ISNULL(b.fromId,'')),'') as mobile_number,  \n" + 
				"ISNULL((select full_name  from admin_user where username = b.fromId),'') as fromId,\n" + 
				"ISNULL((select full_name from admin_user where username = b.toId),'') as toId,   \n" + 
				"b.toRole,\n" + 
				"b.caseStatus,\n" + 
				"b.remarks,\n" + 
				"b.createdDate,\n" + 
				"Lag(b.updatedDate, 1,b.createdDate) OVER(PARTition by a.caseId ORDER BY b.updatedDate ASC) as allocated_date,\n" + 
				"b.updatedDate as approved_date,\n" + 
				"DATEDIFF(day,Lag(b.updatedDate, 1,b.createdDate) OVER(PARTition by a.caseId ORDER BY b.updatedDate ASC), b.updatedDate) as TAT,\n" + 
				"ISNULL((select fees from admin_user x left outer join user_fees y on x.username = y.username\n" + 
				"where x.username = b.toId and y.investigationType = a.investigationType and fromId in(select username from admin_user where role_name ='REGMAN') and x.role_name ='AGNSUP'),0) as fees ,\n" + 
				"case ISNULL((select fees from admin_user x left outer join user_fees y on x.username = y.username\n" + 
				"where x.username = b.toId and y.investigationType = a.investigationType and fromId in(select username from admin_user where role_name ='REGMAN') and x.role_name ='AGNSUP'\n" + 
				"and a.caseStatus = 'Closed'\n" + 
				"and a.caseId  in (select caseId from case_payment where userId = b.toId)\n" + 
				"),0)\n" + 
				"when 0.00 then ' ' else 'Y'  end as status\n" + 
				"from case_lists a\n" + 
				"left outer join\n" + 
				"audit_case_movement b on a.caseId = b.caseId \n" + 
				"where a.caseId=b.caseId and CONVERT(date, a.createdDate) BETWEEN ? and ? order by b.updatedDate\n" + 
				 
				"";
		
		
		template.query(sql, new Object[] {startDate, endDate},(ResultSet rs, int rowNum) -> {
			reportData.put(rowNum+1, new Object[] {
					rowNum + 1,
					rs.getInt("caseId"),
					rs.getString("policyNumber"),
					rs.getString("nature_of_investigation"),
					rs.getString("city"),
					rs.getString("state"),
					rs.getString("zone"),
					rs.getString("issuedDate"),
					rs.getString("insuredMob"),
					rs.getString("insuredName"),
					rs.getString("insuredDOD"),
					rs.getString("insuredDOB"),
					rs.getString("insuredDiagnosisDate"),
					rs.getString("gender"),
					rs.getString("sumAssured"),
					rs.getString("investigationType"),
					rs.getString("pincode"),
					rs.getString("caseStatus"),
					rs.getString("caseSubStatus"),
					rs.getString("notCleanCategory"),
					rs.getString("trigger_name"),
					rs.getString("trigger_dept"),
		       		rs.getString("disposition_name"),
		       		rs.getString("nominee_Name"),
		       		rs.getString("nominee_ContactNumber"),
		       		rs.getString("nominee_address"),
		       		rs.getString("insured_address"),
		       		rs.getString("case_description"),
		       		rs.getString("longitude"),
		       		rs.getString("latitude"),
		       		rs.getString("createdBy"),
		       		rs.getString("createdDate"),
		       		rs.getString("updatedDate"),
		       		rs.getString("updatedBy"),
		       		rs.getString("mobile_number"),
		       		rs.getString("fromId"),
		       		rs.getString("toId"),
		       		rs.getString("toRole"),
		       		rs.getString("remarks"),
		       		rs.getString("allocated_date"),
		       		rs.getString("approved_date"),
		       		rs.getString("TAT"),
		       		rs.getString("fees"),
		       		rs.getString("status"),
		       		
		       		
			});			
			  return null;
		});

	return reportData;
	}
	
	//added by kk
	public Map<Integer, Object[]> dumpAuditReportupdate(String startDate,String endDate) 
	{
		Map<Integer, Object[]> reportData = new HashMap<Integer, Object[]>();
		reportData.put(0, new Object[] {
				"Sr No", 
				"CASEID",
				"POLICY NUMBER",
				"NATURE OF INVESTIGATION", 
				"ISSUED DATE",
				"INSURED MOB",
				"INSURED NAME",
				"INSURED DOD", 
				"INSURED DOB",
				"INSURED DIAGNOSIS DATE",
				"GENDER",
				"SUM ASSURED",
				"INVESTIGATION TYPE",
				"LOCATION ID",
				"PINCODE", 
				"CASE SUB STATUS",
				"NOTCLEAN CATEGORY", 
				"TRIGGER NAME", 
				"TRIGGER DEPT",
				"DISPOSITION NAME",
				"NOMINEE NAME", 
				"NOMINEE CONTACTNUMBER", 
				"NOMINEE ADDRESS",
				"INSURED ADDRESS",
				"CASE DESCRIPTION",
				//"LONGITUDE", 
				//"LATITUDE", 
				"CREATED BY", 
				"CREATED DATE", 
				"UPDATED DATE", 
				"UPDATED BY",
				"CITY",
				"STATE", 
				"ZONE", 
				"FEES", 
				"STATUS",
				"RCU MOBILE NUMBER",
				"RCU FROMID",
				"RCU TOID",
				"RCU TOROLE", 
				"RCU CASE STATUS", 
				"RCU REMARKS",
				"RCU ALLOCATED DATE", 
				"RCU APPROVED DATE", 
				"RCU TAT",
				"REGMAN MOBILE NUMBER",
				"REGMAN FROMID", 
				"AGNSUP TOID",
				"AGNSUP TOROLE",
				"REGMAN CASE STATUS",
				"REGMAN REMARKS",
				"REGMAN ALLOCATED DATE",
				"REGMAN APPROVED DATE",
				"REGMAN TAT",
				"AGNSUP MOBILE NUMBER", 
				"AGNSUP FROMID",
				"INV TOID",
				"INV TOROLE",
                "AGNSUP CASE STATUS",
                "AGNSUP REMARKS",
				"AGNSUP ALLOCATED DATE",
				"AGNSUP APPROVED DATE",
				"AGNSUP TAT", 
				"INV MOBILE NUMBER",
				"INV FROMID",
				"AGNSUP TOID", 
				"AGNSUP TOROLE", 
				"INV CASE STATUS",
				"INV REMARKS",
				"INV ALLOCATED DATE", 
				"INV APPROVED DATE",
				"INV TAT",
				"AGNSUP MOBILE NUMBER",
				"AGNSUP FROMID",
				"REGMAN TOID",
				"REGMAN TOROLE",
				"AGNSUP CASE STATUS", 
				"AGNSUP REMARKS",
				"AGNSUP ALLOCATED DATE",
				"AGNSUP APPROVED DATE", 
				"AGNSUP TAT",
				"REGMAN MOBILE NUMBER", 
				"REGMAN FROMID",
				"UW TOID",
				"UW TOROLE",
                "REGMAN CASE STATUS", 
                "REGMAN REMARKS",
				"REGMAN ALLOCATED DATE", 
				"REGMAN APPROVED DATE",
				"REGMAN TAT",
				"UW MOBILE NUMBER",
				"UW FROMID", 
				"TALICMAN TOID",
				"TALICMAN TOROLE",
				"UW CASE STATUS",
				"UW REMARKS", 
				"UW ALLOCATED DATE",
				"UW APPROVED DATE",
                "UW TAT"
				});
		
		String sql = ";with ctc as (select *,ROW_NUMBER() over(partition by caseid,torole,toid order by updateddate desc) as row1 from AUDIT_CASE_MOVEMENT WHERE toRole = 'REGMAN' AND toId = '')\n"
				+ "								select * into #AUDIT_CASE_MOVEMENT from ctc where row1 = 1\n"
				+ "				\n"
				+ "								--;with ctc as (select *,ROW_NUMBER() over(partition by caseid,torole,toid order by updateddate) as row1 from AUDIT_CASE_MOVEMENT WHERE toRole = 'AGNSUP')\n"
				+ "								--select * into #AUDIT_CASE_MOVEMENT1 from ctc where row1 = 1\n"
				+ "				\n"
				+ "								;with ctc(caseId,fromId,toId,toRole,caseStatus,zone,remarks,createdDate,updatedDate,ROW1) as \n"
				+ "								(select A.caseId,fromId,toId,toRole,A.caseStatus,zone,remarks,A.createdDate,A.updatedDate,ROW_NUMBER() over(partition by A.caseid,torole,toid order by A.updateddate) as row1\n"
				+ "								from AUDIT_CASE_MOVEMENT A\n"
				+ "								INNER JOIN CASE_LISTS B ON A.CASEID = B.CASEID  \n"
				+ "								INNER JOIN ( SELECT ROLE_NAME,username FROM ADMIN_USER ) C ON C.username = A.fromId AND C.role_name IN('REGMAN') WHERE toRole = 'AGNSUP')\n"
				+ "								select * INTO #AUDIT_CASE_MOVEMENT1 FROM ctc where row1 = 1\n"
				+ "				\n"
				+ "				\n"
				+ "								;with ctc as (select *,ROW_NUMBER() over(partition by caseid,torole,toid order by updateddate) as row1 from AUDIT_CASE_MOVEMENT WHERE toRole = 'REGMAN' AND toId NOT IN (''))\n"
				+ "								select * into #AUDIT_CASE_MOVEMENT2 from ctc where row1 = 1\n"
				+ "				\n"
				+ "								;with ctc as (select *,ROW_NUMBER() over(partition by caseid,torole order by updateddate) as row1 from AUDIT_CASE_MOVEMENT WHERE toRole = 'INV')\n"
				+ "								select * into #AUDIT_CASE_MOVEMENT3 from ctc where row1 = 1\n"
				+ "				\n"
				+ "				\n"
				+ "								;with ctc(caseId,fromId,toId,toRole,caseStatus,zone,remarks,createdDate,updatedDate,ROW1) as \n"
				+ "								(select A.caseId,fromId,toId,toRole,A.caseStatus,zone,remarks,A.createdDate,A.updatedDate,ROW_NUMBER() over(partition by A.caseid,torole,toid order by A.updateddate) as row1\n"
				+ "								from AUDIT_CASE_MOVEMENT A\n"
				+ "								INNER JOIN CASE_LISTS B ON A.CASEID = B.CASEID  \n"
				+ "								INNER JOIN ( SELECT ROLE_NAME,username FROM ADMIN_USER ) C ON C.username = A.fromId AND C.role_name IN('INV') WHERE toRole = 'AGNSUP')-- AND A.caseStatus = 'Approved')\n"
				+ "								select * INTO #AUDIT_CASE_MOVEMENT4 FROM ctc where row1 = 1\n"
				+ "								order by updatedDate desc --where row1 = 1\n"
				+ "				\n"
				+ "								;with ctc as (select *,ROW_NUMBER() over(partition by caseid,torole,toid order by updateddate) as row1 from AUDIT_CASE_MOVEMENT WHERE toRole = 'REGMAN' AND caseStatus = 'Approved')\n"
				+ "								select * into #AUDIT_CASE_MOVEMENT5 from ctc where row1 = 1\n"
				+ "				\n"
				+ "								;with ctc(caseId,fromId,toId,toRole,caseStatus,zone,remarks,createdDate,updatedDate,ROW1) as \n"
				+ "								(select A.caseId,fromId,toId,toRole,A.caseStatus,zone,remarks,A.createdDate,A.updatedDate,ROW_NUMBER() over(partition by A.caseid,torole,toid order by A.updateddate) as row1\n"
				+ "								from AUDIT_CASE_MOVEMENT A\n"
				+ "								INNER JOIN CASE_LISTS B ON A.CASEID = B.CASEID  \n"
				+ "								INNER JOIN ( SELECT ROLE_NAME,username FROM ADMIN_USER ) C ON C.username = A.fromId AND C.role_name IN('REGMAN') WHERE toRole = 'UW' AND A.caseStatus = 'Approved')\n"
				+ "								select * INTO #AUDIT_CASE_MOVEMENT6 FROM ctc where row1 = 1\n"
				+ "				\n"
				+ "								;with ctc(caseId,fromId,toId,toRole,caseStatus,zone,remarks,createdDate,updatedDate,ROW1) as \n"
				+ "								(select A.caseId,fromId,toId,toRole,A.caseStatus,zone,remarks,A.createdDate,A.updatedDate,ROW_NUMBER() over(partition by A.caseid,torole,toid order by A.updateddate) as row1\n"
				+ "								from AUDIT_CASE_MOVEMENT A\n"
				+ "								INNER JOIN CASE_LISTS B ON A.CASEID = B.CASEID  \n"
				+ "								INNER JOIN ( SELECT ROLE_NAME,username FROM ADMIN_USER ) C ON C.username = A.fromId AND C.role_name IN('UW') WHERE toRole = 'TALICMAN' AND A.caseStatus = 'Approved')\n"
				+ "								select * INTO #AUDIT_CASE_MOVEMENT7 FROM ctc where row1 = 1\n"
				+ "				\n"
				+ "								--;with ctc(caseId,fromId,toId,toRole,caseStatus,zone,remarks,createdDate,updatedDate,ROW1) as \n"
				+ "								--(select A.caseId,fromId,toId,toRole,A.caseStatus,zone,remarks,A.createdDate,A.updatedDate,ROW_NUMBER() over(partition by A.caseid,torole,toid order by A.updateddate) as row1\n"
				+ "								--from AUDIT_CASE_MOVEMENT A\n"
				+ "								--INNER JOIN CASE_LISTS B ON A.CASEID = B.CASEID  \n"
				+ "								--INNER JOIN ( SELECT ROLE_NAME,username FROM ADMIN_USER ) C ON C.username = A.fromId AND C.role_name IN('INV') WHERE toRole = 'AGNSUP')-- AND A.caseStatus = 'Approved')\n"
				+ "								--select * FROM ctc where  caseId = 147\n"
				+ "				\n"
				+ "								--SELECT * FROM #AUDIT_CASE_MOVEMENT2 WHERE CASEID = 54\n"
				+ "				\n"
				+ "								SELECT\n"
				+ "								CASEID, \n"
				+ "								POLICYNUMBER, \n"
				+ "								NATURE_OF_INVESTIGATION, \n"
				+ "								ISSUEDDATE, \n"
				+ "								INSUREDMOB, \n"
				+ "								INSUREDNAME, \n"
				+ "								INSUREDDOD, \n"
				+ "								INSUREDDOB, \n"
				+ "								INSUREDDIAGNOSISDATE, \n"
				+ "								GENDER, \n"
				+ "								SUMASSURED, \n"
				+ "								INVESTIGATIONTYPE, \n"
				+ "								LOCATIONID, \n"
				+ "								PINCODE, \n"
				+ "								--CASESTATUS, \n"
				+ "								CASESUBSTATUS, \n"
				+ "								NOTCLEANCATEGORY, \n"
				+ "								TRIGGER_NAME, \n"
				+ "								TRIGGER_DEPT, \n"
				+ "								DISPOSITION_NAME, \n"
				+ "								NOMINEE_NAME, \n"
				+ "								NOMINEE_CONTACTNUMBER, \n"
				+ "								NOMINEE_ADDRESS, \n"
				+ "								INSURED_ADDRESS, \n"
				+ "								CASE_DESCRIPTION, \n"
				+ "								LONGITUDE, \n"
				+ "								LATITUDE, \n"
				+ "								CREATEDBY, \n"
				+ "								CREATEDDATE,\n"
				+ "								UPDATEDDATE, \n"
				+ "								UPDATEDBY, \n"
				+ "								CITY,	 \n"
				+ "								STATE, \n"
				+ "								ZONE, \n"
				+ "								--FEES, \n"
				+ "								STATUS, \n"
				+ "								CASE WHEN TOROLE = 'REGMAN' AND TOID = '' THEN MOBILE_NUMBER END [RCU-REGMAN_MOBILE_NUMBER], \n"
				+ "								CASE WHEN TOROLE = 'REGMAN' AND TOID = '' THEN FROMID END [RCU-REGMAN_FROMID], \n"
				+ "								CASE WHEN TOROLE = 'REGMAN' AND TOID = '' THEN TOID END [RCU-REGMAN_TOID], \n"
				+ "								CASE WHEN TOROLE = 'REGMAN' AND TOID = '' THEN TOROLE END [RCU-REGMAN_TOROLE], \n"
				+ "								CASE WHEN TOROLE = 'REGMAN' AND TOID = '' THEN CASESTATUS END [RCU-REGMAN_CASESTATUS], \n"
				+ "								CASE WHEN TOROLE = 'REGMAN' AND TOID = '' THEN REMARKS END [RCU-REGMAN_REMARKS], \n"
				+ "								CASE WHEN TOROLE = 'REGMAN' AND TOID = '' THEN ALLOCATED_DATE END [RCU-REGMAN_ALLOCATED_DATE], \n"
				+ "								CASE WHEN TOROLE = 'REGMAN' AND TOID = '' THEN APPROVED_DATE END [RCU-REGMAN_APPROVED_DATE], \n"
				+ "								CASE WHEN TOROLE = 'REGMAN' AND TOID = '' THEN TAT END [RCU-REGMAN_TAT]\n"
				+ "								INTO #TEMP\n"
				+ "								FROM\n"
				+ "								(\n"
				+ "								SELECT \n"
				+ "								A.CASEID, \n"
				+ "								A.POLICYNUMBER, \n"
				+ "								A.ISSUEDDATE, \n"
				+ "								A.INSUREDMOB, \n"
				+ "								A.INSUREDNAME, \n"
				+ "								A.INSUREDDOD, \n"
				+ "								A.INSUREDDOB, \n"
				+ "								A.INSUREDDIAGNOSISDATE, \n"
				+ "								A.GENDER, \n"
				+ "								A.SUMASSURED, \n"
				+ "								A.INVESTIGATIONTYPE, \n"
				+ "								A.LOCATIONID, \n"
				+ "								A.PINCODE, \n"
				+ "								A.CASESUBSTATUS, \n"
				+ "								A.NOTCLEANCATEGORY, \n"
				+ "								A.TRIGGER_NAME, \n"
				+ "								A.TRIGGER_DEPT, \n"
				+ "								A.DISPOSITION_NAME, \n"
				+ "								A.NOMINEE_NAME, \n"
				+ "								A.NOMINEE_CONTACTNUMBER, \n"
				+ "								A.NOMINEE_ADDRESS, \n"
				+ "								A.INSURED_ADDRESS, \n"
				+ "								A.CASE_DESCRIPTION, \n"
				+ "								A.LONGITUDE, \n"
				+ "								A.LATITUDE, \n"
				+ "								A.CREATEDBY, \n"
				+ "								A.UPDATEDDATE, \n"
				+ "								A.UPDATEDBY, \n"
				+ "												 \n"
				+ "								(SELECT TOP 1 ROLE_NAME FROM ADMIN_USER WHERE USERNAME =B.FROMID  AND  ROLE_NAME IN('REGMAN')) REGMAN,  \n"
				+ "								(SELECT TOP 1 ROLE_NAME FROM ADMIN_USER WHERE USERNAME = B.FROMID AND  ROLE_NAME IN('AGNSUP'))  AGNSUP, \n"
				+ "								(SELECT TOP 1 ROLE_NAME FROM ADMIN_USER WHERE USERNAME = B.FROMID AND  ROLE_NAME IN('INV'))  INV, \n"
				+ "								(SELECT TOP 1 ROLE_NAME FROM ADMIN_USER WHERE USERNAME = B.FROMID AND  ROLE_NAME IN('UW'))  UW, \n"
				+ "								(SELECT TOP 1 ROLE_NAME FROM ADMIN_USER WHERE USERNAME = B.FROMID AND  ROLE_NAME IN('TALICMAN')) TALICMAN, \n"
				+ "												 \n"
				+ "								(SELECT TOP 1 CITY FROM LOCATION_LISTS WHERE LOCATIONID = A.LOCATIONID) CITY, \n"
				+ "								(SELECT TOP 1 STATE FROM LOCATION_LISTS WHERE LOCATIONID = A.LOCATIONID) STATE,   \n"
				+ "								(SELECT TOP 1 ZONE FROM LOCATION_LISTS WHERE LOCATIONID = A.LOCATIONID) ZONE,   \n"
				+ "								(SELECT NATURE_OF_INVESTIGATIONTYPE FROM NATURE_OF_INVESTIGATION WHERE NATURE_OF_INVESTIGATIONID = A.NATURE_OF_INVESTIGATIONID) AS NATURE_OF_INVESTIGATION,   \n"
				+ "								ISNULL((SELECT TOP 1 MOBILE_NUMBER FROM ADMIN_USER WHERE USERNAME = ISNULL(B.FROMID,'')),'') AS MOBILE_NUMBER,   \n"
				+ "								ISNULL((SELECT TOP 1 FULL_NAME  FROM ADMIN_USER WHERE USERNAME = B.FROMID),'') AS FROMID, \n"
				+ "								ISNULL((SELECT TOP 1 FULL_NAME FROM ADMIN_USER WHERE USERNAME = B.TOID),'') AS TOID,    \n"
				+ "								B.TOROLE, \n"
				+ "								B.CASESTATUS CASESTATUS, \n"
				+ "								B.REMARKS REMARKS, \n"
				+ "								B.CREATEDDATE, \n"
				+ "								LAG(B.UPDATEDDATE, 1,B.CREATEDDATE) OVER(PARTITION BY A.CASEID ORDER BY B.UPDATEDDATE ASC) AS ALLOCATED_DATE, \n"
				+ "								B.UPDATEDDATE AS APPROVED_DATE, \n"
				+ "								DATEDIFF(DAY,LAG(B.UPDATEDDATE, 1,B.CREATEDDATE) OVER(PARTITION BY A.CASEID ORDER BY B.UPDATEDDATE ASC), B.UPDATEDDATE) AS TAT, \n"
				+ "								ISNULL((SELECT FEES FROM ADMIN_USER X LEFT OUTER JOIN USER_FEES Y ON X.USERNAME = Y.USERNAME \n"
				+ "								WHERE X.USERNAME = B.TOID AND Y.INVESTIGATIONTYPE = A.INVESTIGATIONTYPE AND FROMID IN(SELECT USERNAME FROM ADMIN_USER WHERE ROLE_NAME ='REGMAN') AND X.ROLE_NAME ='AGNSUP'),0) AS FEES , \n"
				+ "								CASE ISNULL((SELECT FEES FROM ADMIN_USER X LEFT OUTER JOIN USER_FEES Y ON X.USERNAME = Y.USERNAME \n"
				+ "								WHERE X.USERNAME = B.TOID AND Y.INVESTIGATIONTYPE = A.INVESTIGATIONTYPE AND FROMID IN(SELECT USERNAME FROM ADMIN_USER WHERE ROLE_NAME ='REGMAN') AND X.ROLE_NAME ='AGNSUP' \n"
				+ "								AND A.CASESTATUS = 'CLOSED' \n"
				+ "								AND A.CASEID  IN (SELECT CASEID FROM CASE_PAYMENT WHERE USERID = B.TOID) \n"
				+ "								),0) \n"
				+ "								WHEN 0.00 THEN ' ' ELSE 'Y'  END AS STATUS \n"
				+ "								FROM CASE_LISTS A \n"
				+ "								LEFT OUTER JOIN \n"
				+ "								#AUDIT_CASE_MOVEMENT B ON A.CASEID = B.CASEID  \n"
				+ "								WHERE A.CASEID=B.CASEID AND CONVERT(DATE, A.CREATEDDATE) BETWEEN ? AND ?  \n"
				+ "								--AND A.CASEID IN (147)\n"
				+ "								) A		\n"
				+ "				\n"
				+ "								SELECT\n"
				+ "								CASEID,\n"
				+ "								CASE WHEN TOROLE = 'AGNSUP' AND  (REGMAN IS NOT NULL OR REGMAN NOT IN (''))  AND REGMAN='REGMAN' THEN MOBILE_NUMBER END [REGMAN-AGNSUP_MOBILE_NUMBER], \n"
				+ "								CASE WHEN TOROLE = 'AGNSUP' AND  (REGMAN IS NOT NULL OR REGMAN NOT IN (''))  AND REGMAN='REGMAN' THEN FROMID END [REGMAN-AGNSUP_FROMID], \n"
				+ "								CASE WHEN TOROLE = 'AGNSUP' AND  (REGMAN IS NOT NULL OR REGMAN NOT IN (''))  AND REGMAN='REGMAN' THEN TOID END [REGMAN-AGNSUP_TOID], \n"
				+ "								CASE WHEN TOROLE = 'AGNSUP' AND  (REGMAN IS NOT NULL OR REGMAN NOT IN (''))  AND REGMAN='REGMAN' THEN TOROLE END [REGMAN-AGNSUP_TOROLE], \n"
				+ "								CASE WHEN TOROLE = 'AGNSUP' AND  (REGMAN IS NOT NULL OR REGMAN NOT IN (''))  AND REGMAN='REGMAN' THEN CASESTATUS END [REGMAN-AGNSUP_CASESTATUS], \n"
				+ "								CASE WHEN TOROLE = 'AGNSUP' AND  (REGMAN IS NOT NULL OR REGMAN NOT IN (''))  AND REGMAN='REGMAN' THEN REMARKS END [REGMAN-AGNSUP_REMARKS], \n"
				+ "								CASE WHEN TOROLE = 'AGNSUP' AND  (REGMAN IS NOT NULL OR REGMAN NOT IN (''))  AND REGMAN='REGMAN' THEN ALLOCATED_DATE END [REGMAN-AGNSUP_ALLOCATED_DATE], \n"
				+ "								CASE WHEN TOROLE = 'AGNSUP' AND  (REGMAN IS NOT NULL OR REGMAN NOT IN (''))  AND REGMAN='REGMAN' THEN APPROVED_DATE END [REGMAN-AGNSUP_APPROVED_DATE], \n"
				+ "								CASE WHEN TOROLE = 'AGNSUP' AND  (REGMAN IS NOT NULL OR REGMAN NOT IN (''))  AND REGMAN='REGMAN' THEN TAT END [REGMAN-AGNSUP_TAT],\n"
				+ "								isnull(FEES,0) FEES				    \n"
				+ "								INTO #TEMP1\n"
				+ "								FROM\n"
				+ "								(\n"
				+ "								SELECT \n"
				+ "								A.CASEID, \n"
				+ "								(SELECT TOP 1 ROLE_NAME FROM ADMIN_USER WHERE USERNAME =B.FROMID  AND  ROLE_NAME IN('REGMAN')) REGMAN,  \n"
				+ "								(SELECT TOP 1 ROLE_NAME FROM ADMIN_USER WHERE USERNAME = B.FROMID AND  ROLE_NAME IN('AGNSUP'))  AGNSUP, \n"
				+ "								(SELECT TOP 1 ROLE_NAME FROM ADMIN_USER WHERE USERNAME = B.FROMID AND  ROLE_NAME IN('INV'))  INV, \n"
				+ "								(SELECT TOP 1 ROLE_NAME FROM ADMIN_USER WHERE USERNAME = B.FROMID AND  ROLE_NAME IN('UW'))  UW, \n"
				+ "								(SELECT TOP 1 ROLE_NAME FROM ADMIN_USER WHERE USERNAME = B.FROMID AND  ROLE_NAME IN('TALICMAN')) TALICMAN,   \n"
				+ "								ISNULL((SELECT TOP 1 MOBILE_NUMBER FROM ADMIN_USER WHERE USERNAME = ISNULL(B.FROMID,'')),'') AS MOBILE_NUMBER,   \n"
				+ "								ISNULL((SELECT TOP 1 FULL_NAME  FROM ADMIN_USER WHERE USERNAME = B.FROMID),'') AS FROMID, \n"
				+ "								ISNULL((SELECT TOP 1 FULL_NAME FROM ADMIN_USER WHERE USERNAME = B.TOID),'') AS TOID,    \n"
				+ "								B.TOROLE, \n"
				+ "								B.CASESTATUS CASESTATUS, \n"
				+ "								B.REMARKS REMARKS, \n"
				+ "								LAG(B.UPDATEDDATE, 1,B.CREATEDDATE) OVER(PARTITION BY A.CASEID ORDER BY B.UPDATEDDATE ASC) AS ALLOCATED_DATE, \n"
				+ "								B.UPDATEDDATE AS APPROVED_DATE, \n"
				+ "								DATEDIFF(DAY,LAG(B.UPDATEDDATE, 1,B.CREATEDDATE) OVER(PARTITION BY A.CASEID ORDER BY B.UPDATEDDATE ASC), B.UPDATEDDATE) AS TAT,\n"
				+ "								ISNULL((SELECT TOP 1 FEES FROM ADMIN_USER X LEFT OUTER JOIN USER_FEES Y ON X.USERNAME = Y.USERNAME \n"
				+ "								WHERE X.USERNAME = B.TOID AND Y.INVESTIGATIONTYPE = A.INVESTIGATIONTYPE AND FROMID IN(SELECT TOP 1 USERNAME FROM ADMIN_USER WHERE ROLE_NAME ='REGMAN') AND X.ROLE_NAME ='AGNSUP'),0) AS FEES \n"
				+ "								FROM CASE_LISTS A \n"
				+ "								LEFT OUTER JOIN \n"
				+ "								#AUDIT_CASE_MOVEMENT1 B ON A.CASEID = B.CASEID  \n"
				+ "								WHERE A.CASEID=B.CASEID AND CONVERT(DATE, A.CREATEDDATE) BETWEEN ? AND ?  \n"
				+ "								--AND A.CASEID IN (147)\n"
				+ "								) A	\n"
				+ "				\n"
				+ "				\n"
				+ "								SELECT\n"
				+ "								CASEID,\n"
				+ "								CASE WHEN TOROLE = 'REGMAN'  AND  (AGNSUP IS NOT NULL OR AGNSUP NOT IN (''))  AND AGNSUP='AGNSUP'  THEN MOBILE_NUMBER END [AGNSUP-REGMAN_MOBILE_NUMBER], \n"
				+ "								CASE WHEN TOROLE = 'REGMAN'  AND  (AGNSUP IS NOT NULL OR AGNSUP NOT IN (''))  AND AGNSUP='AGNSUP'  THEN FROMID END [AGNSUP-REGMAN_FROMID], \n"
				+ "								CASE WHEN TOROLE = 'REGMAN'  AND  (AGNSUP IS NOT NULL OR AGNSUP NOT IN (''))  AND AGNSUP='AGNSUP'  THEN TOID END [AGNSUP-REGMAN_TOID], \n"
				+ "								CASE WHEN TOROLE = 'REGMAN'  AND  (AGNSUP IS NOT NULL OR AGNSUP NOT IN (''))  AND AGNSUP='AGNSUP'  THEN TOROLE END [AGNSUP-REGMAN_TOROLE], \n"
				+ "								CASE WHEN TOROLE = 'REGMAN'  AND  (AGNSUP IS NOT NULL OR AGNSUP NOT IN (''))  AND AGNSUP='AGNSUP'  THEN CASESTATUS END [AGNSUP-REGMAN_CASESTATUS], \n"
				+ "								CASE WHEN TOROLE = 'REGMAN'  AND  (AGNSUP IS NOT NULL OR AGNSUP NOT IN (''))  AND AGNSUP='AGNSUP'  THEN REMARKS END [AGNSUP-REGMAN_REMARKS], \n"
				+ "								CASE WHEN TOROLE = 'REGMAN'  AND  (AGNSUP IS NOT NULL OR AGNSUP NOT IN (''))  AND AGNSUP='AGNSUP'  THEN ALLOCATED_DATE END [AGNSUP-REGMAN_ALLOCATED_DATE], \n"
				+ "								CASE WHEN TOROLE = 'REGMAN'  AND  (AGNSUP IS NOT NULL OR AGNSUP NOT IN (''))  AND AGNSUP='AGNSUP'  THEN APPROVED_DATE END [AGNSUP-REGMAN_APPROVED_DATE], \n"
				+ "								CASE WHEN TOROLE = 'REGMAN'  AND  (AGNSUP IS NOT NULL OR AGNSUP NOT IN (''))  AND AGNSUP='AGNSUP'  THEN TAT END [AGNSUP-REGMAN_TAT]			\n"
				+ "								INTO #TEMP2\n"
				+ "								FROM\n"
				+ "								(\n"
				+ "								SELECT \n"
				+ "								A.CASEID, \n"
				+ "								(SELECT TOP 1 ROLE_NAME FROM ADMIN_USER WHERE USERNAME =B.FROMID  AND  ROLE_NAME IN('REGMAN')) REGMAN,  \n"
				+ "								(SELECT TOP 1 ROLE_NAME FROM ADMIN_USER WHERE USERNAME = B.FROMID AND  ROLE_NAME IN('AGNSUP'))  AGNSUP, \n"
				+ "								(SELECT TOP 1 ROLE_NAME FROM ADMIN_USER WHERE USERNAME = B.FROMID AND  ROLE_NAME IN('INV'))  INV, \n"
				+ "								(SELECT TOP 1 ROLE_NAME FROM ADMIN_USER WHERE USERNAME = B.FROMID AND  ROLE_NAME IN('UW'))  UW, \n"
				+ "								(SELECT TOP 1 ROLE_NAME FROM ADMIN_USER WHERE USERNAME = B.FROMID AND  ROLE_NAME IN('TALICMAN')) TALICMAN,   \n"
				+ "								ISNULL((SELECT TOP 1 MOBILE_NUMBER FROM ADMIN_USER WHERE USERNAME = ISNULL(B.FROMID,'')),'') AS MOBILE_NUMBER,   \n"
				+ "								ISNULL((SELECT TOP 1 FULL_NAME  FROM ADMIN_USER WHERE USERNAME = B.FROMID),'') AS FROMID, \n"
				+ "								ISNULL((SELECT TOP 1 FULL_NAME FROM ADMIN_USER WHERE USERNAME = B.TOID),'') AS TOID,    \n"
				+ "								B.TOROLE, \n"
				+ "								B.CASESTATUS CASESTATUS, \n"
				+ "								B.REMARKS REMARKS, \n"
				+ "								LAG(B.UPDATEDDATE, 1,B.CREATEDDATE) OVER(PARTITION BY A.CASEID ORDER BY B.UPDATEDDATE ASC) AS ALLOCATED_DATE, \n"
				+ "								B.UPDATEDDATE AS APPROVED_DATE, \n"
				+ "								DATEDIFF(DAY,LAG(B.UPDATEDDATE, 1,B.CREATEDDATE) OVER(PARTITION BY A.CASEID ORDER BY B.UPDATEDDATE ASC), B.UPDATEDDATE) AS TAT\n"
				+ "								FROM CASE_LISTS A \n"
				+ "								LEFT OUTER JOIN \n"
				+ "								#AUDIT_CASE_MOVEMENT2 B ON A.CASEID = B.CASEID  \n"
				+ "								WHERE A.CASEID=B.CASEID AND CONVERT(DATE, A.CREATEDDATE) BETWEEN ? AND ?  \n"
				+ "								--AND A.CASEID IN (147)\n"
				+ "								) A\n"
				+ "				\n"
				+ "				\n"
				+ "								SELECT\n"
				+ "								CASEID, \n"
				+ "								(CASE WHEN TOROLE = 'INV'  AND  (AGNSUP IS NOT NULL OR AGNSUP NOT IN (''))  AND AGNSUP='AGNSUP' THEN MOBILE_NUMBER END) [AGNSUP-INV_MOBILE_NUMBER], \n"
				+ "								(CASE WHEN TOROLE = 'INV'  AND  (AGNSUP IS NOT NULL OR AGNSUP NOT IN (''))  AND AGNSUP='AGNSUP' THEN FROMID END) [AGNSUP-INV_FROMID], \n"
				+ "								(CASE WHEN TOROLE = 'INV'  AND  (AGNSUP IS NOT NULL OR AGNSUP NOT IN (''))  AND AGNSUP='AGNSUP' THEN TOID END) [AGNSUP-INV_TOID], \n"
				+ "								(CASE WHEN TOROLE = 'INV'  AND  (AGNSUP IS NOT NULL OR AGNSUP NOT IN (''))  AND AGNSUP='AGNSUP' THEN TOROLE END) [AGNSUP-INV_TOROLE], \n"
				+ "								(CASE WHEN TOROLE = 'INV'  AND  (AGNSUP IS NOT NULL OR AGNSUP NOT IN (''))  AND AGNSUP='AGNSUP' THEN CASESTATUS END) [AGNSUP-INV_CASESTATUS], \n"
				+ "								(CASE WHEN TOROLE = 'INV'  AND  (AGNSUP IS NOT NULL OR AGNSUP NOT IN (''))  AND AGNSUP='AGNSUP' THEN REMARKS END) [AGNSUP-INV_REMARKS], \n"
				+ "								(CASE WHEN TOROLE = 'INV'  AND  (AGNSUP IS NOT NULL OR AGNSUP NOT IN (''))  AND AGNSUP='AGNSUP' THEN ALLOCATED_DATE END) [AGNSUP-INV_ALLOCATED_DATE], \n"
				+ "								(CASE WHEN TOROLE = 'INV'  AND  (AGNSUP IS NOT NULL OR AGNSUP NOT IN (''))  AND AGNSUP='AGNSUP' THEN APPROVED_DATE END) [AGNSUP-INV_APPROVED_DATE], \n"
				+ "								(CASE WHEN TOROLE = 'INV'  AND  (AGNSUP IS NOT NULL OR AGNSUP NOT IN (''))  AND AGNSUP='AGNSUP' THEN TAT END) [AGNSUP-INV_TAT] 	\n"
				+ "								INTO #TEMP3\n"
				+ "								FROM\n"
				+ "								(\n"
				+ "								SELECT \n"
				+ "								A.CASEID, \n"
				+ "								(SELECT TOP 1 ROLE_NAME FROM ADMIN_USER WHERE USERNAME =B.FROMID  AND  ROLE_NAME IN('REGMAN')) REGMAN,  \n"
				+ "								(SELECT TOP 1 ROLE_NAME FROM ADMIN_USER WHERE USERNAME = B.FROMID AND  ROLE_NAME IN('AGNSUP'))  AGNSUP, \n"
				+ "								(SELECT TOP 1 ROLE_NAME FROM ADMIN_USER WHERE USERNAME = B.FROMID AND  ROLE_NAME IN('INV'))  INV, \n"
				+ "								(SELECT TOP 1 ROLE_NAME FROM ADMIN_USER WHERE USERNAME = B.FROMID AND  ROLE_NAME IN('UW'))  UW, \n"
				+ "								(SELECT TOP 1 ROLE_NAME FROM ADMIN_USER WHERE USERNAME = B.FROMID AND  ROLE_NAME IN('TALICMAN')) TALICMAN,   \n"
				+ "								ISNULL((SELECT TOP 1 MOBILE_NUMBER FROM ADMIN_USER WHERE USERNAME = ISNULL(B.FROMID,'')),'') AS MOBILE_NUMBER,   \n"
				+ "								ISNULL((SELECT TOP 1 FULL_NAME  FROM ADMIN_USER WHERE USERNAME = B.FROMID),'') AS FROMID, \n"
				+ "								ISNULL((SELECT TOP 1 FULL_NAME FROM ADMIN_USER WHERE USERNAME = B.TOID),'') AS TOID,    \n"
				+ "								B.TOROLE, \n"
				+ "								B.CASESTATUS CASESTATUS, \n"
				+ "								B.REMARKS REMARKS, \n"
				+ "								LAG(B.UPDATEDDATE, 1,B.CREATEDDATE) OVER(PARTITION BY A.CASEID ORDER BY B.UPDATEDDATE ASC) AS ALLOCATED_DATE, \n"
				+ "								B.UPDATEDDATE AS APPROVED_DATE, \n"
				+ "								DATEDIFF(DAY,LAG(B.UPDATEDDATE, 1,B.CREATEDDATE) OVER(PARTITION BY A.CASEID ORDER BY B.UPDATEDDATE ASC), B.UPDATEDDATE) AS TAT\n"
				+ "								FROM CASE_LISTS A \n"
				+ "								LEFT OUTER JOIN \n"
				+ "								#AUDIT_CASE_MOVEMENT3 B ON A.CASEID = B.CASEID  \n"
				+ "								WHERE A.CASEID=B.CASEID AND CONVERT(DATE, A.CREATEDDATE) BETWEEN ? AND ?  \n"
				+ "								--AND A.CASEID IN (147)\n"
				+ "								) A\n"
				+ "				\n"
				+ "				\n"
				+ "								SELECT\n"
				+ "								CASEID, \n"
				+ "								(CASE WHEN TOROLE = 'AGNSUP'  AND  (INV IS NOT NULL OR INV NOT IN (''))  AND INV='INV'  THEN MOBILE_NUMBER END) [INV-AGNSUP_MOBILE_NUMBER], \n"
				+ "								(CASE WHEN TOROLE = 'AGNSUP'  AND  (INV IS NOT NULL OR INV NOT IN (''))  AND INV='INV'  THEN FROMID END) [INV-AGNSUP_FROMID], \n"
				+ "								(CASE WHEN TOROLE = 'AGNSUP'  AND  (INV IS NOT NULL OR INV NOT IN (''))  AND INV='INV'  THEN TOID END) [INV-AGNSUP_TOID], \n"
				+ "								(CASE WHEN TOROLE = 'AGNSUP'  AND  (INV IS NOT NULL OR INV NOT IN (''))  AND INV='INV'  THEN TOROLE END) [INV-AGNSUP_TOROLE], \n"
				+ "								(CASE WHEN TOROLE = 'AGNSUP'  AND  (INV IS NOT NULL OR INV NOT IN (''))  AND INV='INV'  THEN CASESTATUS END) [INV-AGNSUP_CASESTATUS], \n"
				+ "								(CASE WHEN TOROLE = 'AGNSUP'  AND  (INV IS NOT NULL OR INV NOT IN (''))  AND INV='INV'  THEN REMARKS END) [INV-AGNSUP_REMARKS], \n"
				+ "								(CASE WHEN TOROLE = 'AGNSUP'  AND  (INV IS NOT NULL OR INV NOT IN (''))  AND INV='INV'  THEN ALLOCATED_DATE END) [INV-AGNSUP_ALLOCATED_DATE], \n"
				+ "								(CASE WHEN TOROLE = 'AGNSUP'  AND  (INV IS NOT NULL OR INV NOT IN (''))  AND INV='INV'  THEN APPROVED_DATE END) [INV-AGNSUP_APPROVED_DATE], \n"
				+ "								(CASE WHEN TOROLE = 'AGNSUP'  AND  (INV IS NOT NULL OR INV NOT IN (''))  AND INV='INV'  THEN TAT END) [INV-AGNSUP_TAT] \n"
				+ "								INTO #TEMP4\n"
				+ "								FROM\n"
				+ "								(\n"
				+ "								SELECT \n"
				+ "								A.CASEID, \n"
				+ "								(SELECT TOP 1 ROLE_NAME FROM ADMIN_USER WHERE USERNAME =B.FROMID  AND  ROLE_NAME IN('REGMAN')) REGMAN,  \n"
				+ "								(SELECT TOP 1 ROLE_NAME FROM ADMIN_USER WHERE USERNAME = B.FROMID AND  ROLE_NAME IN('AGNSUP'))  AGNSUP, \n"
				+ "								(SELECT TOP 1 ROLE_NAME FROM ADMIN_USER WHERE USERNAME = B.FROMID AND  ROLE_NAME IN('INV'))  INV, \n"
				+ "								(SELECT TOP 1 ROLE_NAME FROM ADMIN_USER WHERE USERNAME = B.FROMID AND  ROLE_NAME IN('UW'))  UW, \n"
				+ "								(SELECT TOP 1 ROLE_NAME FROM ADMIN_USER WHERE USERNAME = B.FROMID AND  ROLE_NAME IN('TALICMAN')) TALICMAN,   \n"
				+ "								ISNULL((SELECT TOP 1 MOBILE_NUMBER FROM ADMIN_USER WHERE USERNAME = ISNULL(B.FROMID,'')),'') AS MOBILE_NUMBER,   \n"
				+ "								ISNULL((SELECT TOP 1 FULL_NAME  FROM ADMIN_USER WHERE USERNAME = B.FROMID),'') AS FROMID, \n"
				+ "								ISNULL((SELECT TOP 1 FULL_NAME FROM ADMIN_USER WHERE USERNAME = B.TOID),'') AS TOID,    \n"
				+ "								B.TOROLE, \n"
				+ "								B.CASESTATUS CASESTATUS, \n"
				+ "								B.REMARKS REMARKS, \n"
				+ "								LAG(B.UPDATEDDATE, 1,B.CREATEDDATE) OVER(PARTITION BY A.CASEID ORDER BY B.UPDATEDDATE ASC) AS ALLOCATED_DATE, \n"
				+ "								B.UPDATEDDATE AS APPROVED_DATE, \n"
				+ "								DATEDIFF(DAY,LAG(B.UPDATEDDATE, 1,B.CREATEDDATE) OVER(PARTITION BY A.CASEID ORDER BY B.UPDATEDDATE ASC), B.UPDATEDDATE) AS TAT\n"
				+ "								FROM CASE_LISTS A \n"
				+ "								LEFT OUTER JOIN \n"
				+ "								#AUDIT_CASE_MOVEMENT4 B ON A.CASEID = B.CASEID  \n"
				+ "								WHERE A.CASEID=B.CASEID AND CONVERT(DATE, A.CREATEDDATE) BETWEEN ? AND ?  \n"
				+ "								--AND A.CASEID IN (147)\n"
				+ "								) A\n"
				+ "				\n"
				+ "				\n"
				+ "				\n"
				+ "								SELECT\n"
				+ "								CASEID, \n"
				+ "								(CASE WHEN TOROLE = 'REGMAN'  AND  (AGNSUP IS NOT NULL OR AGNSUP NOT IN (''))  AND AGNSUP='AGNSUP'  THEN MOBILE_NUMBER END) [AGNSUP-REGMAN_MOBILE_NUMBER], \n"
				+ "								(CASE WHEN TOROLE = 'REGMAN'  AND  (AGNSUP IS NOT NULL OR AGNSUP NOT IN (''))  AND AGNSUP='AGNSUP'  THEN FROMID END) [AGNSUP-REGMAN_FROMID], \n"
				+ "								(CASE WHEN TOROLE = 'REGMAN'  AND  (AGNSUP IS NOT NULL OR AGNSUP NOT IN (''))  AND AGNSUP='AGNSUP'  THEN TOID END) [AGNSUP-REGMAN_TOID], \n"
				+ "								(CASE WHEN TOROLE = 'REGMAN'  AND  (AGNSUP IS NOT NULL OR AGNSUP NOT IN (''))  AND AGNSUP='AGNSUP'  THEN TOROLE END) [AGNSUP-REGMAN_TOROLE], \n"
				+ "								(CASE WHEN TOROLE = 'REGMAN'  AND  (AGNSUP IS NOT NULL OR AGNSUP NOT IN (''))  AND AGNSUP='AGNSUP'  THEN CASESTATUS END) [AGNSUP-REGMAN_CASESTATUS], \n"
				+ "								(CASE WHEN TOROLE = 'REGMAN'  AND  (AGNSUP IS NOT NULL OR AGNSUP NOT IN (''))  AND AGNSUP='AGNSUP'  THEN REMARKS END) [AGNSUP-REGMAN_REMARKS], \n"
				+ "								(CASE WHEN TOROLE = 'REGMAN'  AND  (AGNSUP IS NOT NULL OR AGNSUP NOT IN (''))  AND AGNSUP='AGNSUP'  THEN ALLOCATED_DATE END) [AGNSUP-REGMAN_ALLOCATED_DATE], \n"
				+ "								(CASE WHEN TOROLE = 'REGMAN'  AND  (AGNSUP IS NOT NULL OR AGNSUP NOT IN (''))  AND AGNSUP='AGNSUP'  THEN APPROVED_DATE END) [AGNSUP-REGMAN_APPROVED_DATE], \n"
				+ "								(CASE WHEN TOROLE = 'REGMAN'  AND  (AGNSUP IS NOT NULL OR AGNSUP NOT IN (''))  AND AGNSUP='AGNSUP'  THEN TAT END) [AGNSUP-REGMAN_TAT] \n"
				+ "								INTO #TEMP5\n"
				+ "								FROM\n"
				+ "								(\n"
				+ "								SELECT \n"
				+ "								A.CASEID, \n"
				+ "								(SELECT TOP 1 ROLE_NAME FROM ADMIN_USER WHERE USERNAME =B.FROMID  AND  ROLE_NAME IN('REGMAN')) REGMAN,  \n"
				+ "								(SELECT TOP 1 ROLE_NAME FROM ADMIN_USER WHERE USERNAME = B.FROMID AND  ROLE_NAME IN('AGNSUP'))  AGNSUP, \n"
				+ "								(SELECT TOP 1 ROLE_NAME FROM ADMIN_USER WHERE USERNAME = B.FROMID AND  ROLE_NAME IN('INV'))  INV, \n"
				+ "								(SELECT TOP 1 ROLE_NAME FROM ADMIN_USER WHERE USERNAME = B.FROMID AND  ROLE_NAME IN('UW'))  UW, \n"
				+ "								(SELECT TOP 1 ROLE_NAME FROM ADMIN_USER WHERE USERNAME = B.FROMID AND  ROLE_NAME IN('TALICMAN')) TALICMAN,   \n"
				+ "								ISNULL((SELECT TOP 1  MOBILE_NUMBER FROM ADMIN_USER WHERE USERNAME = ISNULL(B.FROMID,'')),'') AS MOBILE_NUMBER,   \n"
				+ "								ISNULL((SELECT TOP 1  FULL_NAME  FROM ADMIN_USER WHERE USERNAME = B.FROMID),'') AS FROMID, \n"
				+ "								ISNULL((SELECT TOP 1  FULL_NAME FROM ADMIN_USER WHERE USERNAME = B.TOID),'') AS TOID,    \n"
				+ "								B.TOROLE, \n"
				+ "								B.CASESTATUS CASESTATUS, \n"
				+ "								B.REMARKS REMARKS, \n"
				+ "								LAG(B.UPDATEDDATE, 1,B.CREATEDDATE) OVER(PARTITION BY A.CASEID ORDER BY B.UPDATEDDATE ASC) AS ALLOCATED_DATE, \n"
				+ "								B.UPDATEDDATE AS APPROVED_DATE, \n"
				+ "								DATEDIFF(DAY,LAG(B.UPDATEDDATE, 1,B.CREATEDDATE) OVER(PARTITION BY A.CASEID ORDER BY B.UPDATEDDATE ASC), B.UPDATEDDATE) AS TAT\n"
				+ "								FROM CASE_LISTS A \n"
				+ "								LEFT OUTER JOIN \n"
				+ "								#AUDIT_CASE_MOVEMENT5 B ON A.CASEID = B.CASEID  \n"
				+ "								WHERE A.CASEID=B.CASEID AND CONVERT(DATE, A.CREATEDDATE) BETWEEN ? AND ?  \n"
				+ "								--AND A.CASEID IN (147)\n"
				+ "								) A\n"
				+ "				\n"
				+ "								SELECT\n"
				+ "								CASEID, \n"
				+ "								CASE WHEN TOROLE = 'UW'  AND  (REGMAN IS NOT NULL OR REGMAN NOT IN (''))  AND REGMAN='REGMAN'  THEN MOBILE_NUMBER END [REGMAN-UW_MOBILE_NUMBER], \n"
				+ "								CASE WHEN TOROLE = 'UW'  AND  (REGMAN IS NOT NULL OR REGMAN NOT IN (''))  AND REGMAN='REGMAN'  THEN FROMID END [REGMAN-UW_FROMID], \n"
				+ "								CASE WHEN TOROLE = 'UW'  AND  (REGMAN IS NOT NULL OR REGMAN NOT IN (''))  AND REGMAN='REGMAN'  THEN TOID END [REGMAN-UW_TOID], \n"
				+ "								CASE WHEN TOROLE = 'UW'  AND  (REGMAN IS NOT NULL OR REGMAN NOT IN (''))  AND REGMAN='REGMAN'  THEN TOROLE END [REGMAN-UW_TOROLE], \n"
				+ "								CASE WHEN TOROLE = 'UW'  AND  (REGMAN IS NOT NULL OR REGMAN NOT IN (''))  AND REGMAN='REGMAN'  THEN CASESTATUS END [REGMAN-UW_CASESTATUS], \n"
				+ "								CASE WHEN TOROLE = 'UW'  AND  (REGMAN IS NOT NULL OR REGMAN NOT IN (''))  AND REGMAN='REGMAN'  THEN REMARKS END [REGMAN-UW_REMARKS], \n"
				+ "								CASE WHEN TOROLE = 'UW'  AND  (REGMAN IS NOT NULL OR REGMAN NOT IN (''))  AND REGMAN='REGMAN'  THEN ALLOCATED_DATE END [REGMAN-UW_ALLOCATED_DATE], \n"
				+ "								CASE WHEN TOROLE = 'UW'  AND  (REGMAN IS NOT NULL OR REGMAN NOT IN (''))  AND REGMAN='REGMAN'  THEN APPROVED_DATE END [REGMAN-UW_APPROVED_DATE], \n"
				+ "								CASE WHEN TOROLE = 'UW'  AND  (REGMAN IS NOT NULL OR REGMAN NOT IN (''))  AND REGMAN='REGMAN'  THEN TAT END [REGMAN-UW_TAT]\n"
				+ "								INTO #TEMP6\n"
				+ "								FROM\n"
				+ "								(\n"
				+ "								SELECT \n"
				+ "								A.CASEID, \n"
				+ "								(SELECT TOP 1 ROLE_NAME FROM ADMIN_USER WHERE USERNAME =B.FROMID  AND  ROLE_NAME IN('REGMAN')) REGMAN,  \n"
				+ "								(SELECT TOP 1 ROLE_NAME FROM ADMIN_USER WHERE USERNAME = B.FROMID AND  ROLE_NAME IN('AGNSUP'))  AGNSUP, \n"
				+ "								(SELECT TOP 1 ROLE_NAME FROM ADMIN_USER WHERE USERNAME = B.FROMID AND  ROLE_NAME IN('INV'))  INV, \n"
				+ "								(SELECT TOP 1 ROLE_NAME FROM ADMIN_USER WHERE USERNAME = B.FROMID AND  ROLE_NAME IN('UW'))  UW, \n"
				+ "								(SELECT TOP 1 ROLE_NAME FROM ADMIN_USER WHERE USERNAME = B.FROMID AND  ROLE_NAME IN('TALICMAN')) TALICMAN,   \n"
				+ "								ISNULL((SELECT TOP 1 MOBILE_NUMBER FROM ADMIN_USER WHERE USERNAME = ISNULL(B.FROMID,'')),'') AS MOBILE_NUMBER,   \n"
				+ "								ISNULL((SELECT TOP 1 FULL_NAME  FROM ADMIN_USER WHERE USERNAME = B.FROMID),'') AS FROMID, \n"
				+ "								ISNULL((SELECT TOP 1 FULL_NAME FROM ADMIN_USER WHERE USERNAME = B.TOID),'') AS TOID,    \n"
				+ "								B.TOROLE, \n"
				+ "								B.CASESTATUS CASESTATUS, \n"
				+ "								B.REMARKS REMARKS, \n"
				+ "								LAG(B.UPDATEDDATE, 1,B.CREATEDDATE) OVER(PARTITION BY A.CASEID ORDER BY B.UPDATEDDATE ASC) AS ALLOCATED_DATE, \n"
				+ "								B.UPDATEDDATE AS APPROVED_DATE, \n"
				+ "								DATEDIFF(DAY,LAG(B.UPDATEDDATE, 1,B.CREATEDDATE) OVER(PARTITION BY A.CASEID ORDER BY B.UPDATEDDATE ASC), B.UPDATEDDATE) AS TAT\n"
				+ "								FROM CASE_LISTS A \n"
				+ "								LEFT OUTER JOIN \n"
				+ "								#AUDIT_CASE_MOVEMENT6 B ON A.CASEID = B.CASEID  \n"
				+ "								WHERE A.CASEID=B.CASEID AND CONVERT(DATE, A.CREATEDDATE) BETWEEN ? AND ?  \n"
				+ "								--AND A.CASEID IN (147)\n"
				+ "								) A\n"
				+ "				\n"
				+ "								SELECT\n"
				+ "								CASEID, \n"
				+ "								CASE WHEN TOROLE = 'TALICMAN'   AND  (UW IS NOT NULL OR UW NOT IN (''))  AND UW='UW'  THEN MOBILE_NUMBER END [UW-TALICMAN_MOBILE_NUMBER], \n"
				+ "								CASE WHEN TOROLE = 'TALICMAN'   AND  (UW IS NOT NULL OR UW NOT IN (''))  AND UW='UW'  THEN FROMID END [UW-TALICMAN_FROMID], \n"
				+ "								CASE WHEN TOROLE = 'TALICMAN'   AND  (UW IS NOT NULL OR UW NOT IN (''))  AND UW='UW'  THEN TOID END [UW-TALICMAN_TOID], \n"
				+ "								CASE WHEN TOROLE = 'TALICMAN'   AND  (UW IS NOT NULL OR UW NOT IN (''))  AND UW='UW'  THEN TOROLE END [UW-TALICMAN_TOROLE], \n"
				+ "								CASE WHEN TOROLE = 'TALICMAN'   AND  (UW IS NOT NULL OR UW NOT IN (''))  AND UW='UW'  THEN CASESTATUS END [UW-TALICMAN_CASESTATUS], \n"
				+ "								CASE WHEN TOROLE = 'TALICMAN'   AND  (UW IS NOT NULL OR UW NOT IN (''))  AND UW='UW'  THEN REMARKS END [UW-TALICMAN_REMARKS], \n"
				+ "								CASE WHEN TOROLE = 'TALICMAN'   AND  (UW IS NOT NULL OR UW NOT IN (''))  AND UW='UW'  THEN ALLOCATED_DATE END [UW-TALICMAN_ALLOCATED_DATE], \n"
				+ "								CASE WHEN TOROLE = 'TALICMAN'   AND  (UW IS NOT NULL OR UW NOT IN (''))  AND UW='UW'  THEN APPROVED_DATE END [UW-TALICMAN_APPROVED_DATE], \n"
				+ "								CASE WHEN TOROLE = 'TALICMAN'   AND  (UW IS NOT NULL OR UW NOT IN (''))  AND UW='UW'  THEN TAT END [UW-TALICMAN_TAT] \n"
				+ "								INTO #TEMP7\n"
				+ "								FROM\n"
				+ "								(\n"
				+ "								SELECT \n"
				+ "								A.CASEID, \n"
				+ "								(SELECT TOP 1 ROLE_NAME FROM ADMIN_USER WHERE USERNAME =B.FROMID  AND  ROLE_NAME IN('REGMAN')) REGMAN,  \n"
				+ "								(SELECT TOP 1 ROLE_NAME FROM ADMIN_USER WHERE USERNAME = B.FROMID AND  ROLE_NAME IN('AGNSUP'))  AGNSUP, \n"
				+ "								(SELECT TOP 1 ROLE_NAME FROM ADMIN_USER WHERE USERNAME = B.FROMID AND  ROLE_NAME IN('INV'))  INV, \n"
				+ "								(SELECT TOP 1 ROLE_NAME FROM ADMIN_USER WHERE USERNAME = B.FROMID AND  ROLE_NAME IN('UW'))  UW, \n"
				+ "								(SELECT TOP 1 ROLE_NAME FROM ADMIN_USER WHERE USERNAME = B.FROMID AND  ROLE_NAME IN('TALICMAN')) TALICMAN,   \n"
				+ "								ISNULL((SELECT TOP 1 MOBILE_NUMBER FROM ADMIN_USER WHERE USERNAME = ISNULL(B.FROMID,'')),'') AS MOBILE_NUMBER,   \n"
				+ "								ISNULL((SELECT TOP 1 FULL_NAME  FROM ADMIN_USER WHERE USERNAME = B.FROMID),'') AS FROMID, \n"
				+ "								ISNULL((SELECT TOP 1 FULL_NAME FROM ADMIN_USER WHERE USERNAME = B.TOID),'') AS TOID,    \n"
				+ "								B.TOROLE, \n"
				+ "								B.CASESTATUS CASESTATUS, \n"
				+ "								B.REMARKS REMARKS, \n"
				+ "								LAG(B.UPDATEDDATE, 1,B.CREATEDDATE) OVER(PARTITION BY A.CASEID ORDER BY B.UPDATEDDATE ASC) AS ALLOCATED_DATE, \n"
				+ "								B.UPDATEDDATE AS APPROVED_DATE, \n"
				+ "								DATEDIFF(DAY,LAG(B.UPDATEDDATE, 1,B.CREATEDDATE) OVER(PARTITION BY A.CASEID ORDER BY B.UPDATEDDATE ASC), B.UPDATEDDATE) AS TAT\n"
				+ "								FROM CASE_LISTS A \n"
				+ "								LEFT OUTER JOIN \n"
				+ "								#AUDIT_CASE_MOVEMENT7 B ON A.CASEID = B.CASEID  \n"
				+ "								WHERE A.CASEID=B.CASEID AND CONVERT(DATE, A.CREATEDDATE) BETWEEN ? AND ?  \n"
				+ "								--AND A.CASEID IN (147)\n"
				+ "								) A\n"
				+ "				\n"
				+ "								--SELECT distinct * FROM  #TEMP A\n"
				+ "								--LEFT JOIN #TEMP1 B ON A.caseId = B.caseId\n"
				+ "								--LEFT JOIN #TEMP3 C ON A.caseId = C.caseId\n"
				+ "								--LEFT JOIN #TEMP4 D ON A.caseId = D.caseId\n"
				+ "								----LEFT JOIN #TEMP2 H ON A.caseId = H.caseId\n"
				+ "								--LEFT JOIN #TEMP5 E ON A.caseId = E.caseId\n"
				+ "								--LEFT JOIN #TEMP6 F ON A.caseId = F.caseId\n"
				+ "								--LEFT JOIN #TEMP7 G ON A.caseId = G.caseId\n"
				+ "								--ORDER BY A.caseId\n"
				+ "				\n"
				+ "								SELECT \n"
				+ "								A.CASEID, \n"
				+ "								A.POLICYNUMBER, \n"
				+ "								A.NATURE_OF_INVESTIGATION, \n"
				+ "								REPLACE(CONVERT(VARCHAR(10),CAST(A.ISSUEDDATE AS DATE),103),'/','-') ISSUEDDATE, \n"
				+ "								A.INSUREDMOB, \n"
				+ "								A.INSUREDNAME, \n"
				+ "								REPLACE(CONVERT(VARCHAR(10),CAST(A.INSUREDDOD AS DATE),103),'/','-') INSUREDDOD, \n"
				+ "								REPLACE(CONVERT(VARCHAR(10),CAST(A.INSUREDDOB AS DATE),103),'/','-') INSUREDDOB, \n"
				+ "								--A.INSUREDDOD, \n"
				+ "								--A.INSUREDDOB, \n"
				+ "								A.INSUREDDIAGNOSISDATE, \n"
				+ "								A.GENDER, \n"
				+ "								A.SUMASSURED, \n"
				+ "								A.INVESTIGATIONTYPE, \n"
				+ "								A.LOCATIONID, \n"
				+ "								A.PINCODE, \n"
				+ "								case WHEN A.CASESUBSTATUS is null THEN 'Pending for Assignment to Supervisor' WHEN A.CASESUBSTATUS = '' THEN 'Pending for Assignment to Supervisor' else A.CASESUBSTATUS end CASESUBSTATUS, \n"
				+ "								A.NOTCLEANCATEGORY, \n"
				+ "								A.TRIGGER_NAME, \n"
				+ "								A.TRIGGER_DEPT, \n"
				+ "								A.DISPOSITION_NAME, \n"
				+ "								A.NOMINEE_NAME, \n"
				+ "								A.NOMINEE_CONTACTNUMBER, \n"
				+ "								A.NOMINEE_ADDRESS, \n"
				+ "								A.INSURED_ADDRESS, \n"
				+ "								A.CASE_DESCRIPTION, \n"
				+ "								A.LONGITUDE, \n"
				+ "								A.LATITUDE, \n"
				+ "								A.CREATEDBY, \n"
				+ "								A.CREATEDDATE, \n"
				+ "								A.UPDATEDDATE, \n"
				+ "								A.UPDATEDBY, \n"
				+ "								A.CITY,	 \n"
				+ "								A.STATE, \n"
				+ "								A.ZONE, \n"
				+ "								A.STATUS, \n"
				+ "								ISNULL(B.FEES,0) FEES,\n"
				+ "								A.[RCU-REGMAN_MOBILE_NUMBER], \n"
				+ "								A.[RCU-REGMAN_FROMID], \n"
				+ "								A.[RCU-REGMAN_TOID], \n"
				+ "								A.[RCU-REGMAN_TOROLE], \n"
				+ "								A.[RCU-REGMAN_CASESTATUS], \n"
				+ "								A.[RCU-REGMAN_REMARKS], \n"
				+ "								A.[RCU-REGMAN_ALLOCATED_DATE], \n"
				+ "								A.[RCU-REGMAN_APPROVED_DATE], \n"
				+ "								A.[RCU-REGMAN_TAT],\n"
				+ "				\n"
				+ "				\n"
				+ "								B.[REGMAN-AGNSUP_MOBILE_NUMBER], \n"
				+ "								B.[REGMAN-AGNSUP_FROMID], \n"
				+ "								B.[REGMAN-AGNSUP_TOID], \n"
				+ "								B.[REGMAN-AGNSUP_TOROLE], \n"
				+ "								B.[REGMAN-AGNSUP_CASESTATUS], \n"
				+ "								B.[REGMAN-AGNSUP_REMARKS], \n"
				+ "								B.[REGMAN-AGNSUP_ALLOCATED_DATE], \n"
				+ "								B.[REGMAN-AGNSUP_APPROVED_DATE], \n"
				+ "								B.[REGMAN-AGNSUP_TAT],\n"
				+ "									\n"
				+ "				\n"
				+ "				\n"
				+ "								C.[AGNSUP-INV_MOBILE_NUMBER], \n"
				+ "								C.[AGNSUP-INV_FROMID], \n"
				+ "								C.[AGNSUP-INV_TOID], \n"
				+ "								C.[AGNSUP-INV_TOROLE], \n"
				+ "								C.[AGNSUP-INV_CASESTATUS], \n"
				+ "								C.[AGNSUP-INV_REMARKS], \n"
				+ "								C.[AGNSUP-INV_ALLOCATED_DATE], \n"
				+ "								C.[AGNSUP-INV_APPROVED_DATE], \n"
				+ "								C.[AGNSUP-INV_TAT], \n"
				+ "				\n"
				+ "				\n"
				+ "								D.[INV-AGNSUP_MOBILE_NUMBER], \n"
				+ "								D.[INV-AGNSUP_FROMID], \n"
				+ "								D.[INV-AGNSUP_TOID], \n"
				+ "								D.[INV-AGNSUP_TOROLE], \n"
				+ "								D.[INV-AGNSUP_CASESTATUS], \n"
				+ "								D.[INV-AGNSUP_REMARKS], \n"
				+ "								D.[INV-AGNSUP_ALLOCATED_DATE], \n"
				+ "								D.[INV-AGNSUP_APPROVED_DATE], \n"
				+ "								D.[INV-AGNSUP_TAT],\n"
				+ "				\n"
				+ "				\n"
				+ "								H.[AGNSUP-REGMAN_MOBILE_NUMBER], \n"
				+ "								H.[AGNSUP-REGMAN_FROMID], \n"
				+ "								H.[AGNSUP-REGMAN_TOID], \n"
				+ "								H.[AGNSUP-REGMAN_TOROLE], \n"
				+ "								H.[AGNSUP-REGMAN_CASESTATUS], \n"
				+ "								H.[AGNSUP-REGMAN_REMARKS], \n"
				+ "								H.[AGNSUP-REGMAN_ALLOCATED_DATE], \n"
				+ "								H.[AGNSUP-REGMAN_APPROVED_DATE], \n"
				+ "								H.[AGNSUP-REGMAN_TAT],\n"
				+ "				\n"
				+ "								F.[REGMAN-UW_MOBILE_NUMBER], \n"
				+ "								F.[REGMAN-UW_FROMID], \n"
				+ "								F.[REGMAN-UW_TOID], \n"
				+ "								F.[REGMAN-UW_TOROLE], \n"
				+ "								F.[REGMAN-UW_CASESTATUS], \n"
				+ "								F.[REGMAN-UW_REMARKS], \n"
				+ "								F.[REGMAN-UW_ALLOCATED_DATE], \n"
				+ "								F.[REGMAN-UW_APPROVED_DATE], \n"
				+ "								F.[REGMAN-UW_TAT],\n"
				+ "				\n"
				+ "				\n"
				+ "								G.[UW-TALICMAN_MOBILE_NUMBER], \n"
				+ "								G.[UW-TALICMAN_FROMID], \n"
				+ "								G.[UW-TALICMAN_TOID], \n"
				+ "								G.[UW-TALICMAN_TOROLE], \n"
				+ "								G.[UW-TALICMAN_CASESTATUS], \n"
				+ "								G.[UW-TALICMAN_REMARKS], \n"
				+ "								G.[UW-TALICMAN_ALLOCATED_DATE], \n"
				+ "								CONVERT(DATE,G.[UW-TALICMAN_APPROVED_DATE],103) [UW-TALICMAN_APPROVED_DATE], \n"
				+ "								G.[UW-TALICMAN_TAT] \n"
				+ "								FROM  #TEMP A\n"
				+ "								LEFT JOIN #TEMP1 B ON A.caseId = B.caseId\n"
				+ "								LEFT JOIN #TEMP3 C ON A.caseId = C.caseId and B.[REGMAN-AGNSUP_TOID] = C.[AGNSUP-INV_FROMID]\n"
				+ "								LEFT JOIN #TEMP4 D ON A.caseId = D.caseId and c.[AGNSUP-INV_TOID] = D.[INV-AGNSUP_FROMID]\n"
				+ "								LEFT JOIN #TEMP2 H ON A.caseId = H.caseId and D.[INV-AGNSUP_TOID] = H.[AGNSUP-REGMAN_FROMID]\n"
				+ "								--LEFT JOIN #TEMP5 E ON A.caseId = E.caseId\n"
				+ "								LEFT JOIN #TEMP6 F ON A.caseId = F.caseId\n"
				+ "								LEFT JOIN #TEMP7 G ON A.caseId = G.caseId\n"
				+ "								ORDER BY A.caseId,a.updatedDate;\n"
				+ "		";        //System.out.println("audit query:::"+sql);
		
		template.query(sql, new Object[] {startDate, endDate,startDate, endDate,startDate, endDate,startDate, endDate,startDate, endDate,startDate, endDate,startDate, endDate,startDate, endDate},(ResultSet rs, int rowNum) -> {
			reportData.put(rowNum+1, new Object[] {
					rowNum + 1,
					rs.getString("CASEID"),
					rs.getString("POLICYNUMBER"),
					rs.getString("nature_of_investigation"),
					rs.getString("ISSUEDDATE"),
					rs.getString("INSUREDMOB"),
					rs.getString("INSUREDNAME"),
					rs.getString("INSUREDDOD"),
					rs.getString("INSUREDDOB"),
					rs.getString("INSUREDDIAGNOSISDATE"),
					rs.getString("GENDER"),
					rs.getString("SUMASSURED"),
					rs.getString("INVESTIGATIONTYPE"),
					rs.getString("LOCATIONID"),
					rs.getString("PINCODE"),
					rs.getString("CASESUBSTATUS"),
					rs.getString("NOTCLEANCATEGORY"),
					rs.getString("TRIGGER_NAME"),
					rs.getString("TRIGGER_DEPT"),
					rs.getString("DISPOSITION_NAME"),
					rs.getString("NOMINEE_NAME"),
					rs.getString("NOMINEE_CONTACTNUMBER"),
					rs.getString("NOMINEE_ADDRESS"),
					rs.getString("INSURED_ADDRESS"),
					rs.getString("CASE_DESCRIPTION"),
					//rs.getString("LONGITUDE"),
					//rs.getString("LATITUDE"),
					rs.getString("CREATEDBY"),
					rs.getString("CREATEDDATE"),
					rs.getString("UPDATEDDATE"),
					rs.getString("UPDATEDBY"),
					rs.getString("CITY"),
					rs.getString("STATE"),
					rs.getString("ZONE"),
					rs.getString("FEES"),
					rs.getString("STATUS"),
					rs.getString("RCU-REGMAN_MOBILE_NUMBER"),
					rs.getString("RCU-REGMAN_FROMID"),
					rs.getString("RCU-REGMAN_TOID"),
					rs.getString("RCU-REGMAN_TOROLE"),
					rs.getString("RCU-REGMAN_CASESTATUS"),
					rs.getString("RCU-REGMAN_REMARKS"),
					rs.getString("RCU-REGMAN_ALLOCATED_DATE"),
					rs.getString("RCU-REGMAN_APPROVED_DATE"),
					rs.getString("RCU-REGMAN_TAT"),
					rs.getString("REGMAN-AGNSUP_MOBILE_NUMBER"),
					rs.getString("REGMAN-AGNSUP_FROMID"),
					rs.getString("REGMAN-AGNSUP_TOID"),
					rs.getString("REGMAN-AGNSUP_TOROLE"),
					rs.getString("REGMAN-AGNSUP_CASESTATUS"),
					rs.getString("REGMAN-AGNSUP_REMARKS"),
					rs.getString("REGMAN-AGNSUP_ALLOCATED_DATE"),
					rs.getString("REGMAN-AGNSUP_APPROVED_DATE"),
					rs.getString("REGMAN-AGNSUP_TAT"),
					rs.getString("AGNSUP-INV_MOBILE_NUMBER"),
					rs.getString("AGNSUP-INV_FROMID"),
					rs.getString("AGNSUP-INV_TOID"),
					rs.getString("AGNSUP-INV_TOROLE"),
					rs.getString("AGNSUP-INV_CASESTATUS"),
					rs.getString("AGNSUP-INV_REMARKS"),
					rs.getString("AGNSUP-INV_ALLOCATED_DATE"),
					rs.getString("AGNSUP-INV_APPROVED_DATE"),
					rs.getString("AGNSUP-INV_TAT"),
					rs.getString("INV-AGNSUP_MOBILE_NUMBER"),
					rs.getString("INV-AGNSUP_FROMID"),
					rs.getString("INV-AGNSUP_TOID"),
					rs.getString("INV-AGNSUP_TOROLE"),
					rs.getString("INV-AGNSUP_CASESTATUS"),
					rs.getString("INV-AGNSUP_REMARKS"),
					rs.getString("INV-AGNSUP_ALLOCATED_DATE"),
					rs.getString("INV-AGNSUP_APPROVED_DATE"),
					rs.getString("INV-AGNSUP_TAT"),
					rs.getString("AGNSUP-REGMAN_MOBILE_NUMBER"),
					rs.getString("AGNSUP-REGMAN_FROMID"),
					rs.getString("AGNSUP-REGMAN_TOID"),
					rs.getString("AGNSUP-REGMAN_TOROLE"),
					rs.getString("AGNSUP-REGMAN_CASESTATUS"),
					rs.getString("AGNSUP-REGMAN_REMARKS"),
					rs.getString("AGNSUP-REGMAN_ALLOCATED_DATE"),
					rs.getString("AGNSUP-REGMAN_APPROVED_DATE"),
					rs.getString("AGNSUP-REGMAN_TAT"),
					rs.getString("REGMAN-UW_MOBILE_NUMBER"),
					rs.getString("REGMAN-UW_FROMID"),
					rs.getString("REGMAN-UW_TOID"),
					rs.getString("REGMAN-UW_TOROLE"),
					rs.getString("REGMAN-UW_CASESTATUS"),
					rs.getString("REGMAN-UW_REMARKS"),
					rs.getString("REGMAN-UW_ALLOCATED_DATE"),
					rs.getString("REGMAN-UW_APPROVED_DATE"),
					rs.getString("REGMAN-UW_TAT"),
					rs.getString("UW-TALICMAN_MOBILE_NUMBER"),
					rs.getString("UW-TALICMAN_FROMID"),
					rs.getString("UW-TALICMAN_TOID"),
					rs.getString("UW-TALICMAN_TOROLE"),
					rs.getString("UW-TALICMAN_CASESTATUS"),
					rs.getString("UW-TALICMAN_REMARKS"),
					rs.getString("UW-TALICMAN_ALLOCATED_DATE"),
					rs.getString("UW-TALICMAN_APPROVED_DATE"),
					rs.getString("UW-TALICMAN_TAT")
		       		
			});			
			  return null;
		});

	return reportData;
	}
	
	public Map<Integer, Object[]> getVendorclosedpending(String Status, String vendorName, String startDate,String endDate) 
	{
		String caseStatus ="";
		if(Status.contains("pending")) {
			caseStatus ="main.caseStatus<>'Closed' and";
		}
		if(Status.contains("closed")) {
			caseStatus ="main.caseStatus='Closed' and";
		}
		if(Status.contains("monthly")) {
			caseStatus ="";
		}
		
				
		
		Map<Integer, Object[]> reportData = new HashMap<Integer, Object[]>();
		reportData.put(0, new Object[] {
				"Sr No", 
				"Case ID", 
				"Policy Number", 
				"Nature Of Investigation",
				"City",
				"State",
				"Zone",
				"Issued Date",
				"Insured Mobile Number",
				"Insured Name", 
				"Insured DOD", 
				"Insured DOB",
				"Insured Diagnosis Date",
				"Gender",
				"Sum Assured",
				"Investigation Type",
				"Pincode",
				"Case Status",
				"Case Sub Status",
				"Not Clean Category",
				"Trigger Name",
				"Trigger Department",
				"Disposition Name",
				"Nominee Name",
				"Nominee Contact Number",
				"Nominee Address",
				"Insured Address", 
				"Case Description",
				"Longitude", 
				"Latitude",
				"Created By",
				"Created Date", 
				"Updated Date",
				"TAT",
				"Updated By",
				"Regional Manager",
				"rm_alloted_Date" ,
				"RCU Remarks",
				"Agency Supervisor",
				"agency_alloted_Date",
				"regional_man_remarks",
				"investigator_mobile_number",
				"Investigator",
				"inv_alloted_date",
				"agn_sup_remarks",
				"Invtoagency_supervisor",
				"Invtoagency_alloted_Date",
				"Invtoagency_remarks",
				"Underwriter",
				"uw_alloted_date",
				"reg_man_remarks",
				"talic/claim",
				"talic/claim_alloted_date",
				"uw_remarks",
				"claim_remarks",
				"Inv Report_date",
				"as_Report_date",
	       		"uw_Report_date",
	       		"talic/clamim_Report_date"
				});
       
		
		String sql = "select main.*, (select city from location_lists where locationId = main.locationId) city,   \n" + 
				"												(select state from location_lists where locationId = main.locationId) state,   \n" + 
				"												(select zone from location_lists where locationId = main.locationId) zone,   \n" + 
				"												(select nature_of_investigationType from nature_of_investigation where nature_of_investigationId = main.nature_of_investigationId) as nature_of_investigation,   \n" + 
				"												ISNULL((select full_name from admin_user where username =  ISNULL(agnsup.fromId,'')),'') as regional_manager,    												 \n" + 
				"												ISNULL(regman.updatedDate,'') as rm_alloted_date,    \n" + 
				"												ISNULL(regman.remarks,'') as RCU_Remarks,    \n" + 
				"												case main.casestatus    \n" + 
				"												when 'Closed' then DATEDIFF(day,main.createdDate,main.updatedDate)    \n" + 
				"												else  DATEDIFF(day,main.updatedDate,getdate())   \n" + 
				"												end as TAT,   \n" + 
				"												ISNULL((select full_name from admin_user where username = ISNULL(agnsup.toId,'')),'') as agency_supervisor,    \n" + 
				"												ISNULL(agnsup.updatedDate,'') as agency_alloted_date,    \n" + 
				"												ISNULL(agnsup.remarks,'') as regional_man_remarks,    \n" + 
				"												ISNULL((select mobile_number from admin_user where username = ISNULL(inv.toId,'')),'') as investigator_mobile_number,    \n" + 
				"												ISNULL((select full_name from admin_user where username = ISNULL(inv.toId,'')),'') as investigator,    \n" + 
				"												ISNULL(inv.updatedDate,'') as inv_alloted_date,    \n" + 
				"												ISNULL(inv.remarks,'') as agn_sup_remarks,    \n" + 
				"												ISNULL((select full_name from admin_user where username = ISNULL(agnsuptorm.toId,'')),'') as Invtoagency_supervisor,    \n" + 
				"												ISNULL(agnsuptorm.updatedDate,'') as Invtoagency_alloted_date,    \n" + 
				"												ISNULL(agnsuptorm.remarks,'') as Invtoagency_remarks,    \n" + 
				"												ISNULL((select full_name from admin_user where username = ISNULL(uw.toId,'')),'') as underwriter,  \n" + 
				"												ISNULL(uw.updatedDate,'') as uw_alloted_date,    \n" + 
				"												ISNULL(uw.remarks,'') as regional_man_remarks, 				   \n" + 
				"												ISNULL((select full_name from admin_user where username = ISNULL(talicman.toId,'')),'') as talic,    \n" + 
				"												ISNULL(talicman.updatedDate,'') as talic_alloted_date,   \n" + 
				"												ISNULL(talicman.remarks,'') as uw_remarks, \n" + 
				"												ISNULL(claimman.remarks,'') as claim_remarks, \n" + 
				"												ISNULL(agnsuptorm.updatedDate,'') as Invtoagency_Report_date,  \n" + 
				"												ISNULL(regman2.updatedDate,'') as asTorm_Report_date, \n" + 
				"												ISNULL(uwreport.updatedDate,'') as uwTotalicman_Report_date, \n" + 
				"												ISNULL(talicrmreport.updatedDate,'') as talicman_Report_date \n" + 
				"												from case_lists main 			   \n" + 
				"												left outer join    \n" + 
				"												(select x.* from audit_case_movement x,    \n" + 
				"												(select caseId , min(updatedDate) as updatedDate from audit_case_movement where toRole = 'AGNSUP'   \n" + 
				"												group by caseId) y   \n" + 
				"												where x.caseId = y.caseId and x.toRole = 'AGNSUP' and x.updatedDate = y.updatedDate ) agnsup   \n" + 
				"												on main.caseId = agnsup.caseId 	   \n" + 
				"												left outer join    \n" + 
				"												(select x.* from audit_case_movement x,    \n" + 
				"												(select caseId , min(updatedDate) as updatedDate from audit_case_movement where toRole = 'REGMAN'   \n" + 
				"												group by caseId) y   \n" + 
				"												where x.caseId = y.caseId and x.toRole = 'REGMAN' and x.updatedDate = y.updatedDate ) regman   \n" + 
				"												on main.caseId = regman.caseId   \n" + 
				"												left outer join    \n" + 
				"												(select x.* from audit_case_movement x,    \n" + 
				"												(select caseId , min(updatedDate) as updatedDate from audit_case_movement where toRole = 'UW'   \n" + 
				"												group by caseId) y   \n" + 
				"												where x.caseId = y.caseId and x.toRole = 'UW' and x.updatedDate = y.updatedDate ) uw   \n" + 
				"												on main.caseId = uw.caseId  \n" + 
				"												left outer join    \n" + 
				"												(select x.* from audit_case_movement x,    \n" + 
				"												(select caseId , min(updatedDate) as updatedDate from audit_case_movement where toRole = 'INV'   \n" + 
				"												group by caseId) y   \n" + 
				"												where x.caseId = y.caseId and x.toRole = 'INV' and x.updatedDate = y.updatedDate ) inv   \n" + 
				"												on main.caseId = inv.caseId     \n" + 
				"												left outer join    \n" + 
				"												(select x.* from audit_case_movement x,    \n" + 
				"												(select caseId , min(updatedDate) as updatedDate from audit_case_movement where toRole = 'CLAMAN'   \n" + 
				"												group by caseId) y   \n" + 
				"												where x.caseId = y.caseId and x.toRole = 'CLAIMS' and x.updatedDate = y.updatedDate ) claims   \n" + 
				"												on main.caseId = claims.caseId  \n" + 
				"												left outer join    \n" + 
				"												(select x.* from audit_case_movement x,    \n" + 
				"												(select caseId , min(updatedDate) as updatedDate from audit_case_movement where toRole in( 'TALICMAN')   \n" + 
				"												group by caseId) y   \n" + 
				"												where x.caseId = y.caseId and x.toRole in( 'TALICMAN')   and x.updatedDate = y.updatedDate ) talicman   \n" + 
				"												on main.caseId = talicman.caseId\n" + 
				"												left outer join    \n" + 
				"												(select x.* from audit_case_movement x,    \n" + 
				"												(select caseId , max(updatedDate) as updatedDate from audit_case_movement where toRole='AGNSUP' and \n" + 
				"												fromId in(select username from admin_user where role_name in ('INV')) \n" + 
				"												group by caseId) y   \n" + 
				"												where x.caseId = y.caseId  and x.updatedDate = y.updatedDate) agnsuptorm   \n" + 
				"												on main.caseId = agnsuptorm.caseId 	\n" + 
				"												left outer join    \n" + 
				"												(select x.* from audit_case_movement x,    \n" + 
				"												(select caseId , max(updatedDate) as updatedDate from audit_case_movement where toRole in( 'CLAMAN','REGMAN')and\n" + 
				"												fromId in(select username from admin_user where role_name in ('AGNSUP' ))   \n" + 
				"												group by caseId) y   \n" + 
				"												where x.caseId = y.caseId  and x.updatedDate = y.updatedDate ) regman2   \n" + 
				"												on main.caseId = regman2.caseId \n" + 
				"												left outer join    \n" + 
				"												(select x.* from audit_case_movement x,    \n" + 
				"												(select caseId , max(updatedDate) as updatedDate from audit_case_movement where \n" + 
				"												fromId in(select username from admin_user where role_name in ('UW'))   \n" + 
				"												group by caseId) y   \n" + 
				"												where x.caseId = y.caseId  and x.updatedDate = y.updatedDate ) uwreport  \n" + 
				"												on main.caseId = uwreport.caseId \n" + 
				"												left outer join    \n" + 
				"												(select x.* from audit_case_movement x,    \n" + 
				"												(select caseId , min(updatedDate) as updatedDate from audit_case_movement where toId ='' and\n" + 
				"												fromId in(select username from admin_user where role_name in( 'TALICMAN','CLAMAN'))   \n" + 
				"												group by caseId) y   \n" + 
				"												where x.caseId = y.caseId and x.updatedDate = y.updatedDate) talicrmreport   \n" + 
				"												on main.caseId = talicrmreport.caseId \n" + 
				"												left outer join     \n" + 
				"												(select x.* from audit_case_movement x,     \n" + 
				"												(select caseId , min(updatedDate) as updatedDate from audit_case_movement where toRole in( 'CLAMAN')    \n" + 
				"												group by caseId) y    \n" + 
				"												where x.caseId = y.caseId and x.toRole in('CLAMAN')   and x.updatedDate = y.updatedDate ) claimman    \n" + 
				"												on main.caseId = claimman.caseId \n" + 
				"												left outer join \n" + 
				"												(select caseId , min(updatedDate)as updatedDate from audit_case_movement where toId \n" + 
				"												in(select username from admin_user where role_name in (?) and username = ?)\n" + 
				"												group by caseId) vendor\n" + 
				"												on main.caseId = vendor.caseId \n" + 
				"												where "+ caseStatus  + "\n" +
				"												CONVERT(date, main.createdDate) BETWEEN ? and ? \n" + 
				"												and\n" + 
				"												main.caseId =vendor.caseId";
		
		System.out.println(sql);
		template.query(sql, new Object[] {config.getSUPERVISOR(), vendorName,startDate, endDate},(ResultSet rs, int rowNum) -> {
			reportData.put(rowNum+1, new Object[] {
					rowNum + 1,
					rs.getInt("caseId"),
					rs.getString("policyNumber"),
					rs.getString("nature_of_investigation"),
					rs.getString("city"),
					rs.getString("state"),
					rs.getString("zone"),
					rs.getString("issuedDate"),
					rs.getString("insuredMob"),
					rs.getString("insuredName"),
					rs.getString("insuredDOD"),
					rs.getString("insuredDOB"),
					rs.getString("insuredDiagnosisDate"),
					rs.getString("gender"),
					rs.getString("sumAssured"),
					rs.getString("investigationType"),
					rs.getString("pincode"),
					rs.getString("caseStatus"),
					rs.getString("caseSubStatus"),
					rs.getString("notCleanCategory"),
					rs.getString("trigger_name"),
					rs.getString("trigger_dept"),
		       		rs.getString("disposition_name"),
		       		rs.getString("nominee_Name"),
		       		rs.getString("nominee_ContactNumber"),
		       		rs.getString("nominee_address"),
		       		rs.getString("insured_address"),
		       		rs.getString("case_description"),
		       		rs.getString("longitude"),
		       		rs.getString("latitude"),
		       		rs.getString("createdBy"),
		       		rs.getString("createdDate"),
		       		rs.getString("updatedDate"),
		       		rs.getString("TAT"),
		       		rs.getString("updatedBy"),
		       		rs.getString("regional_manager"),
		       		rs.getString("rm_alloted_date"),
		       		rs.getString("RCU_Remarks"),
		       		rs.getString("agency_supervisor"),
		       		rs.getString("agency_alloted_date"),
		       		rs.getString("regional_man_remarks"),
		       		rs.getString("investigator_mobile_number"),
		       		rs.getString("investigator"),
		       		rs.getString("inv_alloted_date"),
		       		rs.getString("agn_sup_remarks"),
		       		rs.getString("Invtoagency_supervisor"),
		       		rs.getString("Invtoagency_alloted_Date"),
		       		rs.getString("Invtoagency_remarks"),
		       		rs.getString("underwriter"),
		       		rs.getString("uw_alloted_date"),
		       		rs.getString("regional_man_remarks"),
		       		rs.getString("talic"),
		       		rs.getString("talic_alloted_date"),
		       		rs.getString("uw_remarks"),
		       		rs.getString("claim_remarks"),
		       		rs.getString("Invtoagency_Report_date"),
		       		rs.getString("asTorm_Report_date"),
		       		rs.getString("uwTotalicman_Report_date"),
		       		rs.getString("talicman_Report_date")
		       		
			});			
			  return null;
		});

	return reportData;
	}
	
}
