package com.preclaim.dao;

import java.sql.ResultSet;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.preclaim.config.CustomMethods;
import com.preclaim.models.Disposition;


@Component
public class DispositionDao {


	@Autowired
	DataSource datasource;

	@Autowired
	JdbcTemplate template;

	public void setTemplate(JdbcTemplate template) {
		this.template = template;
	}

	String sql = "";
	
	public String addDispositonName(Disposition name) 
	{
		try 
		{
			sql = "SELECT COUNT(*) FROM  disposition_name where disposition_name = '" + name.getDisposition_name() + "'";
			int count = this.template.queryForObject(sql,Integer.class);
			if(count > 0)
				return "Disposition Name already exists";
			
			String sql = "INSERT INTO disposition_name (disposition_name, status, created_date ,created_by)"
				 	  + " values(?, '0', getdate(),?)";
			this.template.update(sql,name.getDisposition_name(),name.getCreated_by());
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
			CustomMethods.logError(e);
			return e.getMessage();
		}

		return "****";

	}
		
	public List<Disposition> getActiveDisPositionList() {
		String query = "SELECT * from disposition_name WHERE status =  1";
		return template.query(query, (ResultSet rs, int rowNum) -> {
			Disposition details = new Disposition();
			details.setDisposition_name(rs.getString("disposition_name"));
			details.setStatus(rs.getString("status"));
			return details;
		});
	}

	public String updateDispositionName(String disposition_name, String dispositionId) {
		try
		{
			sql = "INSERT INTO audit_disposition_name select * from disposition_name where disposition_name = ?";
			this.template.update(sql,dispositionId);
			
			sql = "select count(*) from disposition_name where disposition_name='" + disposition_name + "' and disposition_name "
					+ " not in (select disposition_name from disposition_name where disposition_name = '" + dispositionId + "')";
			int count = this.template.queryForObject(sql, Integer.class);
			if(count > 0)
				return "Disposition already exists";
			
			String sql = "update disposition_name set disposition_name = ? where disposition_name = ?";
			template.update(sql, disposition_name, dispositionId);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			CustomMethods.logError(e);
			return e.getMessage();
		}
		return "****";
	}



	public String deleteDisPositionName(String dispositionName) {
		try 
		{
			sql = "INSERT INTO audit_disposition_name select * from disposition_name where disposition_name = ?";
			this.template.update(sql,dispositionName);
			
			String sql = "DELETE FROM disposition_name WHERE disposition_name = ?";
			this.template.update(sql,dispositionName);
		}
		catch(Exception e) 
		{
			e.printStackTrace();
			CustomMethods.logError(e);
			return e.getMessage();	
		}
		return "****";	
	}

	public String updateDisPositionNameStatus(String dispositionName, String status) {
		try 
		{
			sql = "INSERT INTO audit_disposition_name select * from disposition_name where disposition_name = ?";
			this.template.update(sql,dispositionName);
			
			String sql = "UPDATE disposition_name SET status = ? where disposition_name = ?";
			this.template.update(sql, status, dispositionName);
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
			CustomMethods.logError(e);
			return e.getMessage();
	    }
		return "****";
	}

	public List<Disposition> getActiveDispositionList() {
		String query = "SELECT * from disposition_name WHERE status =  1";
		return template.query(query, (ResultSet rs, int rowNum) -> {
			Disposition details = new Disposition();
			details.setDisposition_name(rs.getString("disposition_name"));
			details.setStatus(rs.getString("status"));
			return details;
		});
	}
	
	public List<Disposition> getAllDisPositionList() {
		String query = "SELECT * from disposition_name";
		return template.query(query, (ResultSet rs, int rowNum) -> {
			Disposition details = new Disposition();
			details.setDisposition_name(rs.getString("disposition_name"));
			details.setStatus(rs.getString("status"));
			return details;
		});
	}
	
}
