package com.preclaim.dao;

import java.sql.ResultSet;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.preclaim.models.Case_pivform;

@Component
public class PIVFormDao {

	@Autowired
	DataSource datasource;

	@Autowired
	JdbcTemplate template;

	public void setTemplate(JdbcTemplate template) {
		this.template = template;
	}

	String sql = "";
	//added by kk TOP 1
	public List<Case_pivform> getPivFormDetails(long caseId)
	{
		sql = "select x.*,(select full_name from admin_user where username = y.INV) fromid,(select full_name from admin_user where username = y.AGS)"
				+ " toid from case_pivform x,(select  top 1 fromId as INV ,toId as AGS  from audit_case_movement where  "
				+ " toId in(select username from admin_user where role_name in ('AGNSUP' ))and caseId = ? and " 
				+ "  fromId in(select username from admin_user where role_name in ('INV' ))order  by updatedDate desc) y "
				+ "  where x.caseId = ? order by x.question_header";
				/*"select x.*,(select full_name from admin_user where username = y.INV) fromid,(select full_name from admin_user where username = y.AGS) \n" + 
				"		toid from case_pivform x,(select  top 1 fromId as INV ,toId as AGS  from audit_case_movement where  \n" + 
				"	--	toId in(select TOP 1 username from admin_user where role_name in ('AGNSUP' ))and caseId = ? and \n" + 
				"		fromId in(select  username from admin_user where role_name in ('INV' ))order  by updatedDate desc) y \n" + 
				"		where x.caseId = ? order by x.question_header";*/
		
		

//	return template.query(sql, new Object[] {caseId},
				return template.query(sql, new Object[] {caseId,caseId},
				(ResultSet rs, int rowNum) ->
				{
					Case_pivform details = new Case_pivform();
					details.setFormId(rs.getLong("formId"));
					details.setCaseId(rs.getLong("caseId"));
					details.setQuestion_header(rs.getString("question_header"));
					details.setQuestion_body(rs.getString("question_body"));
					details.setQuestion_remarks(rs.getString("question_remarks"));
					details.setAS(rs.getString("toid"));
					details.setINV(rs.getString("fromid"));
					return details;
				}
				);		
	}
	
	
	public String updatePivFormRemark(int formId , String remark) {
		
		try {
				sql = "update case_pivform set question_remarks = '" + remark + "' where formId = '" + formId + "'";
				template.update(sql);
				
				sql = "update audit_case_pivform set question_remarks = '" + remark + "' where formId = '" + formId + "'";
				template.update(sql);
		    }
		     catch(Exception e) {
		     e.printStackTrace();	
		    }
		return "****";
	}
	
}
