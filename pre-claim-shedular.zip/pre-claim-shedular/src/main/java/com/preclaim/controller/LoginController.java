package com.preclaim.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.preclaim.config.Config;
import com.preclaim.entity.Response;

@RestController
@RequestMapping
//@SessionAttributes({"User_Login","user_role","user_permission"})
public class LoginController {
	@Autowired
	Config config;
	
	Response jsonResponse = new Response();
	
	@GetMapping("/")
//	@ApiOperation(value = "Main logic", notes = "To check the API is working. Contains version no to be used in child URLs")
	public ResponseEntity<Response> main() {
		jsonResponse.setData("Hi !! I'm Sheduler service. " + config.getVersion());
		jsonResponse.setStatus("Sheduler service up..");
		return new ResponseEntity<>(jsonResponse, HttpStatus.OK);
	}


}
