package com.preclaim.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
@Getter @Setter @ToString @NoArgsConstructor
@Entity(name = "location_lists")
@Table(name = "location_lists")
public class Location_lists {

	@JsonIgnore
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column
	private int locationId;
	
	@JsonIgnore
	@Column
	private String city;
	
	@JsonIgnore
	@Column
	private String state;
	
	@Column
	private String zone;
	
	@JsonIgnore
	@Transient
	private String createdBy;
	
	@JsonIgnore
	@Transient
	private Date createdDate;
	
	@JsonIgnore
	@Transient
	private int status;

}