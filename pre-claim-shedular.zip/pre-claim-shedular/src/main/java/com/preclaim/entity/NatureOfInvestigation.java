package com.preclaim.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;


@Getter @Setter @ToString @NoArgsConstructor
@Entity(name = "nature_of_investigation")
@Table(name = "nature_of_investigation")
public class NatureOfInvestigation 
{

	@JsonIgnore
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "nature_of_investigationId")
	private int nature_of_investigationId;
	
	@Column(name = "nature_of_investigationType")
	private String nature_of_investigationType;
	
	@JsonIgnore
	@Transient
	private String createdBy;
	
	@JsonIgnore
	@Transient
	private Date createdDate;
	
	@JsonIgnore
	@Transient
	private int status;
	
}
