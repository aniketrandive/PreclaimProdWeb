package com.preclaim.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter @Setter @ToString @NoArgsConstructor
@Entity
@Table(name = "Bulk_Scheduler_Data")
public class BulkSchedulerData {
	


	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "ID" ,updatable = false ,nullable = false)
	private long Id = 0;

	@Column(name = "caseID")
	private long CaseID = 0;

	@Column(name = "FromID")
	private String FromID = "";

	@Column(name = "ToID")
	private String ToID = "";
  
	@Column(name = "FromRole")
	private String FromRole = "";
	
	@Column(name = "ToRole")
	private String ToRole = "";

	@Column(name = "ToStatus")
	private String ToStatus = "";
	
	@Column(name = "caseStatus")
	private String caseStatus = "";
	
	@Column(name = "caseSubStatus")
	private String caseSubStatus = "";

	@Column(name = "NotCleanCategory")
	private String NotCleanCategory = "";

	@Column(name = "toRemarks")
	private String toRemarks = "";
	
	@Column(name = "Doc1")
	private String Doc1 = "";

	@Column(name = "Doc2")
	private String Doc2 = "";
	
	@Column(name = "Responce")
	private String Responce = "";

	@Column(name = "flag")
	private long flag = 0;

	@Column(name = "Createddate")
	private Date CreatedDate = new Date();

	@Column(name = "Updated_date")
	private Date UpdatedDate = new Date();

}
