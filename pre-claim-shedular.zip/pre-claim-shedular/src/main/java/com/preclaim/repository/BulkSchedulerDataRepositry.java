package com.preclaim.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.preclaim.entity.BulkSchedulerData;
import com.preclaim.entity.Case_lists;

@Repository
public interface BulkSchedulerDataRepositry extends JpaRepository<BulkSchedulerData, Long> {
	
	
	@Query(value = "select top 10 * from Bulk_Scheduler_Data where flag = 0 and Responce =''", nativeQuery = true)
	List<BulkSchedulerData> getDoc1CreationData();
	
	@Query(value = "select top 10 * from Bulk_Scheduler_Data where flag = 1 and Responce like '%Doc1sucses%' or Responce like '%Doc1pass%'", nativeQuery = true)
	List<BulkSchedulerData> getDoc2CreationData();
	
	@Query(value = "select top 10 * from Bulk_Scheduler_Data where flag = 2 and Responce  like '%Doc2sucses%' or Responce like '%Doc2pass%'", nativeQuery = true)
	List<BulkSchedulerData> getBulkCaseAssign();
	
	@Query(value = "select top 10 * from Bulk_Scheduler_Data where flag = 3 and Responce like '%assigned%'", nativeQuery = true)
	List<BulkSchedulerData> getMailSendData();
	
	


}
