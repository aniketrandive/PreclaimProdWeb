package com.preclaim.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.preclaim.entity.Admin_user;

@Repository
public interface AdminuserRepository extends JpaRepository<Admin_user, Integer> {
	
	Admin_user findByUsername(String username);
	
	Admin_user  findById(int id);
	
	@Query(value = "select count(*) from admin_user where mobile_number = :mobile_number", nativeQuery = true)
	int getmobile_number(@Param("mobile_number")String mobile_number);

}