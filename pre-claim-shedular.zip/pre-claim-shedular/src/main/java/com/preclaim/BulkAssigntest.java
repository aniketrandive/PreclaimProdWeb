package com.preclaim;

public class BulkAssigntest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String selectedValues = "";
		String tempStr[] = {"1","2","3"};

//		 tempStr[0] = 1;
		
		  for (String values : tempStr	) {
			  
		selectedValues = selectedValues.concat(values+",");
		
		System.out.println("selectedValues"+selectedValues);
		  }
		  selectedValues = selectedValues.substring(0, selectedValues.length() - 1);
		  System.out.println("selectedValues"+selectedValues);
		 }
}