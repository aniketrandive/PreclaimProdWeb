package com.preclaim;

import java.io.File;
import java.io.IOException;



public class fileread {

	public static void main(String[] args) throws  IOException {
		// TODO Auto-generated method stub
String path ="C:\\Pre-Claim Investigation\\uploads\\template\\Appointment Letter.docx";
	
File f = new File(path);
if(f.exists() && !f.isDirectory()) { 
    // do something
	System.out.println("yes");
}
	}

}
