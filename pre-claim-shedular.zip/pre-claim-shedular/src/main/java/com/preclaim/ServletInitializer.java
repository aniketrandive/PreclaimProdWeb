package com.preclaim;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;

import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.context.annotation.Bean;
import org.springframework.session.web.http.CookieSerializer;
import org.springframework.session.web.http.DefaultCookieSerializer;

public class ServletInitializer extends SpringBootServletInitializer {

	@Override
	protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
		return application.sources(PreClaimInvestigationApplication.class);
	}

	
	@Override
	public void onStartup(ServletContext sc) throws ServletException {
		// TODO Auto-generated method stub
//		sc.getSessionCookieConfig().setHttpOnly(true);        
//       sc.getSessionCookieConfig().setSecure(true); 
	
		
        super.onStartup(sc);
	}

	
	

	
	
	
	
	
}
