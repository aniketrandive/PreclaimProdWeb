package com.preclaim.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.preclaim.config.CustomMethods;
import com.preclaim.dao.CaseDao;
import com.preclaim.dao.UserDAO;
import com.preclaim.entity.BulkSchedulerData;
import com.preclaim.models.CaseSubStatus;
import com.preclaim.models.UserDetails;
import com.preclaim.repository.BulkSchedulerDataRepositry;

@Service
@Transactional                       
public class BulkCaseService {
	
	@Autowired
	BulkSchedulerDataRepositry BulkSchedulerDataRepositry;
	@Autowired
	UserDAO userDao;
	@Autowired
	CaseDao caseDao;
	
	public String BulkDataShedulerInsert(UserDetails from ,UserDetails to,HttpServletRequest request) {
		try {
		String selectedValues = "";
		String tempStr[] = request.getParameterValues("caseId[]");
		for (String values : tempStr)
			selectedValues += values + ",";
		selectedValues = selectedValues.substring(0, selectedValues.length() - 1);
		
		String toRole = request.getParameter("toRole");
		String toId = request.getParameter("toId");
		String fromId = from.getUsername();
		String toStatus = request.getParameter("toStatus");
		String caseSubStatus = request.getParameter("caseSubStatus");
		String NotCleanCategory = request.getParameter("NotCleanCategory");
		String toRemarks = request.getParameter("toRemarks");
		CaseSubStatus  status = null;
		String caseStatus = null;
		String CaseSubStatus = null;
		if (caseSubStatus.equals("")) {
			status = caseDao.getCaseStatus(from.getAccount_type(), toRole, toStatus);

			if (status == null)
				status = new CaseSubStatus();
			
			caseStatus = status.getCase_status();
			CaseSubStatus = status.getCaseSubStatus();
		}
		
		/*
		 * System.out.println("toRole"+toRole); System.out.println("toId"+toId);
		 * System.out.println("fromId"+fromId); System.out.println("toStatus"+toStatus);
		 * System.out.println("caseSubStatus"+caseSubStatus);
		 * System.out.println("NotCleanCategory"+NotCleanCategory);
		 */
//		List<BulkSchedulerData> bulkList = BulkSchedulerDataRepositry.getDocCreationData();
		List<BulkSchedulerData> bulkListtest = new ArrayList<BulkSchedulerData>();
		BulkSchedulerData BulkSchedulerData;
		for(String s :tempStr) {
//		System.out.println(i);
		BulkSchedulerData =new BulkSchedulerData();	
		
		BulkSchedulerData.setCaseID(Long.parseLong(s));
		BulkSchedulerData.setFromID(fromId);
		BulkSchedulerData.setToID(toId);
		BulkSchedulerData.setFromRole(from.getAccount_type());
		BulkSchedulerData.setToRole(toRole);
		BulkSchedulerData.setToStatus(toStatus);
		BulkSchedulerData.setCaseStatus(caseStatus);
		BulkSchedulerData.setCaseSubStatus(CaseSubStatus);
		BulkSchedulerData.setNotCleanCategory(NotCleanCategory);
		BulkSchedulerData.setToRemarks(toRemarks);
		BulkSchedulerData.setResponce("");
		
		BulkSchedulerData.setFlag(0);
		BulkSchedulerData.setCreatedDate(new Date());
		BulkSchedulerData.setUpdatedDate(new Date());
		bulkListtest.add(BulkSchedulerData);
	}
		BulkSchedulerDataRepositry.saveAll(bulkListtest);
		return "****";	
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			CustomMethods.logError(e);
			return "***";	
		}
		

	}
	
	

}
