package com.preclaim.service;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.itextpdf.html2pdf.HtmlConverter;
import com.itextpdf.io.source.ByteArrayOutputStream;
import com.preclaim.config.Config;
import com.preclaim.dao.CaseDao;
import com.preclaim.dao.PIVFormDao;
import com.preclaim.models.CaseDetails;
import com.preclaim.models.Case_pivform;
import com.preclaim.models.UserDetails;

@Service
public class PDFGenration {

	/*
	 * @Autowired static PIVFormDao pivFormDao;
	 */

	@Autowired
	CaseDao caseDao;

	@Autowired
	Config config;

	@Autowired
	PIVFormDao pivFormDao;

	

	public String HtmlToPdfGenration(CaseDetails caseDetail,UserDetails user) throws FileNotFoundException, IOException {

		String inputfile = "C:\\Pre-Claim Investigation\\uploads\\template\\Questionarie.html";
		String inputfile1 = "Questionarie.html";
		List<Case_pivform> pivform = pivFormDao.getPivFormDetails(caseDetail.getCaseId());
		// Html File Path

		// File To InputStream
		System.err.println(config.getTemplate_directory()+inputfile1);
		FileInputStream templatefile = new FileInputStream(inputfile);

//		FileInputStream templatefile = new FileInputStream(inputfile);
		
		//InputStream to File Convert
		File f = new File(inputfile);
		
		//Filesiz taken from File length
		long Filesize = f.length();

		//Filesize to INput Buffer  
		byte[] inputBuffer = new byte[(int) Filesize];
		int noOfBytesRead = templatefile.read(inputBuffer);
		String inputString = new String(inputBuffer);

		// Object of ByteArrayOutputStream
		ByteArrayOutputStream baos = new ByteArrayOutputStream();

		inputString = PIVQuestions(pivform, inputString);
		Date date = new Date();  
		SimpleDateFormat formatter = new SimpleDateFormat("dd-M-yyyy hh-mm-ss");  
		  String  strDate = formatter.format(date); 
		String filename = caseDetail.getCaseId() + "_" + strDate.replaceAll(" ","")+ "_Questionarie.pdf";
		System.err.println(config.getUpload_directory()+filename);
		System.err.println(inputString);
		HtmlConverter.convertToPdf(inputString, new FileOutputStream(config.getUpload_directory()+filename));

		String error_message = caseDao.updateCandidateDoc(caseDetail.getCaseId(), filename, "pdf", user.getUsername());

		System.out.println("PDF Created!");
		return error_message;
	}

	public static String PIVQuestions(List<Case_pivform> pivform, String inputString) {
		System.err.println(inputString);
		System.err.println(1);
		Set<String> header_list = new TreeSet<String>();
		Set<String> AS = new TreeSet<String>();
		Set<String> INV = new TreeSet<String>();
		System.err.println(2);
		for (Case_pivform details : pivform) {
			header_list.add(details.getQuestion_header());
			AS.add(details.getAS());
			INV.add(details.getINV());
		}
		System.err.println(3);
		
		System.err.println(4);
		for (String AGS : AS) {
			inputString = inputString.replace("||AGS||", AGS.toString());
		}
		System.err.println(5);
		for (String IN : INV) {
			inputString = inputString.replace("||IN||", IN.toString());
		}
		System.err.println(6);
		StringBuffer s = new StringBuffer();

		
		for (String header : header_list) {
			
			
			
			String b ="<tr style=\"background-color: #eeece1\"><th colspan=\"2\" class = \"text-center\">"+header+"</th></tr>";
	        s.append(b);
		for (Case_pivform details : pivform) {
			if (details.getQuestion_header().equals(header)) {

				String a = " <tr> <td style=\"font-size: 14px; \">" + details.getQuestion_body()
						+ "</td><td  style = \" display: inline;\" class = \"remarks\"><textarea style = \"height:50px;width:200px; font-size:9px;\">"
						+ details.getQuestion_remarks() + "</textarea></td></tr>";
				s.append(a);
			}
		}
		
		}
		System.err.println(7);
		inputString = inputString.replace("||ANIKET||", s.toString());

		System.err.println(inputString);
		return inputString;

	}

}
