package com.preclaim.service;

import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.List;

import org.apache.poi.openxml4j.opc.OPCPackage;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFParagraph;
import org.apache.poi.xwpf.usermodel.XWPFRun;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.preclaim.config.Config;
import com.preclaim.config.CustomMethods;
import com.preclaim.models.CaseDetails;
import com.preclaim.models.UserDetails;

@Component
public class DocCreation {
	
	@Autowired
	Config config;	
	

	public String textReplaceForAppointment(String path, CaseDetails caselist, UserDetails toUser)
	{ 
		Date date = new Date();  
		SimpleDateFormat formatter = new SimpleDateFormat("dd-M-yyyy hh-mm-ss");  
		  String  strDate = formatter.format(date); 
		  
		String Filename =caselist.getCaseId()+"_"+strDate+"_Appointment Letter.docx";
		System.out.println(Filename);
	
		try {
			XWPFDocument doc = new XWPFDocument(OPCPackage.open(path));
			for (XWPFParagraph p : doc.getParagraphs()) {
				List<XWPFRun> runs = p.getRuns();

				if (runs != null) {

					for (XWPFRun r : runs) {

						String text = r.getText(0);

						if (text != null && text.contains("POLY000")) {
							text = text.replace("POLY000", caselist.getPolicyNumber());// your content
							r.setText(text, 0);
						}

						if (text != null && text.contains("DATEEE")) {
							text = text.replace("DATEEE", caselist.getCreatedDate().substring(8, 10)
									+ caselist.getCreatedDate().substring(4, 8) + 
									caselist.getCreatedDate().substring(0, 4));
							System.out.println(caselist.getCreatedDate());
							r.setText(text, 0);
						}

						if (text != null && text.contains("USER000")) {
							text = text.replace("USER000", toUser.getFull_name());
							r.setText(text, 0);
						}

						if (text != null && text.contains("ADD000")) {
							text = text.replace("ADD000", toUser.getAddress1());
							r.setText(text, 0);
						}

						if (text != null && text.contains("INS000")) {
							text = text.replace("INS000", caselist.getInsuredName());
							r.setText(text, 0);
						}

						if (text != null && text.contains("NOM000")) {
							text = text.replace("NOM000", caselist.getNominee_name());
							r.setText(text, 0);
						}
					}
				}
			}
			
			doc.write(new FileOutputStream(config.getUpload_directory()+Filename));
			return Filename;
		} 
		catch (Exception e) 
		{
//			e.printStackTrace();
			CustomMethods.logError(e);
			return "";
		}
		
	}

	public String textReplaceForAuthorization(String path, CaseDetails caselist, UserDetails toUser)
	{ 
		Date date = new Date();  
		SimpleDateFormat formatter = new SimpleDateFormat("dd-M-yyyy hh-mm-ss");  
		  String  strDate = formatter.format(date); 
		String Filename =caselist.getCaseId()+"_"+strDate+"_Authorization Letter.docx";
		System.out.println(Filename);
		try 
		{
			XWPFDocument doc = new XWPFDocument(OPCPackage.open(path));

			for (XWPFParagraph p : doc.getParagraphs()) 
			{
				List<XWPFRun> runs = p.getRuns();
				if (runs != null) 
				{
					for (XWPFRun r : runs) 
					{
						String text = r.getText(0);
						if (text != null && text.contains("DATEEE")) {
							text = text.replace("DATEEE", caselist.getCreatedDate().substring(8, 10)
									+ caselist.getCreatedDate().substring(4, 8) + 
									caselist.getCreatedDate().substring(0, 4));
							r.setText(text, 0);
						}
						if (text != null && text.contains("VDATE000")) {
							LocalDate startDate = LocalDate.parse(caselist.getCreatedDate().substring(0, 10), 
									DateTimeFormatter.ofPattern("yyyy-MM-dd"));
							LocalDate endDate = startDate.plusMonths(2);
							String validity = startDate.format(DateTimeFormatter.ofPattern("dd/MMM/yyyy")) + " to " +
									endDate.format(DateTimeFormatter.ofPattern("dd/MMM/yyyy"));
							text = text.replace("VDATE000", validity);
							r.setText(text, 0);
						}
						if (text != null && text.contains("USER000")) {
							text = text.replace("USER000", toUser.getFull_name());
							r.setText(text, 0);
						}
						if (text != null && text.contains("AGSUP000")) {
							text = text.replace("AGSUP000", toUser.getFull_name());
							r.setText(text, 0);
						}
						if (text != null && text.contains("ADD000")) {
							text = text.replace("ADD000", toUser.getAddress1());
							r.setText(text, 0);
						}
					}
				}
			}
			doc.write(new FileOutputStream(config.getUpload_directory()+Filename));
			return Filename;
		} 
		catch(Exception e)
		{
//			e.printStackTrace();
			CustomMethods.logError(e);
			return "";
		}
		

	}
	
	


}
