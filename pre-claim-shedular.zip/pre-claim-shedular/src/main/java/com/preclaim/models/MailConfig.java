package com.preclaim.models;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class MailConfig {

	private String host = "";
	private int port = 0;
	private String username = "";
	private String password = "";
	private String encryptionType = "";
	private String receipent = "";
	private String subject = "";
	private String messageBody = "";
	private String AppointmentPath = "";
	private String AuthorizationPath = "";
}
