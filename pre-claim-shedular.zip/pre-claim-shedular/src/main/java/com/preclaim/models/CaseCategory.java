package com.preclaim.models;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class CaseCategory {
	
	private int caseCategoryId = 0;
	private String caseStatus = "";
	private String caseCategory = "";
	private String createdBy = "";
	private String updatedBy = "";
	private int status = 0;
	
}
