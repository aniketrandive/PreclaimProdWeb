package com.preclaim.models;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class Disposition {

	private String disposition_name = "";
	private String status = "";
	private String created_date = "";
	private String created_by = "";



public Disposition(String disposition_name) {
	this.disposition_name = disposition_name;
}

}