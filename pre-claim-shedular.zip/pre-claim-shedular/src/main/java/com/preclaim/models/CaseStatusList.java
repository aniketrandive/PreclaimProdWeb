package com.preclaim.models;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class CaseStatusList {

	private int srNo = 0;
	private String caseStatus= "";
	private String createdDate= "";
	private int status = 0;
	private int caseStatusId = 0;
}