package com.preclaim.models;

import java.util.Date;

public class User_locations {

	private String username;
	
	private String fullname;

	private String longitude;

	private String latitude;

	private Date updatedon;

	public User_locations(int id, String username, String fullname, String longitude, String latitude, Date updatedon) {
		super();
		this.username = username;
		this.fullname = fullname;
		this.longitude = longitude;
		this.latitude = latitude;
		this.updatedon = updatedon;
	}

	public User_locations() {
		super();
		// TODO Auto-generated constructor stub
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getLongitude() {
		return longitude;
	}

	public void setLongitude(String longitude) {
		this.longitude = longitude;
	}

	public String getLatitude() {
		return latitude;
	}

	public void setLatitude(String latitude) {
		this.latitude = latitude;
	}

	public Date getUpdatedon() {
		return updatedon;
	}

	public void setUpdatedon(Date updatedon) {
		this.updatedon = updatedon;
	}
	
	public String getFullname() {
		return fullname;
	}

	public void setFullname(String fullname) {
		this.fullname = fullname;
	}

	@Override
	public String toString() {
		return "User_locations [username=" + username + ", fullname=" + fullname + ", longitude=" + longitude
				+ ", latitude=" + latitude + ", updatedon=" + updatedon + "]";
	}



}
