package com.preclaim.Sheduler;

import java.time.LocalDateTime;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import com.preclaim.config.Config;
import com.preclaim.config.CustomMethods;
import com.preclaim.dao.CaseDao;
import com.preclaim.dao.MailConfigDao;
import com.preclaim.dao.UserDAO;
import com.preclaim.entity.BulkSchedulerData;
import com.preclaim.models.CaseDetails;
import com.preclaim.models.UserDetails;
import com.preclaim.repository.BulkSchedulerDataRepositry;
import com.preclaim.service.DocCreation;

import javassist.tools.framedump;

@Service
@EnableScheduling
public class Doc2CreateShedulaer2 {
	@Autowired
	Config config;

	@Autowired
	DocCreation DocCreation;

	@Autowired
	BulkSchedulerDataRepositry BulkSchedulerDataRepositry;

	@Autowired
	MailConfigDao mailConfigDao;

	@Autowired
	UserDAO userDao;
	@Autowired
	CaseDao caseDao;

	public String Doc1 = "";
	public String Doc2 = "";

	@Scheduled(cron = "*/10 * * * * *")
	public void runEvey5Minutes() {
		String error_messagedoc1 ="";
		String error_messagedoc2 ="";
		String AppointmentPath = "C:\\Pre-Claim Investigation\\uploads\\template\\Appointment Letter.docx";
		String AuthorizationPath = "C:\\Pre-Claim Investigation\\uploads\\template\\Authorization Letter.docx";
		
		//get Data from Bulk_Scheduler_Data table 
		List<BulkSchedulerData> bulkList = BulkSchedulerDataRepositry.getDoc2CreationData();

		//Check Size of LIst
		if (bulkList != null && bulkList.size() > 0) {
			//start for loop
			for (BulkSchedulerData BulkSchedulerData : bulkList) {
				// fetch user details 
				UserDetails toUser = userDao.getUserDetails(BulkSchedulerData.getToID());
				//fetch case details
				CaseDetails casdetail = caseDao.getCaseDetail(BulkSchedulerData.getCaseID());
				//Check Is ToStatus is approved and user role is agency supervisor
				if (BulkSchedulerData.getToStatus().equals("Approved")&& BulkSchedulerData.getToRole().equals(config.getSUPERVISOR())) {
						try {
							
							//Send to method via parameters for This method will return Appointment Doc_name
//							Doc1 = DocCreation.textReplaceForAppointment(AppointmentPath, casdetail, toUser);
							//Send to method via parameters for This method will return Authorization Doc_name
							Doc2 = DocCreation.textReplaceForAuthorization(AuthorizationPath, casdetail, toUser);
							
							//Check Appointment Doc_name is not blank if not then incert into CaseDoc
							/*
							 * if(!Doc1.equalsIgnoreCase("")) error_messagedoc1 =
							 * caseDao.updateCandidateDoc(BulkSchedulerData.getCaseID(), Doc1,
							 * "Doc1",BulkSchedulerData.getFromID());
							 */
							//Check Authorization Doc_name is not blan kif not then incert into CaseDoc
							if(!Doc2.equalsIgnoreCase(""))
								error_messagedoc2 = caseDao.updateCandidateDoc(BulkSchedulerData.getCaseID(), Doc2, "Doc2",BulkSchedulerData.getFromID());
							
							//Check Appointment Doc_name and Authorization Doc_name is blank or not 
							if(Doc2.equalsIgnoreCase("")) {
								//if yes set responce as Docfailed
								BulkSchedulerData.setResponce("Doc2failed");
							}
							//check both doc name are incerted sucssfully into table
							else if(error_messagedoc2.equalsIgnoreCase("")){
								BulkSchedulerData.setResponce("Doc2updatefailed");
							}else {
							//set responce and flag sucsses	
								BulkSchedulerData.setFlag(2);
								BulkSchedulerData.setResponce("Doc2sucsess");
							}

						} catch (Exception e) {
							//handled exception 
							BulkSchedulerData.setResponce("Doc2failed");
//							BulkSchedulerData.setDoc1(error_messagedoc1);
							BulkSchedulerData.setDoc2(error_messagedoc2);

//							e.printStackTrace();

							CustomMethods.logError(e);
						}
					}
					else {
						BulkSchedulerData.setFlag(2);
						BulkSchedulerData.setResponce("Doc2pass");
					}
//					BulkSchedulerData.setDoc1(Doc1);
					BulkSchedulerData.setDoc2(Doc2);
					BulkSchedulerData.setUpdatedDate(new Date());

					BulkSchedulerDataRepositry.save(BulkSchedulerData);
					System.out.println("Current time is :: " + LocalDateTime.now());
				}
			// ForLoopEnd
			}
		// If End
			
		}
		//Method end
	}


