package com.example.Preclaimupdate.controller.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.example.Preclaimupdate.entity.Case_docs;

@Repository
public interface Case_docsRepository extends JpaRepository<Case_docs, Integer>{
	
	Case_docs findByCaseId(long caseId);
	
	
	@Query(value = "select * from  case_docs a \n" +
			"where caseId =:caseId and created_by =:name", nativeQuery = true)
	List<Case_docs> findByCaseIdAndCreated_By(@Param("caseId")long caseId,@Param("name")String name);
	
	@Query(value = "select * from  case_docs a \n" +
			"where caseId =:caseId", nativeQuery = true)
	List<Case_docs> findByCaseId(@Param("caseId")String caseId);
	
}
