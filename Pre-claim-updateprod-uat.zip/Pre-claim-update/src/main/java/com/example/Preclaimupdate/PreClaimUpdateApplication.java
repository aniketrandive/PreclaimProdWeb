package com.example.Preclaimupdate;

import java.util.Collections;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.context.annotation.Bean;

import com.example.Preclaimupdate.common.Config;

import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.service.Contact;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

@SpringBootApplication
@EnableConfigurationProperties(Config.class)
@EnableSwagger2
public class PreClaimUpdateApplication extends SpringBootServletInitializer {

	@Autowired
	Config config;
	
	public static void main(String[] args) {
		SpringApplication.run(PreClaimUpdateApplication.class, args);

	}

	@Override
	protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
		return application.sources(PreClaimUpdateApplication.class);
	}

	@Bean
	protected Docket swaggerConfiguration()
	{
		return new Docket(DocumentationType.SWAGGER_2)
				.select()
				.apis(RequestHandlerSelectors.basePackage("com.example.Preclaimupdate.controller"))
				.build()
				.apiInfo(getApiInfo());
	}
	
	public ApiInfo getApiInfo()
	{
		return new ApiInfo(
				"Pre-Claim Investigation API", 
				"This document contains information of all APIs required to integrate Claims Portal with Mobile App",
				config.getVersion(),
				"Free to use",
				new Contact("Xangars Infratech Solutions Pvt Ltd","xangars.dixons@xangarsinfra.com",""),
				"",
				"",
				Collections.emptyList()
				);
	}
	
	
	
	
}
