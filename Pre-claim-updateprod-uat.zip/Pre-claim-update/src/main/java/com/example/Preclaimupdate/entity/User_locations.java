package com.example.Preclaimupdate.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter @Setter @ToString @NoArgsConstructor
@Entity(name = "user_locations")
@Table(name = "user_locations")
public class User_locations {

	@Id
//	@GeneratedValue(strategy = GenerationType.IDENTITY)
	//private int id;
	@Column(name = "userName")
	private String username;
	@Column(name = "longitude")
	private String longitude;
	@Column(name = "latitude")
	private String latitude;
	@Column(name = "updatedon")
	private Date updatedon;
		
	
}
