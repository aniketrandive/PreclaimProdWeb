package com.example.Preclaimupdate.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@NoArgsConstructor
@AllArgsConstructor@ToString

@Setter @Getter 
@Entity(name = "case_pivform")
@Table(name = "case_pivform")
public class Case_pivform {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "formId")
	@JsonIgnore
	private long formId = 0;
	
	@Column(name = "caseId")
	private long caseId = 0;
	
	@Column(name = "question_header")
	private String question_header = "";
	
	@Column(name = "question_body")
	private String question_body = "";
	
	@Column(name = "question_remarks")
	private String question_remarks = "";
}
