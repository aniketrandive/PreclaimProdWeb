package com.example.Preclaimupdate.entity;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter @Setter @ToString @NoArgsConstructor
public class CaseRequest {

	private String caseId = "";
	private String policyNumber = "";


}
