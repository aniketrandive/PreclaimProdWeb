package com.example.Preclaimupdate.entity;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter @Setter @ToString
public class CaseIdRequest {

	private long caseid = 0;
	private String version = "";
	private String created_by = "";
}
