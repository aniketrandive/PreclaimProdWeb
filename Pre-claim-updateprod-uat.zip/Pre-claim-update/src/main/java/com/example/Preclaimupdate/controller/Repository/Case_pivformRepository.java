package com.example.Preclaimupdate.controller.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.example.Preclaimupdate.entity.Case_pivform;

@Repository
public interface Case_pivformRepository extends JpaRepository<Case_pivform, Long> {
	
	@Query(value="select * from case_pivform where caseId = :caseId", nativeQuery = true)
	List<Case_pivform> getDetailByCaseId(@Param("caseId") long caseid);
	
	@Query(value="delete  from case_pivform where caseId = :caseId", nativeQuery = true)
	 void Delete(@Param("caseId") long caseid); 
	
	
	 void deleteByCaseId(long caseid); 

}
