package com.example.Preclaimupdate.controller.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.Preclaimupdate.entity.NatureOfInvestigation;

@Repository
public interface InvestigationNatureRepository extends JpaRepository<NatureOfInvestigation, Integer>{
	

	//NatureOfInvestigation findByInvestigationId(int investigationId);
	

}
