package com.example.Preclaimupdate.controller.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.Preclaimupdate.entity.Mail_config;

@Repository
public interface MailConfigRepository extends JpaRepository<Mail_config, Integer> {
	
	Mail_config findBystatus(int status);

	
	
}
