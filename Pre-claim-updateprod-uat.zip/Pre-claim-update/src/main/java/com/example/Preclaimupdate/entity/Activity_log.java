package com.example.Preclaimupdate.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter @Setter @ToString @NoArgsConstructor
@Entity
@Table(name = "activity_log")
public class Activity_log {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column
	private int logId = 0;
	@Column
	private String moduleName = "";
	@Column
	private String moduleCode = "";
	@Column
	private String moduleAction = "";
	@Column
	private String user_name = "";
	@Column
	private Date logDate = new Date();

}
