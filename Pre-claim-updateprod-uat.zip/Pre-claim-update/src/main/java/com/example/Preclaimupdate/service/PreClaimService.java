package com.example.Preclaimupdate.service;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.UnsupportedEncodingException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Base64.Encoder;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;
import javax.servlet.http.HttpServletRequest;

import org.apache.logging.log4j.core.util.FileUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import com.example.Preclaimupdate.common.Config;
import com.example.Preclaimupdate.common.CustomMethods;
import com.example.Preclaimupdate.controller.Repository.AdminuserRepository;
import com.example.Preclaimupdate.controller.Repository.Audit_Case_pivformRepository;
import com.example.Preclaimupdate.controller.Repository.Audit_casemovementRepository;
import com.example.Preclaimupdate.controller.Repository.CaseDetailsRepository;
import com.example.Preclaimupdate.controller.Repository.CaseSubStatusRepository;
import com.example.Preclaimupdate.controller.Repository.Case_docsRepository;
import com.example.Preclaimupdate.controller.Repository.Case_movementRepository;
import com.example.Preclaimupdate.controller.Repository.Case_pivformRepository;
import com.example.Preclaimupdate.controller.Repository.CaselistsRepository;
import com.example.Preclaimupdate.controller.Repository.MailConfigRepository;
import com.example.Preclaimupdate.controller.Repository.UserLocationRepository;
import com.example.Preclaimupdate.entity.Admin_user;
import com.example.Preclaimupdate.entity.Audit_case_pivform;
import com.example.Preclaimupdate.entity.CaseCategorywiseRequest;
import com.example.Preclaimupdate.entity.CaseIdRequest;
import com.example.Preclaimupdate.entity.CaseSubStatus;
import com.example.Preclaimupdate.entity.Case_Details;
import com.example.Preclaimupdate.entity.Case_docs;
import com.example.Preclaimupdate.entity.Case_lists;
import com.example.Preclaimupdate.entity.Case_movement;
import com.example.Preclaimupdate.entity.Case_pivform;
import com.example.Preclaimupdate.entity.DashboardRequest;
import com.example.Preclaimupdate.entity.LocationTrackRequest;
import com.example.Preclaimupdate.entity.Mail;
import com.example.Preclaimupdate.entity.Mail_config;
import com.example.Preclaimupdate.entity.Request;
import com.example.Preclaimupdate.entity.UpdateCaseRequest;
import com.example.Preclaimupdate.entity.User_locations;
import com.example.Preclaimupdate.entity.req_qustion;
@Transactional
@Service
public class PreClaimService {
	//Logger logger = LoggerFactory.getLogger(PreClaimService.class);

	@Autowired
	public JavaMailSender mailSender;

	@Autowired
	private AdminuserRepository Adminuser;

	@Autowired
	private Case_movementRepository caserepo;

	@Autowired
	private CaselistsRepository Caselist;

	@Autowired
	private CaseDetailsRepository caseDetails;

	@Autowired
	private Audit_casemovementRepository audit_repo;

	@Autowired
	private MailConfigRepository mailConfig;

	@Autowired
	private CaseSubStatusRepository casesubStatus;

	@Autowired
	private UserLocationRepository UserLocation;

	@Autowired
	private Case_pivformRepository case_pivformRepository;

	@Autowired
	private Audit_Case_pivformRepository audit_case_pivformRepository;

	@Autowired
	private Mail mail;

	@Autowired
	private Case_docsRepository case_docs;

	
	  @Autowired private Config config;
	 
	public Admin_user getbyusername(String username) {
		Admin_user user = Adminuser.findByUsername(username);
		return user;
	}

	public void save(Admin_user user) {
		Adminuser.save(user);
	}

	public HashMap<String, Object> save(List<req_qustion> question) {
		HashMap<String, Object> log = new HashMap<String, Object>();
		try {
			Long caseid = null;
			String User = "";
			Case_pivform case_piv;
			Audit_case_pivform audit_case_piv;
			List<Case_pivform> case_pivlist = new ArrayList<Case_pivform>();
			List<Audit_case_pivform> audit_case_pivlist = new ArrayList<Audit_case_pivform>();
			for (req_qustion req : question) {
				caseid = req.getCaseId();
				User = req.getCreated_by();
			}
			List<Case_pivform> caselist = case_pivformRepository.getDetailByCaseId(caseid);
			if(caselist.size() >  0)
			case_pivformRepository.deleteByCaseId(caseid);

			for (req_qustion req : question) {
				case_piv = new Case_pivform();
				case_piv.setCaseId(req.getCaseId());
				case_piv.setQuestion_header(req.getQuestion_header());
				case_piv.setQuestion_body(req.getQuestion_body());
				case_piv.setQuestion_remarks(req.getQuestion_remarks());
				case_pivlist.add(case_piv);
			}
			case_pivformRepository.saveAll(case_pivlist);

			List<Case_pivform> request = case_pivformRepository.getDetailByCaseId(caseid);
			for (Case_pivform req : request) {
				audit_case_piv = new Audit_case_pivform();
				audit_case_piv.setFormId(req.getFormId());
				audit_case_piv.setCaseId(req.getCaseId());
				audit_case_piv.setQuestion_header(req.getQuestion_header());
				audit_case_piv.setQuestion_body(req.getQuestion_body());
				audit_case_piv.setQuestion_remarks(req.getQuestion_remarks());
				audit_case_piv.setCreated_by(User);
				audit_case_piv.setUpdated_by(User);
				audit_case_piv.setCreatedDate(new Date());
				audit_case_piv.setUpdatedDate(new Date());
				audit_case_pivlist.add(audit_case_piv);
			}
			audit_case_pivformRepository.saveAll(audit_case_pivlist);

			return log;
		} catch (Exception e) {
			e.printStackTrace();
			log.put("error_code", "Failed");
			log.put("error_description", e.getMessage());
			CustomMethods.logError(e);
			return log;
		}

	}

	public Case_movement findByCaseId(long caseId) {
		return caserepo.findByCaseId(caseId);
	}

	public String Sendmail(String username, String pass) throws UnsupportedEncodingException {
		Admin_user user = Adminuser.findByUsername(username);
		Encoder encoder = Base64.getEncoder();
		user.setPassword(encoder.encodeToString(pass.getBytes()));
		Adminuser.save(user);

		Mail_config mConfig = mailConfig.findBystatus(1);
		String senderName = "Your company name";
		String toAddress = user.getUser_email();

		String subject = "You temp password ";
		String content = "Your temp password is<h3> [[name]]</h3>Kindly set your password,<br>" + "Thank you,<br>"
				+ "Your company name.";

		MimeMessage message = mailSender.createMimeMessage();
		MimeMessageHelper helper = new MimeMessageHelper(message);

		try {

			helper.setFrom(mConfig.getUsername(), senderName);
			helper.setTo(toAddress);
			helper.addCc("xangars.aniketr@xangarsinfra.com");
			helper.setSubject(subject);
			content = content.replace("[[name]]", pass);
			helper.setText(content, true);
			mailSender.send(message);

		} catch (MessagingException e) {

			CustomMethods.logError(e);
			e.printStackTrace();
		}
		return "****";
	}

	public void Sendmail(Mail mail) {
		Mail_config mConfig = mailConfig.findBystatus(1);
		String senderName = "Your company name";

		MimeMessage message = mailSender.createMimeMessage();
		MimeMessageHelper helper = new MimeMessageHelper(message);

		try {
			helper.setFrom(mConfig.getUsername(), senderName);
			helper.setTo(mail.getReceipent());
			helper.addCc("xangars.aniketr@xangarsinfra.com");
			helper.setSubject(mail.getSubject());
			helper.setText(mail.getMessageBody(), true);
			mailSender.send(message);
		} catch (UnsupportedEncodingException e) {
			CustomMethods.logError(e);
			e.printStackTrace();
		} catch (Exception e) {
			CustomMethods.logError(e);
			e.printStackTrace();
		}
	}

	public boolean changepassword(Request username) {
		Encoder encoder = Base64.getEncoder();
		Admin_user user = Adminuser.findByUsername(username.getUsername());
		String encodedPassword = encoder.encodeToString(username.getNewpassword().getBytes());
		String oldPassword = encoder.encodeToString(username.getOldpassword().getBytes());
		if (user != null && user.getPassword().equals(oldPassword)) {
			//logger.error("user found" + username.getUsername());
			user.setPassword(encodedPassword);
			user.setUpdatedDate(new Date());
			Adminuser.save(user);

			return true;
		}
		return false;

	}

	public Case_Details GetCaseDetailsByCaseId(CaseIdRequest username) {
		Case_Details case_Details = caseDetails.findByCaseId(username.getCaseid());

		return case_Details;
	}

	public List<Case_lists> GetCaseListByUsername(String username, int min, int max) {
		List<Case_lists> caselist = Caselist.getCaselists(username, min, max);
		if(caselist.size()  < 0) {
		for (Case_lists case_Details : caselist) 
			case_Details.setCase_Docs(case_docs.findByCaseIdAndCreated_By(case_Details.getCaseId(), username));
		}
		return caselist;
	}

	public HashMap<String, Object> fileupload(MultipartFile uploadedFile, HttpServletRequest request) {
		HashMap<String, Object> log = new HashMap<String, Object>();
		// Input Validation

		String username = request.getParameter("username");
		String fileType = request.getParameter("uploadType");
		String longitude = request.getParameter("longitude");
		String latitude = request.getParameter("latitude");
		int caseId = Integer.parseInt(request.getParameter("caseId"));
		Case_lists caselist = Caselist.findByCaseId(caseId);

		if (caselist == null) {
			log.put("error_code", "Failed");
			log.put("error_description", "Case not found");
			return log;
		}

		Case_docs caseDocs = new Case_docs();
		caseDocs.setCaseId(caselist.getCaseId());

		if (username == null) {
			log.put("error_code", "Failed");
			log.put("error_description", "Username not entered");
			return log;
		}
		if (longitude == null || latitude == null) {
			log.put("error_code", "Failed");
			log.put("error_description", "Geo-tagging missing");
			return log;
		}
		if (fileType == null) {
			log.put("error_code", "Failed");
			log.put("error_description", "File Type not entered");
			return log;
		}
		List<String> uploadType = CustomMethods.getUploadType();
		if (!uploadType.contains(fileType.toLowerCase())) {
			log.put("error_code", "Failed");
			log.put("error_description", "Invalid File Type");
			return log;
		}

		try {
			if (!uploadedFile.isEmpty()) {
				byte[] bytes = uploadedFile.getBytes();
				String originalFilename = uploadedFile.getOriginalFilename();
				String currentDate = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH-mm-ss"));
				String filename = caseId + "_" + fileType + "_" + currentDate + "."
						+ FileUtils.getFileExtension(new File(originalFilename));
				String ext = StringUtils.getFilenameExtension(filename).toLowerCase();
				File serverFile = new File(config.getUploadDirectory() + filename);
				BufferedOutputStream stream = new BufferedOutputStream(new FileOutputStream(serverFile));
				stream.write(bytes);
				stream.close();

				caseDocs.setCreated_by(username);
				switch (fileType) {
				case "pdf": {
					if (!ext.equals("pdf")) {
						log.put("error_code", "Failed");
						log.put("error_description", "Invalid File Extension");
						return log;
					}
					break;
				}

				case "audio": {
					if (!CustomMethods.getAudioFormat().contains(ext)) {
						log.put("error_code", "Failed");
						log.put("error_description", "Invalid File Extension");
						return log;
					}
					break;
				}

				case "video": {
					if (!CustomMethods.getVideoFormat().contains(ext)) {
						log.put("error_code", "Failed");
						log.put("error_description", "Invalid File Extension");
						return log;
					}
					break;
				}

				case "signature": {
					if (!CustomMethods.getImgFormat().contains(ext)) {
						log.put("error_code", "Failed");
						log.put("error_description", "Invalid File Extension");
						return log;
					}
					break;
				}

				case "image": {
					if (!CustomMethods.getImgFormat().contains(ext)) {
						log.put("error_code", "Failed");
						log.put("error_description", "Invalid File Extension");
						return log;
					}
					break;
				}

				case "excel": {
					if (!(ext.equals("csv") || ext.equals("xls") || ext.equals("xlsx"))) {
						log.put("error_code", "Failed");
						log.put("error_description", "Invalid File Extension");
						return log;
					}
					break;
				}
				}

				caseDocs.setDoc_type(fileType);
				caseDocs.setDoc_name(filename);
				caseDocs.setCreated_on(LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd hh:mm:ss")));
				case_docs.save(caseDocs);
			} else {
				log.put("error_code", "Failed");
				log.put("error_description", "File not uploaded");
				return log;
			}
		} catch (Exception e) {
			e.printStackTrace();
			log.put("error_code", "Failed");
			log.put("error_description", e.getMessage());
			CustomMethods.logError(e);
			return log;
		}

		return log;

	}

	public HashMap<String, Object> updateCaseDetails(UpdateCaseRequest username) {
		Case_lists caselist = Caselist.findByCaseId(username.getCaseid());
		HashMap<String, Object> log = new HashMap<String, Object>();

		if (caselist == null) {
			log.put("error_code", "****");
			log.put("error_description", "CaseId Not Found");
			return log;
		}
		Case_movement cas = caserepo.findByCaseId(caselist.getCaseId());
		System.out.println("1");
		CaseSubStatus caseSubstatus = casesubStatus.findByfromRole("INV");
		System.out.println("caseSubstatus" + caseSubstatus);
		try {

			String to = cas.getToId();
			String from = cas.getFromId();
			cas.setFromId(to);
			cas.setToId(from);
			cas.setUpdatedDate(new Date());
			cas.setToRole("AGNSUP");
			cas.setRemarks(username.getRemarks());
			caselist.setCase_description(username.getCase_description());
			caselist.setUpdatedDate(new Date());
			caselist.setLatitude(username.getLatitude());
			caselist.setLongitude(username.getLongitude());
			caselist.setCaseStatus(caseSubstatus.getCase_status());
			caselist.setCaseSubStatus(caseSubstatus.getCaseSubStatus());

			Caselist.save(caselist);

			if (username.getSubmitCase().equalsIgnoreCase("Y") && username.getSubmitCase() != null) {
				caserepo.save(cas);
				audit_repo.insertlog(caselist.getCaseId());

				if (caselist != null) {
					if (cas.getFromId() != null) {
						///// Sending mail from user
						Admin_user user = Adminuser.findByUsername(cas.getToId());
						mail.setSubject("Case Assigned - Claims");
						String message_body = "Dear <User>, \n Case has been assigned successfully\n\n";
						message_body = message_body.replaceAll("<User>", user.getFull_name());
						message_body += "Thanks & Regards,\n Claims";
						mail.setMessageBody(message_body);
						mail.setReceipent(user.getUser_email());
						Sendmail(mail);
					}

					if (cas.getToId() != null) {
						////// sending mail to User//
						Admin_user user = Adminuser.findByUsername(cas.getFromId());
						mail.setSubject("Case Assigned - Claims");
						String message_body = "Dear <User>, \n Your are required to take action on new cases\n\n";
						message_body = message_body.replaceAll("<User>", user.getFull_name());
						message_body += "Thanks & Regards,\n Claims";
						mail.setMessageBody(message_body);
						mail.setReceipent(user.getUser_email());
						Sendmail(mail);
					}

					log.put("error_code", "****");
					log.put("error_description", "Cases Details submitted successfully");
				}

			} else {
				log.put("error_code", "****");
				log.put("error_description", "Cases Details updated successfully");
			}
		} catch (Exception e) {
			log.put("error_code", "Failed");
			log.put("error_description", e.getMessage());
			CustomMethods.logError(e);
		}
		return log;
	}

	public HashMap<String, Object> dashboard(DashboardRequest username) {
		HashMap<String, Object> log = new HashMap<String, Object>();
		try {
			log.put("New", caserepo.getNewCaseCount(username.getUsername()));
			log.put("PIV/PIRV/LIVE", caseDetails.getNCDPCaseCount(username.getUsername(), "CDP"));
			log.put("CDP", caseDetails.getCDPCaseCount(username.getUsername(), "CDP"));
		} catch (Exception e) {
			log.put("error_code", "Failed");
			log.put("error_description", e.getMessage());
			CustomMethods.logError(e);
		}

		return log;

	}

	public List<Case_lists> getCaseCategoryList(CaseCategorywiseRequest request) {
		try {
			String investigatorId = request.getUsername();
			int pageSize = request.getPagesize();
			int pageNum = request.getPageNum();

			int min = pageSize * (pageNum - 1) + 1;
			int max = pageNum * pageSize;

			List<Case_lists> case_list = null;
			if (request.getInvestigationType().equalsIgnoreCase("NEW"))
				case_list = Caselist.getCaselists(investigatorId, min, max);
			else if (request.getInvestigationType().equals("CDP"))
				case_list = Caselist.getCDPCaseList(investigatorId, min, max);
			else
				case_list = Caselist.getNCDPCaseList(investigatorId, min, max);
			if(!case_list.equals(null)) {
			for (Case_lists case_Details : case_list) 
				case_Details.setCase_Docs(case_docs.findByCaseIdAndCreated_By(case_Details.getCaseId(), request.getUsername()));
			}
			return case_list;
		} catch (Exception e) {
			e.printStackTrace();
			CustomMethods.logError(e);
			return null;
		}
	}

	public HashMap<String, Object> locationtrack(LocationTrackRequest request) {
		HashMap<String, Object> log = new HashMap<String, Object>();
		if (request.getUsername() == null) {
			log.put("error_code", "Failed");
			log.put("error_description", "Username not entered");
		}
		if (request.getLongitude() == null) {
			log.put("error_code", "Failed");
			log.put("error_description", "Longitude not entered");
		}
		if (request.getLatitude() == null) {
			log.put("error_code", "Failed");
			log.put("error_description", "Latitude not entered");
		}
		User_locations user = UserLocation.findByUsername(request.getUsername());
		Admin_user adminuser = Adminuser.findByUsername(request.getUsername());

		if (user != null && adminuser != null) {
			user.setLatitude(request.getLatitude());
			user.setLongitude(request.getLongitude());
			user.setUpdatedon(new Date());
			UserLocation.save(user);
		} else if (user == null && adminuser != null) {
			User_locations locations = new User_locations();
			locations.setUsername(request.getUsername());
			locations.setLatitude(request.getLatitude());
			locations.setLongitude(request.getLongitude());
			locations.setUpdatedon(new Date());
			UserLocation.save(locations);
		} else {
			log.put("error_code", "Failed");
			log.put("error_description", "Username not found");
		}

		return log;

	}

	public List<Case_docs> getCaseDocsList(String caseId) {
		return case_docs.findByCaseId(caseId);
	}

}
