package com.example.Preclaimupdate.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter @Setter @ToString @NoArgsConstructor
@Entity(name = "case_substatus")
@Table(name = "case_substatus")
public class CaseSubStatus {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "id")
	private int id;
	
	@Column(name = "fromRole")
	private String fromRole;

	@Column(name = "toRole")
	private String toRole;

	@Column(name = "Case_status")
	private String Case_status;

	@Column(name = "caseSubStatus")
	private String caseSubStatus;

	@Column(name = "user_action")
	private String user_action;

}
