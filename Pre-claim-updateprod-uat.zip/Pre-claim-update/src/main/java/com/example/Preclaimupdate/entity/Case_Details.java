package com.example.Preclaimupdate.entity;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter @Setter @ToString @NoArgsConstructor
@Entity(name = "case_lists")
@Table(name = "case_lists")
public class Case_Details {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "caseId")
	private long caseId = 0;

	@Column(name = "policyNumber")
	private String policyNumber = "";

	@OneToOne
	@JoinColumn(name = "nature_of_investigationId", referencedColumnName = "nature_of_investigationId")
	private NatureOfInvestigation investigationNature = new NatureOfInvestigation();

	@Column(name = "issuedDate")
	private String issuedDate = "";

	@Column(name = "insuredName")
	private String insuredName = "";

	@Column(name = "insuredMob")
	private String insuredMob = "";

	@Column(name = "insuredDOD")
	private String insuredDOD = "";

	@Column(name = "insuredDOB")
	private String insuredDOB = "";

	@Column(name = "insuredDiagnosisDate")
	private String insuredDiagnosisDate = "";

	@Column(name = "sumAssured")
	private double sumAssured = 0;

	@Column(name = "gender")
	private String gender = "";

	@Column(name = "investigationType")
	private String investigationType = "";

	@OneToOne
	@JoinColumn(name = "locationId", referencedColumnName = "locationId")
	Location_lists location = new Location_lists();

	@Column(name = "caseStatus")
	private String caseStatus = "";
	
	@Column(name = "caseSubStatus")
	private String caseSubStatus = "";

	@Column(name = "trigger_name")
	private String trigger_name = "";

	@Column(name = "trigger_dept")
	private String trigger_dept = "";
	
	@Column(name = "disposition_name")
	private String disposition_name = "";
	
	@Column(name = "nominee_Name")
	private String nominee_Name = "";

	@Column(name = "nominee_ContactNumber")
	private String nominee_ContactNumber = "";

	@Column(name = "nominee_address")
	private String nominee_address = "";

	@Column(name = "pincode")
	private String pincode = "";

	@Column(name = "insured_address")
	private String insured_address = "";

	@Column(name = "case_description")
	private String case_description = "";

	@Column(name = "longitude")
	private String longitude = "";

	@Column(name = "latitude")
	private String latitude = "";

	@Transient
	private String remarks = "";
	
	@Transient
	private String fromUser = "";
	
	@Transient
	private String caseMovementStatus = "";
	
	/*
	 * @OneToMany
	 * @JoinColumn(name = "caseId", referencedColumnName = "caseId")
	 */
	@Transient
	List<Case_docs> case_Docs = new ArrayList<Case_docs>();

}
