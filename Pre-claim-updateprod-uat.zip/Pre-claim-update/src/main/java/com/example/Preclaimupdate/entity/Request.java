package com.example.Preclaimupdate.entity;

import java.util.Date;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter @Setter @ToString @NoArgsConstructor
public class Request {

	private String username = "";
	private String password = "";
	private String oldpassword = "";
	private String newpassword = "";
	private String Status = "";
	private int pagesize = 0;
	private int pageNum = 0;
	private int caseid = 0;
	private String case_description = "";
	private Date date = new Date();
	private String latitude = "";
	private String longitude = "";
	private String file = "";
	private String capturedDate = "";
	private String remarks = "";
	private String submitCase = "";
	private String version = "";
	private String mobileNumber = "";

}
