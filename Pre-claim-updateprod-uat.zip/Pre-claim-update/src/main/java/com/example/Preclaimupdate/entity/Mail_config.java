package com.example.Preclaimupdate.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
@Getter @Setter @ToString @NoArgsConstructor
@Entity(name = "Mail_config")
@Table(name = "Mail_config")
public class Mail_config {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "mailConfigId")
	private int mailConfigId;
	
	@Column(name = "username")
	private String username;
	
	@Column(name = "password")
	private String password;
	
	@Column(name = "outgoingServer")
	private String outgoingServer;
	
	@Column(name = "outgoingPort")
	private int outgoingPort;
	
	@Column(name = "encryptionType")
	private String encryptionType;
	
	@Column(name = "status")
	private int status;
	
	@Column(name = "createdBy")
	private String createdBy;
	
	@Column(name = "created_on")
	private Date created_on;
	
	@Column(name = "updatedBy")
	private String updatedBy;
	
	@Column(name = "updated_on")
	private Date updated_on;

}
