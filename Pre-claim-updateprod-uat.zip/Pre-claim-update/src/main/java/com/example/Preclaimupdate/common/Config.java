package com.example.Preclaimupdate.common;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;


@Getter @Setter @ToString
@ConfigurationProperties
@PropertySource(value = "classpath:application-${spring.profiles.active}.properties")
public class Config {

	private String uploadDirectory;
	public String uploadURL;
	private String version;
	
	//LDAP Server Details
	private String LDAP_AUTHENTICATION;
	private String INITIAL_CONTEXT_FACTORY;
	private String PROVIDER_URL;
	private String SECURITY_PRINCIPAL;

	//Designation
	private String ADMIN;
	private String RCUTEAM;
	private String REGIONAL_MANAGER;
	private String SUPERVISOR;
	private String INVESTIGATOR;
	private String CLAIMS;
	private String UNDERWRITER;
	private String TALIC_MANAGER;
}
