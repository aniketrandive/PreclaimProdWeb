package com.example.Preclaimupdate.controller.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.example.Preclaimupdate.entity.Case_Details;
import com.example.Preclaimupdate.entity.Case_pivform;

@Repository
public interface CaseDetailsRepository extends JpaRepository<Case_Details, Long> {
	
	Case_Details findByCaseId(long caseId);
	
	
	
	@Query(value = "select count(*) from case_lists where caseId in ("
			+ "select caseId from case_movement where toId = :username) and "
			+ "investigationType = :investigationType", nativeQuery = true)
	int getCDPCaseCount(@Param("username") String username, 
			@Param("investigationType") String investigationType);
	
	@Query(value = "select count(*) from case_lists where caseId in ("
			+ "select caseId from case_movement where toId = :username) and "
			+ "investigationType <> :investigationType", nativeQuery = true)
	int getNCDPCaseCount(@Param("username") String username, 
			@Param("investigationType") String investigationType);
	
	
}
