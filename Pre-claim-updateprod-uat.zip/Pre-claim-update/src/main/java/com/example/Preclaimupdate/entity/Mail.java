package com.example.Preclaimupdate.entity;

import org.springframework.stereotype.Component;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter @Setter @ToString @NoArgsConstructor
@Component
public class Mail {
	
	private String host;
	private int port;
	private String username;
	private String password;
	private String encryptionType;
	private String receipent;
	private String subject;
	private String messageBody;
	private String AppointmentPath;
	private String AuthorizationPath;
	
}
