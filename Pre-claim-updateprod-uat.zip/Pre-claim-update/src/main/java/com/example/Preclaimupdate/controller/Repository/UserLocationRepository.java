package com.example.Preclaimupdate.controller.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.Preclaimupdate.entity.User_locations;

@Repository
public interface UserLocationRepository extends JpaRepository<User_locations, Integer> {

	User_locations findByUsername(String username);

}
