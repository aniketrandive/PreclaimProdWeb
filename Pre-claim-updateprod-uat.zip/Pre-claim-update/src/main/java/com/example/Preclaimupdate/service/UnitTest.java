package com.example.Preclaimupdate.service;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class UnitTest {
	
public static void main(String[] args) throws IOException { // TODO

		
		//Html File Path 		
				String inputfile = "C:\\Pre-Claim Investigation\\uploads\\template\\Questionarie.html";
				
				//File To InputStream
				FileInputStream templatefile = new FileInputStream(inputfile);
				
				//InputStream to File Convert
				File f = new File(inputfile);
				
				//Filesiz taken from File length
				long Filesize = f.length();

				//Filesize to INput Buffer  
				byte[] inputBuffer = new byte[(int) Filesize];
				int noOfBytesRead = templatefile.read(inputBuffer);
				String inputString = new String(inputBuffer);

				//Object of ByteArrayOutputStream  
				
				System.out.println(inputString.toString());

	}
	
	/*
	 * public static void main(String[] args) {
	 * 
	 * 
	 * Date date = new Date(); SimpleDateFormat formatter = new
	 * SimpleDateFormat("MM/dd/yyyy"); String strDate = formatter.format(date);
	 * System.out.println("Date Format with MM/dd/yyyy : "+strDate);
	 * 
	 * formatter = new SimpleDateFormat("dd-M-yyyy hh-mm-ss"); strDate =
	 * formatter.format(date);
	 * System.out.println("Date Format with dd-M-yyyy hh:mm:ss : "+strDate.
	 * replaceAll(" ", ""));
	 * 
	 * formatter = new SimpleDateFormat("dd MMMM yyyy"); strDate =
	 * formatter.format(date);
	 * System.out.println("Date Format with dd MMMM yyyy : "+strDate);
	 * 
	 * formatter = new SimpleDateFormat("dd MMMM yyyy zzzz"); strDate =
	 * formatter.format(date);
	 * System.out.println("Date Format with dd MMMM yyyy zzzz : "+strDate);
	 * 
	 * formatter = new SimpleDateFormat("E, dd MMM yyyy HH:mm:ss z"); strDate =
	 * formatter.format(date);
	 * System.out.println("Date Format with E, dd MMM yyyy HH:mm:ss z : "+strDate);
	 * }
	 */
}