package com.example.Preclaimupdate.entity;

public class UpdateUserRequest {

}
