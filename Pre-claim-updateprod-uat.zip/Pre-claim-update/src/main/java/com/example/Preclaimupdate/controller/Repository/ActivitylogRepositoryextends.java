package com.example.Preclaimupdate.controller.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.Preclaimupdate.entity.Activity_log;

@Repository
public interface ActivitylogRepositoryextends extends JpaRepository<Activity_log, Integer> {

}
