package com.example.Preclaimupdate.entity;

import java.util.Date;

import javax.persistence.Column;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@NoArgsConstructor
@AllArgsConstructor
@ToString

@Setter
@Getter
public class req_qustion {

	private long formId = 0;

	private long caseId = 0;

	private String question_header = "";

	private String question_body = "";

	private String question_remarks = "";

	private String created_by = "";

}
