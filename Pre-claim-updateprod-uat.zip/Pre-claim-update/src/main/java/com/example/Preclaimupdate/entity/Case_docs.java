package com.example.Preclaimupdate.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.PropertySource;

import com.example.Preclaimupdate.common.Config;
import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.AccessLevel;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

 @Setter @ToString @NoArgsConstructor
@Entity(name = "case_docs")
@Table(name = "case_docs")
public class Case_docs {

	@Autowired
	@JsonIgnore
	@Getter(value = AccessLevel.NONE)
	@Setter(value = AccessLevel.NONE)
	@Transient
	private Config config;
	
	@JsonIgnore
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private int id = 0;
	
	
	@JsonIgnore
	@Column(name = "caseId")
	private long caseId = 0;
	
	@Column(name = "doc_type")
	private String doc_type = "";
	
	@Column(name = "doc_name")
	private String doc_name = "";
	
	@JsonIgnore
	@Column(name = "created_by")
	private String created_by = "";
	
	@JsonIgnore
	@Column(name = "created_on")
	private String created_on = "";


	public void setConfig(Config config) {
		this.config = config;
	}

	public long getId() {
		return id;
	}

	public long getCaseId() {
		return caseId;
	}

	public String getDoc_type() {
		return doc_type;
	}

	public String getDoc_name() {
		
//		return "http://13.235.150.162:805/"+doc_name;
		return "https://fieldinvestigation.tataaia.com/claim/"+doc_name;
	}

	public String getCreated_by() {
		return created_by;
	}

	public String getCreated_on() {
		return created_on;
	}
	

	
	
	
}
