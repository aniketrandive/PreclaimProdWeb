package com.example.Preclaimupdate.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
@Getter @Setter @ToString @NoArgsConstructor
@Entity(name = "audit_case_movement")
@Table(name = "audit_case_movement")
public class Audit_case_movement {

	@Id
	@Column(name = "caseId")
	private int caseId = 0;
	
	@Column(name = "fromId")
	private String fromId = "";
	
	@Column(name = "toId")
	private String toId = "";
	
	@Column(name = "toRole")
	private String toRole = "";
	
	@Column(name = "zone")
	private String zone = "";
	
	@Column(name = "caseStatus")
	private String caseStatus = "";
	
	@Column(name = "remarks")
	private String remarks = "";
	
	@Column(name = "createdDate")
	private Date createdDate = new Date();
	
	@Column(name = "updatedDate")
	private Date updatedDate = new Date();

}
