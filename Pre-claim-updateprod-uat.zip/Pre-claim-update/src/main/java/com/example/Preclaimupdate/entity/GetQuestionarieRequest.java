package com.example.Preclaimupdate.entity;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter @Setter @ToString
public class GetQuestionarieRequest {

	private long caseId = 0;
	private String version = "";
}
