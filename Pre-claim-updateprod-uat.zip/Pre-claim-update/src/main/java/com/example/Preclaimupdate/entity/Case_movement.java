package com.example.Preclaimupdate.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter @Setter @ToString @NoArgsConstructor
@Entity(name = "case_movement")
@Table(name = "case_movement")
public class Case_movement {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name =  "caseId")
	private long caseId;
	
	@Column(name =  "fromId")
	private String fromId;
	
	@Column(name =  "toId")
	private String toId;
	
	@Column(name = "toRole")
	private String toRole;
	
	@Column(name = "zone")
	private String zone;
	
	@Column(name =  "caseStatus")
	private String caseStatus;
	
	@Column(name =  "remarks")
	private String remarks;
	
	@Column(name =  "createdDate")
	private Date createdDate;
	
	@Column(name =  "updatedDate")
	private Date updatedDate;

	
}
