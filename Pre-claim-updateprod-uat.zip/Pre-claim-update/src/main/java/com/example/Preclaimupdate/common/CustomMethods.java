package com.example.Preclaimupdate.common;

import java.util.ArrayList;
import java.util.List;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class CustomMethods {
	
	public static List<String> getUploadType()
	{
		List<String> uploadType = new ArrayList<String>();
		uploadType.add("pdf");
		uploadType.add("image");
		uploadType.add("image2");
		uploadType.add("audio");
		uploadType.add("video");
		uploadType.add("signature");
		uploadType.add("excel");
		return uploadType;
	}
	
	public static void logError(Exception e)
	{
		log.error("Exception occured -------------- ###, e");
	}
	
	public static List<String> getImgFormat()
	{
		List<String> uploadFormat = new ArrayList<String>();
		uploadFormat.add("jpg");
		uploadFormat.add("jpeg");
		uploadFormat.add("png");
		uploadFormat.add("gif");
		uploadFormat.add("dib");
		uploadFormat.add("tif");
		uploadFormat.add("jfif");
		uploadFormat.add("tiff");
		uploadFormat.add("heic");
		uploadFormat.add("bmp");
		return uploadFormat;
	}
	
	public static List<String> getAudioFormat()
	{
		List<String> uploadFormat = new ArrayList<String>();
		uploadFormat.add("wav");
		uploadFormat.add("mp3");
		uploadFormat.add("wma");
		uploadFormat.add("midi");
		uploadFormat.add("m4a");
		uploadFormat.add("amr");
		uploadFormat.add("ac3");
		uploadFormat.add("acc");
		uploadFormat.add("aac");
		uploadFormat.add("mp2");
		
		return uploadFormat;
	}

	public static List<String> getVideoFormat()
	{
		List<String> uploadFormat = new ArrayList<String>();
		uploadFormat.add("webm");
		uploadFormat.add("mpg");
		uploadFormat.add("mp2");
		uploadFormat.add("mpeg");
		uploadFormat.add("mpe");
		uploadFormat.add("mpv");
		uploadFormat.add("ogg");
		uploadFormat.add("mp4");
		uploadFormat.add("m4p");
		uploadFormat.add("m4v");		
		uploadFormat.add("avi");
		uploadFormat.add("wmv");
		uploadFormat.add("mov");
		uploadFormat.add("qt");
		uploadFormat.add("flv");
		uploadFormat.add("swf");
		return uploadFormat;
	}
}
