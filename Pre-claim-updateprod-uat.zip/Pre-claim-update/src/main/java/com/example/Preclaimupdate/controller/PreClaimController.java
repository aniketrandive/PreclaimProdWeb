package com.example.Preclaimupdate.controller;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Base64.Encoder;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.example.Preclaimupdate.common.Config;
import com.example.Preclaimupdate.common.CustomMethods;
import com.example.Preclaimupdate.controller.Repository.AdminuserRepository;
import com.example.Preclaimupdate.controller.Repository.Audit_Case_pivformRepository;
import com.example.Preclaimupdate.controller.Repository.Case_movementRepository;
import com.example.Preclaimupdate.controller.Repository.Case_pivformRepository;
import com.example.Preclaimupdate.controller.Repository.CaselistsRepository;
import com.example.Preclaimupdate.entity.Admin_user;
import com.example.Preclaimupdate.entity.Audit_case_pivform;
import com.example.Preclaimupdate.entity.CaseCategorywiseRequest;
import com.example.Preclaimupdate.entity.CaseIdRequest;
import com.example.Preclaimupdate.entity.CaseRequest;
import com.example.Preclaimupdate.entity.Case_Details;
import com.example.Preclaimupdate.entity.Case_docs;
import com.example.Preclaimupdate.entity.Case_lists;
import com.example.Preclaimupdate.entity.Case_movement;
import com.example.Preclaimupdate.entity.Case_pivform;
import com.example.Preclaimupdate.entity.DashboardRequest;
import com.example.Preclaimupdate.entity.GetQuestionarieRequest;
import com.example.Preclaimupdate.entity.LocationTrackRequest;
import com.example.Preclaimupdate.entity.LoginRequest;
import com.example.Preclaimupdate.entity.MobileRequest;
import com.example.Preclaimupdate.entity.Response;
import com.example.Preclaimupdate.entity.UpdateCaseRequest;
import com.example.Preclaimupdate.entity.UsernameRequest;
import com.example.Preclaimupdate.entity.req_qustion;
import com.example.Preclaimupdate.entity.version;
import com.example.Preclaimupdate.service.PreClaimService;

import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping
public class PreClaimController {

	//Logger logger = LoggerFactory.getLogger(PreClaimController.class);

	@Autowired
	private PreClaimService pre;

	@Autowired
	private Case_movementRepository case_movementRepository;

	@Autowired
	private Case_pivformRepository case_pivformRepository;
	
	@Autowired
	private CaselistsRepository caselistsRepository;
	 

	@Autowired
	private Audit_Case_pivformRepository audit_case_pivformRepository;
	
	@Autowired
	private AdminuserRepository Adminuser;

	Response jsonResponse = new Response();

	@Autowired
	private Config config;

	@GetMapping("/")
	@ApiOperation(value = "Main logic", notes = "To check the API is working. Contains version no to be used in child URLs")
	public ResponseEntity<Response> main() {
		jsonResponse.setData("Hi !! I'm API service. " + config.getVersion());
		jsonResponse.setStatus("Login successful");
		return new ResponseEntity<>(jsonResponse, HttpStatus.OK);
	}

	@PostMapping("/login")
	@ApiOperation(value = "Login API", notes = "To validate active Investigators by Username")
	public ResponseEntity<Response> login(@RequestBody LoginRequest username) {
		if (!username.getVersion().equals(config.getVersion())) {
			jsonResponse.setData("Version Incompatible. Kindly update");
			jsonResponse.setStatus("Failed");
			return new ResponseEntity<>(jsonResponse, HttpStatus.OK);
		} else {

			Admin_user user = pre.getbyusername(username.getUsername());
			if (user != null && user.getRole_name().equals("INV")) {

				jsonResponse.setData(user);
				jsonResponse.setStatus("Login successful");
				return new ResponseEntity<>(jsonResponse, HttpStatus.OK);

			} else {
				jsonResponse = new Response();
				jsonResponse.setStatus("Invalid credentials");
				return new ResponseEntity<>(jsonResponse, HttpStatus.OK);
			}
		}
	}

	@PostMapping("/getCaseDetailsByCaseId")
	@ApiOperation(value = "Get Case Details by Case ID", notes = "To retrieve case details by passing Case ID")
	public ResponseEntity<Response> getCaseDetailsByCaseId(@RequestBody CaseIdRequest username) {
		if (!username.getVersion().equals(config.getVersion())) {
			jsonResponse.setData("Version Incompatible. Kindly update");
			jsonResponse.setStatus("Failed");
			return new ResponseEntity<>(jsonResponse, HttpStatus.OK);
		}

		long id = username.getCaseid();
		Case_Details log = pre.GetCaseDetailsByCaseId(username);

		if (log != null) {
			Case_movement case_movement = case_movementRepository.findByCaseId(id);
			System.out.println(log);
			if (case_movement != null) {
				log.setRemarks(case_movement.getRemarks());
				log.setCaseMovementStatus(case_movement.getCaseStatus());
				log.setFromUser(pre.getbyusername(case_movement.getFromId()).getFull_name());
			}
			jsonResponse.setData(log);
			jsonResponse.setStatus("****");
			return new ResponseEntity<>(jsonResponse, HttpStatus.OK);
		} else {
			jsonResponse.setData(null);
			jsonResponse.setStatus("Case not maching with System");
			return new ResponseEntity<>(jsonResponse, HttpStatus.INTERNAL_SERVER_ERROR);
		}

	}

	@PostMapping("/GetCaseListByUsername")
	@ApiOperation(value = "Get all case details by Investigator ID", notes = "To retrieve case details by passing Investigator ID")
	public ResponseEntity<Response> GetCaseListByUsername(@RequestBody UsernameRequest username) {
		if (!username.getVersion().equals(config.getVersion())) {
			jsonResponse.setData("Version Incompatible. Kindly update");
			jsonResponse.setStatus("Failed");
			return new ResponseEntity<>(jsonResponse, HttpStatus.OK);
		}
		Admin_user user = pre.getbyusername(username.getUsername());
		if (user == null) {
			jsonResponse.setStatus("Failed");
			jsonResponse.setData("Invalid Username");
			return new ResponseEntity<>(jsonResponse, HttpStatus.OK);
		}
		if (!user.getRole_name().equals("INV")) {
			jsonResponse.setStatus("Failed");
			jsonResponse.setData("User not authorised");
			return new ResponseEntity<>(jsonResponse, HttpStatus.OK);
		}

		// Input Parameters
		String investigatorId = username.getUsername();
		int pageSize = username.getPagesize();
		int pageNum = username.getPageNum();

		int min = pageSize * (pageNum - 1) + 1;
		int max = pageNum * pageSize;
		List<Case_lists> caselist = pre.GetCaseListByUsername(investigatorId, min, max);
		for (int i = 0; i < caselist.size(); i++) {
			Case_movement case_movement = case_movementRepository.findByCaseId(caselist.get(i).getCaseId());
			if (case_movement != null) {
				caselist.get(i).setRemarks(case_movement.getRemarks());
				caselist.get(i).setCaseMovementStatus(case_movement.getCaseStatus());
				caselist.get(i).setFromUser(pre.getbyusername(case_movement.getFromId()).getFull_name());
			}
		}

		jsonResponse.setData(caselist);
		jsonResponse.setStatus("case list details");
		return new ResponseEntity<>(jsonResponse, HttpStatus.OK);

	}

	@PostMapping("/dashboard")
	@ApiOperation(value = "Dashboard", notes = "To get all new case assigned to Investigator based on Investigation Type")
	public ResponseEntity<Response> dashboard(@RequestBody DashboardRequest username) {
		if (!username.getVersion().equals(config.getVersion())) {
			jsonResponse.setData("Version Incompatible. Kindly update");
			jsonResponse.setStatus("Failed");
			return new ResponseEntity<>(jsonResponse, HttpStatus.OK);
		}

		Admin_user user = pre.getbyusername(username.getUsername());
		if (user != null) {
			HashMap<String, Object> log = pre.dashboard(username);
			jsonResponse.setData(log);
			jsonResponse.setStatus("****");
		} else {
			jsonResponse.setData("Username not found");
			jsonResponse.setStatus("****");
		}
		return new ResponseEntity<>(jsonResponse, HttpStatus.OK);
	}

	@PostMapping("/getCaseCategorywiseList")
	@ApiOperation(value = "Get Case Details by Investigation Type", notes = "Get List of Cases assigned to Investigator by passing Investigator ID & Investigation Type")
	public ResponseEntity<Response> getCaseCategoryList(@RequestBody CaseCategorywiseRequest request) {
		if (!request.getVersion().equals(config.getVersion())) {
			jsonResponse.setData("Version Incompatible. Kindly update");
			jsonResponse.setStatus("Failed");
			return new ResponseEntity<>(jsonResponse, HttpStatus.OK);
		}
		Admin_user user = pre.getbyusername(request.getUsername());
		if (user == null) {
			jsonResponse.setStatus("Failed");
			jsonResponse.setData("Invalid Username");
			return new ResponseEntity<>(jsonResponse, HttpStatus.OK);
		}
		if (!user.getRole_name().equals("INV")) {
			jsonResponse.setStatus("Failed");
			jsonResponse.setData("User not authorised");
			return new ResponseEntity<>(jsonResponse, HttpStatus.OK);
		}

		// Input Parameters
		List<Case_lists> caselist = pre.getCaseCategoryList(request);

		jsonResponse.setData(caselist);
		jsonResponse.setStatus("case list details");
		return new ResponseEntity<>(jsonResponse, HttpStatus.OK);
	}

	@PostMapping("/uploadFile")
	@ApiOperation(value = "Upload Case Documents", notes = "Upload image, audio, video & pdf through this API.")
	public ResponseEntity<Response> uploadFile(@RequestParam("uploadedFile") MultipartFile uploadedFile,
			HttpServletRequest request) throws IOException {
		String version = request.getParameter("version") == null ? "" : request.getParameter("version");
		if (!version.equals(config.getVersion())) {
			jsonResponse.setData("Version Incompatible. Kindly update");
			jsonResponse.setStatus("Failed");
			return new ResponseEntity<>(jsonResponse, HttpStatus.OK);
		}

		HashMap<String, Object> log = pre.fileupload(uploadedFile, request);
		if (log.isEmpty()) {
			jsonResponse.setData("File uploaded successfully");
			jsonResponse.setStatus("*****");
		} else
			jsonResponse.setData(log);
		return new ResponseEntity<>(jsonResponse, HttpStatus.OK);
	}

	@PostMapping("/updateCaseDetails")
	@ApiOperation(value = "Upload Case Details", notes = "Update Case Details such as longitude, latitude, investigator remarks etc")
	public ResponseEntity<Response> updateCaseDetails(@RequestBody UpdateCaseRequest username) {
		if (!username.getVersion().equals(config.getVersion())) {
			jsonResponse.setData("Version Incompatible. Kindly update");
			jsonResponse.setStatus("Failed");
			return new ResponseEntity<>(jsonResponse, HttpStatus.OK);
		}

		jsonResponse.setData(pre.updateCaseDetails(username));
		jsonResponse.setStatus("*****");
		return new ResponseEntity<>(jsonResponse, HttpStatus.OK);
	}

	@PostMapping("/updateUserDetails")
	@ApiOperation(value = "Upload Investigator Details", notes = "Update Investigator Details such as mobile number, email address etc")
	public ResponseEntity<Response> updateUserDetails(
			@RequestParam(value = "updatePhoto", required = false) MultipartFile updatePhoto,
			HttpServletRequest request) {
		String version = request.getParameter("version") == null ? "" : request.getParameter("version");
		if (!version.equals(config.getVersion())) {
			jsonResponse.setData("Version Incompatible. Kindly update");
			jsonResponse.setStatus("Failed");
			return new ResponseEntity<>(jsonResponse, HttpStatus.OK);
		}

		HashMap<String, String> log = new HashMap<String, String>();
		String candidatePhoto = "";
		try {
			if (updatePhoto != null) {
				candidatePhoto = updatePhoto.getOriginalFilename();
				Files.write(Paths.get(config.getUploadDirectory() + candidatePhoto), updatePhoto.getBytes());
			}
			String username = request.getParameter("username");
			String password = request.getParameter("password");
			String full_name = request.getParameter("full_name");
			String emailId = request.getParameter("emailId");
			String contactNumber = request.getParameter("contactNumber");

			if (username == null) {
				log.put("error_code", "Failed");
				log.put("error_description", "User ID not entered");
				jsonResponse.setData(log);
				return new ResponseEntity<>(jsonResponse, HttpStatus.OK);
			}

			Admin_user user = pre.getbyusername(username);

			if (user == null) {
				log.put("error_code", "Failed");
				log.put("error_description", "Invalid User ID");
				jsonResponse.setData(log);
				return new ResponseEntity<>(jsonResponse, HttpStatus.OK);
			}

			if (full_name != null)
				user.setFull_name(full_name);
			if (password != null) {
				Encoder encoder = Base64.getEncoder();
				user.setPassword(encoder.encodeToString(password.getBytes()));
			}
			if (emailId != null)
				user.setUser_email(emailId);
			if (contactNumber != null)
				user.setMobile_number(contactNumber);
			if (!candidatePhoto.equals(""))
				user.setUser_image(candidatePhoto);

			if (log.size() == 0) {
				pre.save(user);
				jsonResponse.setStatus("****");
				jsonResponse.setData("Candidate Details updated successfully");
			} else
				jsonResponse.setData(log);

		} catch (Exception ex) {
			log.put("error_code", "Failed");
			log.put("error_description", ex.getMessage());
			CustomMethods.logError(ex);
		}
		return new ResponseEntity<>(jsonResponse, HttpStatus.OK);
	}

	@PostMapping("/locationtrack")
	@ApiOperation(value = "Update Location status", notes = "Track Location status")
	public ResponseEntity<Response> locationtrack(@RequestBody LocationTrackRequest request) {
		HashMap<String, Object> log = pre.locationtrack(request);
		System.out.println("log" + log);
		if (!log.isEmpty())
			jsonResponse.setData(log);
		else {
			jsonResponse.setStatus("******");
			jsonResponse.setData("Tracking updated successful");
		}
		return new ResponseEntity<>(jsonResponse, HttpStatus.OK);
	}

	@PostMapping("/addPIVQuestionarie")
	public ResponseEntity<Response> addPIVQuestionarie(@RequestBody List<req_qustion> question) {

		System.out.println(question);
		HashMap<String, Object> log = pre.save(question);
		if (!log.isEmpty()) {

			jsonResponse.setData(log);
		} else {

			jsonResponse.setStatus("****");
			jsonResponse.setData("Investigation Form added successfully");				}
	return new ResponseEntity<>(jsonResponse,HttpStatus.OK);
	}

	@PostMapping("/updatePIVQuestionarie")
	public ResponseEntity<Response> updatePIVQuestionarie(@RequestBody req_qustion request)
	{
		try
		{
			Case_pivform case_pivform = case_pivformRepository.findById(request.getFormId()).get();
			Audit_case_pivform audit_case_pivform = audit_case_pivformRepository.findByFormId(request.getFormId());
			case_pivform.setQuestion_remarks(request.getQuestion_remarks());
			audit_case_pivform.setQuestion_remarks(request.getQuestion_remarks());
			audit_case_pivform.setUpdatedDate(new Date());
			audit_case_pivform.setUpdated_by(request.getCreated_by());
			case_pivformRepository.save(case_pivform);
			audit_case_pivformRepository.save(audit_case_pivform);
			jsonResponse.setStatus("******");
			jsonResponse.setData("Updated successful");
		}
		catch(Exception e)
		{
			jsonResponse.setStatus("Failed");
			jsonResponse.setData("FormId not found");	
		}
		return new ResponseEntity<>(jsonResponse, HttpStatus.OK);
	}

	@PostMapping("/getPIVQuestionarie")
	public ResponseEntity<Response> getPIVQuestionarie(@RequestBody GetQuestionarieRequest request)
	{
		if(!request.getVersion().equals(config.getVersion())) 
		{
			jsonResponse.setStatus("Failed");
			jsonResponse.setData("Version Incompatible. Kindly update");
			return new ResponseEntity<>(jsonResponse, HttpStatus.OK);
		}
		else 
		{
			List<Case_pivform> data = case_pivformRepository.getDetailByCaseId(request.getCaseId());
			if(data.isEmpty()) 
		    {
			    jsonResponse.setData("CaseId not found");
			    jsonResponse.setStatus("Failed");					
			}
			else 
			{
				jsonResponse.setData(case_pivformRepository.getDetailByCaseId(request.getCaseId()));
				jsonResponse.setStatus("****");
			}	
			
		}
		
		return new ResponseEntity<>(jsonResponse, HttpStatus.OK);
	}

	
	
	@PostMapping("/checkMobileNumber")
	public ResponseEntity<Response> checkMobileNumber(@RequestBody MobileRequest request) 
	{
		int log = Adminuser.getmobile_number(request.getMobileNumber());
		if(log == 0) 
		{
			 jsonResponse.setData("Invalid Mobile Number");
	         jsonResponse.setStatus("Failed");
		}
         else		
		{	
			jsonResponse.setStatus("****");
			jsonResponse.setData("Successfully validated");
		}
		return new ResponseEntity<>(jsonResponse, HttpStatus.OK);
	}

	@PostMapping("/getCaseList")
	public ResponseEntity<Response> getCaseList(@RequestBody version version) {
		System.out.println("config.getVersion()--"+config.getVersion());
		System.out.println("version--"+version);
		if (!version.getVersion().equals(config.getVersion())) {
			jsonResponse.setStatus("Failed");
			jsonResponse.setData("Version Incompatible. Kindly update");
			return new ResponseEntity<>(jsonResponse, HttpStatus.OK);
		} else {
			List<Case_lists> data = caselistsRepository.getCaseDetailList();
			List<CaseRequest> caseRequest = new ArrayList<>();
			if (data.isEmpty()) {
				jsonResponse.setData("CaseId not found");
				jsonResponse.setStatus("Failed");
			} else {
				for (Case_lists cl : data) {
					CaseRequest caseReq = new CaseRequest();
					caseReq.setCaseId(Long.toString(cl.getCaseId()));
					caseReq.setPolicyNumber(cl.getPolicyNumber());
					caseRequest.add(caseReq);
				}
				jsonResponse.setData(caseRequest);
				jsonResponse.setStatus("****");
			}

		}

		return new ResponseEntity<>(jsonResponse, HttpStatus.OK);
	}

	@PostMapping("/getCaseDocsList")
	public ResponseEntity<Response> getCaseDocsList(@RequestBody GetQuestionarieRequest request) {
		if(request.getCaseId()==0) {
			jsonResponse.setStatus("Failed");
			jsonResponse.setData("CaseId is Canot be blank");
			return new ResponseEntity<>(jsonResponse, HttpStatus.OK);
		} else {
			List<Case_docs> data = pre.getCaseDocsList(Long.toString(request.getCaseId()));
			System.out.println("getCaseId"+Long.toString(request.getCaseId()));
			//List<Case_docs> caseRequest = new ArrayList<>();
			if (data.isEmpty()) {
				jsonResponse.setData("Doc not found");
				jsonResponse.setStatus("Failed");
			} else {
				/*for (Case_lists cl : data) {
					CaseRequest caseReq = new CaseRequest();
					caseReq.setCaseId(Long.toString(cl.getCaseId()));
					caseReq.setPolicyNumber(cl.getPolicyNumber());
					caseRequest.add(caseReq);
				}*/
				jsonResponse.setData(data);
				jsonResponse.setStatus("****");
			}

		}

		return new ResponseEntity<>(jsonResponse, HttpStatus.OK);
	}

}
