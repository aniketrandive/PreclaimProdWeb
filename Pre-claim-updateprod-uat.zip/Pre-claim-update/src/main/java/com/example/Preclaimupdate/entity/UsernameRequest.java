package com.example.Preclaimupdate.entity;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter @Setter @ToString
public class UsernameRequest {

	private String username = "";
	private int pagesize = 0;
	private int pageNum = 0;
	private String version = "";
	
}
