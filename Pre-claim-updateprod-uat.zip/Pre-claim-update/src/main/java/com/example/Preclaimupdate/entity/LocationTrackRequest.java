package com.example.Preclaimupdate.entity;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter @Setter @ToString
public class LocationTrackRequest {

	private String username = "";
	private String latitude = "";
	private String longitude = "";
	
}
