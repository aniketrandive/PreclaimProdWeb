package com.example.Preclaimupdate.controller.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.example.Preclaimupdate.entity.Audit_case_pivform;
import com.example.Preclaimupdate.entity.Case_pivform;

@Repository
public interface Audit_Case_pivformRepository extends JpaRepository<Audit_case_pivform, Long> {
		
	
	@Query(value="delete  from case_pivform where caseId = :caseId", nativeQuery = true)
	void DeleteDetailsByCaseId(@Param("caseId")long caseid); 
	
	Audit_case_pivform findByFormId(long caseid);

}
