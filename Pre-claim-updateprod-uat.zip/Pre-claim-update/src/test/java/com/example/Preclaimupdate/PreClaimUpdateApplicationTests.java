package com.example.Preclaimupdate;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PreClaimUpdateApplicationTests {

	@Test
	void contextLoads() {
	}

}
