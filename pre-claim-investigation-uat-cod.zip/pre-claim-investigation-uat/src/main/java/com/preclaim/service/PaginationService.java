package com.preclaim.service;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.preclaim.config.Config;
import com.preclaim.dao.LocationDao;
import com.preclaim.entity.Case_lists;
import com.preclaim.models.Location;
import com.preclaim.models.UserDetails;
import com.preclaim.repository.CaselistsPagingRepository;

@Service
public class PaginationService {
	
	@Autowired
	CaselistsPagingRepository caserepo;
	
	@Autowired
	LocationDao locationDao;
	
	@Autowired
	Config config;
	
	
	public Page<Case_lists> getCaselist(Pageable Page,HttpServletRequest request, UserDetails user){
		
		/*
		 * UserDetails user = (UserDetails) session.getAttribute("User_Login"); */  Location location = locationDao.getActiveLocationList(user.getCity());
		
		
//		  List<Case_lists>  case1 =null;
		  Page<Case_lists> case1 =null;
		if (user.getAccount_type().equalsIgnoreCase(config.getADMIN())) {
			System.err.println("inside ADMIN");
	    case1 = caserepo.getCaselistsAdmin(Page);
	}
		else if (user.getAccount_type().equalsIgnoreCase(config.getREGIONAL_MANAGER())) {
			System.err.println("inside REGIONAL_MANAGER");
			System.err.println("user.getUsername(), user.getAccount_type(), location.getZone()"+user.getUsername()+" "+user.getAccount_type()+" "+ location.getZone());
		   case1 = caserepo.getCaselistsRM(Page,user.getUsername(), user.getAccount_type(), location.getZone());
			//case1 = caserepo.getCaselistsRM(user.getUsername(),location.getZone());
		}
		else {
			System.err.println("inside user");
			 case1 = caserepo.getCaselists(Page,user.getUsername());
		}
		
		return case1;	
	}
	
	

}
