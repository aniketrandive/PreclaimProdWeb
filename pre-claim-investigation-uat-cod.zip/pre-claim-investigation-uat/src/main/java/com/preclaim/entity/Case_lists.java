package com.preclaim.entity;


import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.preclaim.models.NatureOfInvestigation;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
@Getter @Setter @ToString @NoArgsConstructor
@Entity
@Table(name = "case_lists")
public class Case_lists {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "caseId")
	private long caseId = 0;
	
	@Column(name = "ID")
	private long ID = 0;
	
	@Column(name = "policyNumber")
	private String policyNumber = "";

	
//	@Column(name = "nature_of_investigationId")
//	private int nature_of_investigationId = 0;
	
	@JsonIgnore
	@Column(name = "issuedDate")
	private String issuedDate = "";

	@Column(name = "insuredName")
	private String insuredName = "";

	@JsonIgnore
	@Column(name = "insuredMob")
	private String insuredMob = "";

	@JsonIgnore
	@Column(name = "insuredDOD")
	private String insuredDOD = "";

	@JsonIgnore
	@Column(name = "insuredDOB")
	private String insuredDOB = "";

	@JsonIgnore
	@Column(name = "insuredDiagnosisDate")
	private String insuredDiagnosisDate = "";

	@JsonIgnore
	@Column(name = "sumAssured")
	private double sumAssured = 0;

	@JsonIgnore
	@Column(name = "gender")
	private String gender = "";

	@Column(name = "investigationType")
	private String investigationType = "";

//	@OneToOne
//	@JoinColumn(name = "locationId", referencedColumnName = "locationId")
//	Location_lists location = new Location_lists();
	
	@Column(name = "zone")
	private String zone = "";

	@JsonIgnore
	@Column(name = "caseStatus")
	private String caseStatus = "";

	@Column(name = "caseSubStatus")
	private String caseSubStatus = "";
	
	@JsonIgnore
	@Column(name = "trigger_name")
	private String trigger_name = "";

	@JsonIgnore
	@Column(name = "trigger_dept")
	private String trigger_dept = "";
	
	@JsonIgnore
	@Column(name = "disposition_name")
	private String disposition_name = "";

	@JsonIgnore
	@Column(name = "nominee_Name")
	private String nominee_Name = "";

	@JsonIgnore
	@Column(name = "nominee_ContactNumber")
	private String nominee_ContactNumber = "";

	@JsonIgnore
	@Column(name = "nominee_address")
	private String nominee_address = "";

	@JsonIgnore
	@Column(name = "pincode")
	private String pincode = "";

	@JsonIgnore
	@Column(name = "insured_address")
	private String insured_address = "";

	@JsonIgnore
	@Column(name = "case_description")
	private String case_description = "";

	@JsonIgnore
	@Column(name = "longitude")
	private String longitude = "";

	@JsonIgnore
	@Column(name = "latitude")
	private String latitude = "";
	
	@JsonIgnore
	@Column(name = "createdBy")
	private String createdBy = "";

	
	@Column(name = "createdDate")
	private Date createdDate = new Date();

	
	@Column(name = "updatedDate")
	private Date updatedDate = new Date();

	@JsonIgnore
	@Column(name = "updatedBy")
	private String updatedBy = "";
	
	@JsonIgnore
    @Transient 
	private String remarks;
	
    
	@Column(name ="nature_of_investigationType")
	private String nature_of_investigationType = "";
    
    
   	@Column(name ="TAT")
   	private int TAT = 0;
	
   	@JsonIgnore
	@Transient
	private String caseMovementStatus = "";
	


}
