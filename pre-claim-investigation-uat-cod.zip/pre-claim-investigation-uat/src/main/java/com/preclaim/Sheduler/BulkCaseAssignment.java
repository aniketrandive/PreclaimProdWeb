//package com.preclaim.Sheduler;
//
//import java.util.List;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.scheduling.annotation.EnableScheduling;
//import org.springframework.scheduling.annotation.Scheduled;
//import org.springframework.stereotype.Service;
//
//import com.preclaim.config.CustomMethods;
//import com.preclaim.dao.CaseDao;
//import com.preclaim.dao.Case_movementDao;
//import com.preclaim.dao.UserDAO;
//import com.preclaim.entity.BulkSchedulerData;
//import com.preclaim.models.CaseDetails;
//import com.preclaim.models.CaseMovement;
//import com.preclaim.models.CaseSubStatus;
//import com.preclaim.models.UserDetails;
//import com.preclaim.repository.BulkSchedulerDataRepositry;
//
//@Service
//@EnableScheduling
//public class BulkCaseAssignment {
//	
//	@Autowired
//	Case_movementDao caseMovementDao;
//	
//	@Autowired
//	BulkSchedulerDataRepositry BulkSchedulerDataRepositry;
//
//	@Autowired
//	UserDAO userDao;
//	
//	@Autowired
//	CaseDao caseDao;
//	
//	public String toRole = "";
//	public String  toId = "";
//	
//	@Scheduled(cron = "*/10 * * * * *")
//	public void runEvey5Minutes() {
//		UserDetails toUser, fromuser = null;
//		List<BulkSchedulerData> bulkList = BulkSchedulerDataRepositry.getBulkCaseAssign();
//		if (bulkList != null && bulkList.size() > 0) {
//			for (BulkSchedulerData BulkSchedulerData : bulkList) {
//				try {
//					toRole = BulkSchedulerData.getToRole();
//					toId = BulkSchedulerData.getToID();
//					CaseDetails caseDetail = new CaseDetails();
//					CaseSubStatus status = new CaseSubStatus();
//					fromuser = userDao.getUserDetails(BulkSchedulerData.getFromID());
//					toUser = userDao.getUserDetails(BulkSchedulerData.getToID());
//					if (BulkSchedulerData.getToStatus().equals("Approved")) {
//
//						if (toUser.getAccount_type().equals("AGNSUP") && fromuser.getAccount_type().equals("REGMAN")) {
//							System.out.println("enter1");
//							caseDao.deletepiv(caseDetail, toUser, fromuser);
//						}
//						
//						if (BulkSchedulerData.getCaseSubStatus().equals("")) {
//							status = caseDao.getCaseStatus(fromuser.getAccount_type(), BulkSchedulerData.getToRole(), BulkSchedulerData.getToStatus());
//
//							if (status == null)
//								status = new CaseSubStatus();
//							caseDetail.setCaseStatus(status.getCase_status());
//							caseDetail.setCaseSubStatus(status.getCaseSubStatus());
//						} else {
//							caseDetail.setCaseStatus("Open");
//							caseDetail.setCaseSubStatus(BulkSchedulerData.getCaseSubStatus());
//							caseDetail.setNotCleanCategory(BulkSchedulerData.getNotCleanCategory());
//						}
//					}
//					else if (BulkSchedulerData.getToStatus().equals("Reopen")) {
//						caseDetail.setCaseStatus("Reopen");
//						caseDetail.setCaseSubStatus("Further Requirement");
//					}
//					// Closed
//					else if (BulkSchedulerData.getToStatus().equals("Closed")) {
//						caseDetail.setNotCleanCategory(BulkSchedulerData.getNotCleanCategory());
//						caseDetail.setCaseStatus(BulkSchedulerData.getToStatus());
//						caseDetail.setCaseSubStatus(BulkSchedulerData.getCaseSubStatus());
//						toRole = "";
//						toId = "";
//					}
//					caseDetail.setUpdatedBy(BulkSchedulerData.getFromID());
//					String caseid = BulkSchedulerData.getCaseID()+"";
//					caseDao.bulkUpdateCaseTypeAndSubType(caseDetail, caseid);
//					CaseMovement case_movement = new CaseMovement(BulkSchedulerData.getCaseID(), BulkSchedulerData.getFromID(), toId,
//							BulkSchedulerData.getToStatus(), BulkSchedulerData.getToRemarks(), toRole);
//					String message = caseMovementDao.BulkupdateCaseMovement(case_movement, caseid);
////					String message ="****";
//					if(message.equalsIgnoreCase("****")) {
//						BulkSchedulerData.setFlag(2);
//						BulkSchedulerData.setResponce("assigned");
//					}
//					else {
//						BulkSchedulerData.setResponce(message);
//					}
//					
//				} catch (Exception e) {
//					BulkSchedulerData.setResponce(e.getMessage());
//					e.printStackTrace();
//					CustomMethods.logError(e);
//				}
//				//catch end
//				
//				BulkSchedulerDataRepositry.save(BulkSchedulerData);
//			}
//			//for loop end
//		}
//		//if end
//	}
////runEvey5Minutes end
//}
////class end