//package com.preclaim.Sheduler;
//
//import java.io.File;
//import java.util.Date;
//import java.util.List;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.scheduling.annotation.EnableScheduling;
//import org.springframework.scheduling.annotation.Scheduled;
//import org.springframework.stereotype.Service;
//
//import com.preclaim.config.Config;
//import com.preclaim.config.CustomMethods;
//import com.preclaim.dao.MailConfigDao;
//import com.preclaim.dao.UserDAO;
//import com.preclaim.entity.BulkSchedulerData;
//import com.preclaim.models.MailConfig;
//import com.preclaim.models.UserDetails;
//import com.preclaim.repository.BulkSchedulerDataRepositry;
//
//@Service
//@EnableScheduling
//public class MailSendShedular {
//
//	@Autowired
//	MailConfigDao mailConfigDao;
//
//	@Autowired
//	UserDAO userDao;
//
//	@Autowired
//	Config config;
//
//	@Autowired
//	BulkSchedulerDataRepositry BulkSchedulerDataRepositry;
//
//	public String message_body = "";
//	public String mailmessage = "";
//	public String result="";
//	
//	@Scheduled(cron = "*/10 * * * * *")
//	public void runEvey1Minutes() {
//		UserDetails toUser, fromuser = null;
//		String filename = "";
//		MailConfig mail = mailConfigDao.getActiveConfig();
//		String message_body = "";
//		List<BulkSchedulerData> bulkList = BulkSchedulerDataRepositry.getMailSendData();
//		if (bulkList != null && bulkList.size() > 0) {
//			for (BulkSchedulerData BulkSchedulerData : bulkList) {
//				try {
//				fromuser = userDao.getUserDetails(BulkSchedulerData.getFromID());
//				toUser = userDao.getUserDetails(BulkSchedulerData.getToID());
//				if (fromuser != null) {
//					mail.setSubject("Bulk Case Assigned - Claims");
//					message_body = fromUserBody(BulkSchedulerData,fromuser);
//					mail.setMessageBody(message_body);
//					System.out.println("message_body fromUserBody" +message_body);
//					mail.setReceipent(fromuser.getUser_email());
//					
//					
//					result=mailConfigDao.sendMail(mail);
//					if(result.equalsIgnoreCase("****")) {
//						BulkSchedulerData.setFlag(2);
//						mailmessage ="fromuser";}
//						else {
//						mailmessage ="fromuser-mailnotsent";}
//					
//					
//					
//				}
//				if (toUser != null) {
//
//					mail.setSubject("New Bulk Case Assigned - Claims");
//					message_body = toUserBody(BulkSchedulerData,toUser);
//					mail.setMessageBody(message_body);
//					System.out.println("message_body fromUserBody" +message_body);
//					mail.setReceipent(toUser.getUser_email());
//					if (BulkSchedulerData.getToStatus().equals("Approved")
//							&& (BulkSchedulerData.getToRole().equals(config.getSUPERVISOR()))) {
//
//						filename = config.getUpload_directory() + BulkSchedulerData.getDoc1();
//						File investigationLetter = new File(filename);
//						if (investigationLetter.isFile())
//							mail.setAppointmentPath(filename);
//						filename = config.getUpload_directory() + BulkSchedulerData.getDoc2();
//						investigationLetter = new File(filename);
//						if (investigationLetter.isFile())
//							mail.setAuthorizationPath(filename);
//						
//
//					}					
//						result=mailConfigDao.sendMail(mail);
//						if(result.equalsIgnoreCase("****")) {
//						BulkSchedulerData.setFlag(3);
//						mailmessage +="-toUser";}
//						else {
//						mailmessage +="&&toUser-mailnotsent";
//						}
//					
//				}
//				BulkSchedulerData.setUpdatedDate(new Date());
//				BulkSchedulerData.setResponce(mailmessage);
//				
//				} catch (Exception e) {
//					// TODO: handle exception
//					BulkSchedulerData.setResponce("MailNotSent");
//					e.printStackTrace();
//
//					CustomMethods.logError(e);
//				}
//				
//				BulkSchedulerDataRepositry.save(BulkSchedulerData);
//			} // For Loop End
//
//		} // If Close
//
//	}
//
//	public String fromUserBody(BulkSchedulerData BulkSchedulerData, UserDetails fromuser) {
//		
//		message_body = "Dear <User>, \n Bulk Case has been assigned successfully\n\n";
//		message_body += "CaseID :- " + BulkSchedulerData.getCaseID() + "\n\n";
//		message_body = message_body.replaceAll("<User>", fromuser.getFull_name());
//		message_body += "Thanks & Regards,\n Claims";
//		
//		return message_body;
//
//	}
//	
//public String toUserBody(BulkSchedulerData BulkSchedulerData,UserDetails toUser) {
//		
//		
//	message_body = "Dear <User>, \n Your are required to take action on new cases\n\n";
//	message_body += "CaseID :- " + BulkSchedulerData.getCaseID() + "\n\n";
//	message_body = message_body.replace("<User>", toUser.getFull_name());
//	 message_body += "Thanks & Regards,\n Claims";
//
//	 return message_body;
//	}
//
//}
