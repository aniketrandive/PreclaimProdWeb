package com.preclaim.dao;

import java.sql.ResultSet;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.preclaim.config.CustomMethods;
import com.preclaim.models.CaseSubStatus;

@Component
public class CaseSubstatusDao{

	@Autowired
	DataSource datasource;

	@Autowired
	private JdbcTemplate template;

	public void setTemplate(JdbcTemplate template) {
		this.template = template;
	}
	
	String sql = "";
	
	public String add_caseSubstatus(CaseSubStatus caseSubStatus) {
		try 
		{
			String caseSubStatusCheck = "select count(*) from case_substatus where fromRole='" 
					+ caseSubStatus.getFromRole() + "' and toRole='"+caseSubStatus.getToRole()+"'";
			int caseSubStatusCount = this.template.queryForObject(caseSubStatusCheck, Integer.class);
			if (caseSubStatusCount == 0) 
			{
				String query = "INSERT INTO case_substatus(fromRole, toRole, Case_status, caseSubStatus,user_action) "
						     + "values(?, ?, ?, ?, '1')";
				template.update(query, caseSubStatus.getFromRole(), caseSubStatus.getToRole(), 
						caseSubStatus.getCase_status(), caseSubStatus.getCaseSubStatus());
			}
			else
				return "Both matching roles are already exists";
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			CustomMethods.logError(e);
			return e.getMessage();
		}
		return "****";
	}
	
	
	public String deleteCaseSubStatus(int caseSubstatusId) {
		try 
		{
			sql = "insert into audit_case_substatus select * from case_substatus WHERE id = ?";
			template.update(sql, caseSubstatusId);
			
			String query = "DELETE FROM case_substatus WHERE id = ?";
			template.update(query, caseSubstatusId);
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
			CustomMethods.logError(e);
			return e.getMessage();
		}
		return "****";
	}
	
	
	public List<CaseSubStatus> getActiveCaseSubStatus_list() {
		//String query =  "select id,(select role from user_role where role_code =fromRole) as fromRole,(select role from user_role where "
			//        	+ "role_code =user_role) as user_role,Case_status,caseSubStatus,level from case_substatus";
		
		String query = "select id,(select role from user_role where role_code =fromRole) as fromRole,(select role from user_role where "
			        	+ "role_code =toRole) as toRole,Case_status,caseSubStatus,user_action from case_substatus";
		return this.template.query(query, (ResultSet rs, int rowNum) -> {
			CaseSubStatus caseSubStatus = new CaseSubStatus();
			caseSubStatus.setId(rs.getInt("id"));
			caseSubStatus.setFromRole(rs.getString("fromRole"));
			caseSubStatus.setToRole(rs.getString("toRole"));
			caseSubStatus.setCase_status(rs.getString("Case_status"));
			caseSubStatus.setCaseSubStatus(rs.getString("caseSubStatus"));
			return caseSubStatus;
		});
	}
	
	public String updateCaseSubStatus(int caseSubStatusId, String CaseStatus,String caseSubStatus) {
		try 
		{
			sql = "insert into audit_case_substatus select * from case_substatus WHERE id = ?";
			template.update(sql, caseSubStatusId);
			
			String sql = "UPDATE case_substatus SET Case_status = ? , caseSubStatus = ?  WHERE id = ?";
			template.update(sql, CaseStatus, caseSubStatus, caseSubStatusId);
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
			CustomMethods.logError(e);
			return e.getMessage();
		}
		return "****";
	}
	
	
	public CaseSubStatus getCaseSubStatusById(int caseSubStatusId)
	{
		String sql = "select * from case_substatus a where  id = ?";
		return template.query(sql,new Object[] {caseSubStatusId},(ResultSet rs, int rowNum) -> {		
			CaseSubStatus details = new CaseSubStatus();
			details.setId(rs.getInt("id"));
			details.setFromRole(rs.getString("fromRole"));
			details.setToRole(rs.getString("toRole"));
			details.setCase_status(rs.getString("Case_status"));
			details.setCaseSubStatus(rs.getString("caseSubStatus"));
			return details;		
		}).get(0);
	}
	
}
