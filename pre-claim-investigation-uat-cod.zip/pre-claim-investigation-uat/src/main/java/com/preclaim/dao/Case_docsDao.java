package com.preclaim.dao;
import java.sql.ResultSet;
import java.util.List;

import javax.sql.DataSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.google.common.collect.ArrayListMultimap;
import com.google.common.collect.Multimap;
import com.preclaim.config.CustomMethods;
import com.preclaim.models.Case_docs;
import com.preclaim.models.UserDetails;

@Component
public class Case_docsDao{

	@Autowired
	DataSource datasource;
	
	@Autowired
	LoginDAO dao;

	@Autowired
	private JdbcTemplate template;

	public Multimap<String, String> getCaseDocsById(int caseId) {
		Multimap<String, String> case_docs = ArrayListMultimap.create();

		try 
		{
			String sql = "select * from case_docs where caseId = ?";
			   template.query(sql, new Object[] {caseId} , 
					(ResultSet rs, int rowNum) -> {
						do
						{
							case_docs.put(rs.getString("doc_type"), 
									rs.getString("doc_name"));
						}while(rs.next());
						return case_docs;
					});
			   return  case_docs;
		}
		catch(Exception e)
		{
			e.printStackTrace();
			return null;
		}
	}	
	
	public List<Case_docs> getdoclist(int username,UserDetails userdeata) {
		try
		{ 	String sql ="";
			if(userdeata.getAccount_type().equals("AGNSUP")) {
				sql ="select * from case_docs where caseId = ? and  created_by in(select username from admin_user where (role_name= 'INV' and vendor_id='"+userdeata.getUsername()+"') or role_name= 'REGMAN' or username ='"+userdeata.getUsername()+"')";	
			}
			else if(userdeata.getAccount_type().equals("INV")) {
				sql ="select * from case_docs where caseId = ? and  created_by in(select username from admin_user where role_name ='INV' and username='"+userdeata.getUsername()+"')";	
			}
			else {
				sql = "select * from case_docs where caseId = ? ";
				}
			List<Case_docs> user_docslist = template.query(sql, 
					new Object[] {username},
					(ResultSet rs, int rowNum) ->{
						Case_docs user_docs = new Case_docs();
						user_docs.setCaseId(rs.getInt("caseId"));
						user_docs.setDoc_type(rs.getString("doc_type"));
						user_docs.setDoc_name(rs.getString("doc_name"));
						user_docs.setCreated_by(rs.getString("created_by"));
						user_docs.setCreated_on(rs.getString("created_on"));					
						return user_docs;
					});
			if(user_docslist!=null) {
				for(int i = 0; i < user_docslist.size(); i++)
				{
					UserDetails user = dao.checkUser(user_docslist.get(i).getCreated_by());
					if(user!= null)
					user_docslist.get(i).setUserdetails(user);					
				}
			}
			return user_docslist;
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
			CustomMethods.logError(ex);
			return null;
		}
	}
	
}

