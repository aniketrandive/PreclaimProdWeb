package com.preclaim.dao;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.sql.Date;
import java.sql.ResultSet;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;
import java.util.regex.Pattern;

import javax.sql.DataSource;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import com.preclaim.config.Config;
import com.preclaim.config.CustomMethods;
import com.preclaim.models.CaseDetailList;
import com.preclaim.models.CaseDetails;
import com.preclaim.models.CaseHistory;
import com.preclaim.models.CaseMovement;
import com.preclaim.models.CaseSubStatus;
import com.preclaim.models.Location;
import com.preclaim.models.MailConfig;
import com.preclaim.models.NatureOfInvestigation;
import com.preclaim.models.UserDetails;
import com.preclaim.models.User_locations;

@Component
public class CaseDaobk {

	@Autowired
	DataSource datasource;

	@Autowired
	JdbcTemplate template;

	@Autowired
	CaseDaobk caseDao;

	@Autowired
	NatureOfInvestigationDao natureOfInvestigationDaoImpl;

	@Autowired
	InvestigationTypeDao investigationTypeDao;

	@Autowired
	LocationDao locationDao;

	@Autowired
	UserDAO userDao;

	@Autowired
	Case_movementDao case_movementDao;
	

	@Autowired
	MailConfigDao mailConfigDao;

	@Autowired
	TriggerDao triggerDao;

	@Autowired
	Config config;

	public void setTemplate(JdbcTemplate template) {
		this.template = template;
	}

	String sql = "";

	public String addBulkUpload(String filename, UserDetails fromUser, String user_role, String assigneeId) {

		String extension = StringUtils.getFilenameExtension(filename).toLowerCase();
		String error = "";
		if (extension.equals("xlsx"))
			error = readCaseXlsx(filename, fromUser, user_role, assigneeId);
		else
			error = "Invalid File extension";
		return error;
	}

	public long addcase(CaseDetails casedetail) {
		try {
			if (checkPolicyNumberWIP(casedetail))
				return -1;
			else if (checkPolicyNumberotherthanCDP(casedetail)
				&&casedetail.getNatureOfInvestigationId()==1
				&&!casedetail.getInvestigationType().equalsIgnoreCase("CDP"))
				return -2;
			else if (checkPolicyNumberCDP(casedetail)
				&&casedetail.getNatureOfInvestigationId()==1
				&&casedetail.getInvestigationType().equalsIgnoreCase("CDP"))
				return -3;

			String current_date = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
			String query = "INSERT INTO case_lists (policyNumber, nature_of_investigationId, issuedDate, insuredName, insuredDOD, insuredDOB, insuredDiagnosisDate, sumAssured, "
					+ "gender,insuredMob, investigationType, locationId, caseStatus, caseSubstatus, nominee_name, nominee_ContactNumber, nominee_address, "
					+ "insured_address, pincode, case_description, longitude, latitude, notCleanCategory, trigger_name, trigger_dept, disposition_name,"
					+ "createdBy, createdDate, updatedDate, updatedBy)" + "values(?, ?, ?, ?, ?, ? ,? ,?"
					+ ",?, ?, ?, ?, ?, ?, ?, ?, ? ," + "?, ?, '', '', '', '', ?, ? ,?," + " ?, ?, ?, '')";
			this.template.update(query, casedetail.getPolicyNumber(), casedetail.getNatureOfInvestigationId(),
					casedetail.getIssuedDate(), casedetail.getInsuredName(), casedetail.getInsuredDOD(),
					casedetail.getInsuredDOB(), casedetail.getDateOfDiagnosis(), casedetail.getSumAssured(),
					casedetail.getGender(), casedetail.getInsuredMob(), casedetail.getInvestigationType(),
					casedetail.getLocationId(), casedetail.getCaseStatus(), casedetail.getCaseSubStatus(),
					casedetail.getNominee_name(), casedetail.getNomineeContactNumber(), casedetail.getNominee_address(),
					casedetail.getInsured_address(), casedetail.getPincode(), casedetail.getTriggerName(),
					casedetail.getTrigger_dept(), casedetail.getDisposition(), casedetail.getCreatedBy(), current_date,
					current_date);

			query = "SELECT caseId FROM case_lists where policyNumber = ? and createdBy = ? and "
					+ "createdDate = ? and updatedBy = ''";
			return template.query(query,
					new Object[] { casedetail.getPolicyNumber(), casedetail.getCreatedBy(), current_date },
					(ResultSet rs, int rowcount) -> {
						return rs.getLong("caseId");
					}).get(0);

		} catch (Exception e) {
			e.printStackTrace();
			CustomMethods.logError(e);
			return 0;
		}
	}

	public List<CaseDetailList> getPendingCaseList(String user_role, String zone, String username) {
		try {
			Object[] obj;
			if (user_role.equalsIgnoreCase(config.getADMIN())) {
				sql = " SELECT * FROM case_lists a, case_movement b where a.caseId = b.caseId and "
						+ "a.caseStatus <> 'Closed'";
				obj = new Object[] {};
			} else if (user_role.equalsIgnoreCase(config.getREGIONAL_MANAGER())) {
				sql = "SELECT * FROM case_lists a, case_movement b where a.caseId = b.caseId "
						+ "and a.caseStatus <> 'Closed' and "
						+ "(toId = ? or (b.toRole = ? and b.zone = ? and b.toId =''))";
				obj = new Object[] { username, user_role, zone };
			} else {
				sql = " SELECT * FROM case_lists a, case_movement b where a.caseId = b.caseId and "
						+ "a.caseStatus <> 'Closed' and b.toId = ?";
				obj = new Object[] { username };
			}

			List<CaseDetailList> casedetailList = template.query(sql, obj, (ResultSet rs, int rowCount) -> {
				CaseDetailList casedetail = new CaseDetailList();
				casedetail.setSrNo(rowCount + 1);
				casedetail.setCaseId(rs.getLong("caseId"));
				casedetail.setPolicyNumber(rs.getString("policyNumber"));
				casedetail.setInsuredName(rs.getString("insuredName"));
				casedetail.setNatureOfInvestigationId(rs.getInt("nature_of_investigationId"));
				casedetail.setSumAssured(rs.getDouble("sumAssured"));
				casedetail.setCaseStatus(rs.getString("caseStatus"));
				casedetail.setInvestigationType(rs.getString("investigationType"));
				casedetail.setNotCleanCategory(rs.getString("notCleanCategory"));
				casedetail.setCaseSubStatus(rs.getString("caseSubStatus"));
				casedetail.setZone(rs.getString("zone"));
				casedetail.setCreatedDate(rs.getString("createdDate"));
				casedetail.setUpdatedDate(rs.getString("updatedDate"));
				return casedetail;
			});
			HashMap<Integer, String> investigationList = natureOfInvestigationDaoImpl
					.getActiveNatureOfInvestigationMapping();
			for (CaseDetailList caseDetail : casedetailList)
				caseDetail.setNatureOfInvestigationCategory(
						investigationList.get(Integer.valueOf(caseDetail.getNatureOfInvestigationId())));
			return casedetailList;

		} catch (Exception ex) {
			ex.printStackTrace();
			CustomMethods.logError(ex);
			return null;
		}
	}

	public List<CaseDetailList> getAssignedCaseList(String user_role, String username) {
		try {
			Object[] obj;
			if (user_role.equalsIgnoreCase(config.getADMIN())) {
				sql = "SELECT * FROM case_lists a, case_movement b where a.caseId = b.caseId";
				obj = new Object[] {};
			} else {
				sql = "select * from case_lists a, (" + "select a.* from audit_case_movement a, ("
						+ "select caseId, max(updatedDate) as updatedDate from audit_case_movement "
						+ "group by caseId ) b " + "where a.caseId = b.caseId and a.updatedDate = b.updatedDate) b "
						+ "where a.caseId = b.caseId and b.fromId = ?";
				obj = new Object[] { username };
			}
			List<CaseDetailList> casedetailList = template.query(sql, obj, (ResultSet rs, int rowCount) -> {
				CaseDetailList casedetail = new CaseDetailList();
				casedetail.setSrNo(rowCount + 1);
				casedetail.setCaseId(rs.getLong("caseId"));
				casedetail.setPolicyNumber(rs.getString("policyNumber"));
				casedetail.setInsuredName(rs.getString("insuredName"));
				casedetail.setNatureOfInvestigationId(rs.getInt("nature_of_investigationId"));
				casedetail.setSumAssured(rs.getDouble("sumAssured"));
				casedetail.setCaseStatus(rs.getString("caseStatus"));
				casedetail.setInvestigationType(rs.getString("investigationType"));
				casedetail.setZone(rs.getString("zone"));
				return casedetail;
			});

			HashMap<Integer, String> investigationList = natureOfInvestigationDaoImpl
					.getActiveNatureOfInvestigationMapping();
			for (CaseDetailList caseDetail : casedetailList)
				caseDetail.setNatureOfInvestigationCategory(
						investigationList.get(Integer.valueOf(caseDetail.getNatureOfInvestigationId())));
			return casedetailList;
		} catch (Exception ex) {
			ex.printStackTrace();
			CustomMethods.logError(ex);
			return null;
		}
	}

	public CaseDetails getCaseDetail(long caseID) {
		try {
			sql = "SELECT * FROM case_lists a where a.caseId = ?";
			List<CaseDetails> caseDetail = this.template.query(sql, new Object[] { caseID },
					(ResultSet rs, int rowCount) -> {
						CaseDetails detail = new CaseDetails();
						detail.setCaseId(rs.getLong("caseId"));
						detail.setPolicyNumber(rs.getString("policyNumber"));
						detail.setNatureOfInvestigationId(rs.getInt("nature_of_investigationId"));
						detail.setInsuredName(rs.getString("insuredName"));
						detail.setInsuredMob(rs.getString("insuredMob"));
						detail.setIssuedDate(rs.getString("issuedDate"));
						detail.setGender(rs.getString("gender"));
						detail.setInsuredDOD(rs.getString("insuredDOD"));
						detail.setInsuredDOB(rs.getString("insuredDOB"));
						detail.setDateOfDiagnosis(rs.getString("insuredDiagnosisDate"));
						detail.setSumAssured(rs.getInt("sumAssured"));
						detail.setInvestigationType(rs.getString("investigationType"));
						detail.setLocationId(rs.getInt("locationId"));
						detail.setPincode(rs.getString("pincode"));
						detail.setCaseStatus(rs.getString("caseStatus"));
						detail.setCaseSubStatus(rs.getString("caseSubStatus"));
						detail.setNotCleanCategory(rs.getString("notCleanCategory"));
						detail.setTriggerName(rs.getString("trigger_name"));
						detail.setTrigger_dept(rs.getString("trigger_dept"));
						detail.setDisposition(rs.getString("disposition_name"));
						detail.setNominee_name(rs.getString("nominee_name"));
						detail.setNomineeContactNumber(rs.getString("nominee_ContactNumber"));
						detail.setNominee_address(rs.getString("nominee_address"));
						detail.setInsured_address(rs.getString("insured_address"));
						detail.setCase_description(rs.getString("case_description"));
						detail.setLongitude(rs.getString("longitude"));
						detail.setLatitude(rs.getString("latitude"));
						detail.setCreatedDate(rs.getString("createdDate"));
						return detail;
					});

			// Assigner Details
			CaseMovement case_movement = case_movementDao.getCaseById(caseID);
			UserDetails user = userDao.getUserDetails(case_movement.getFromId());
			caseDetail.get(0).setAssignerName(user.getFull_name());
			caseDetail.get(0).setApprovedStatus(case_movement.getCaseStatus());
			caseDetail.get(0).setAssignerRemarks(case_movement.getRemarks());

			// Get Role Name
			caseDetail.get(0).setAssignerRole(userDao.getUserRole(user.getAccount_type()));

			return caseDetail.get(0);

		} catch (Exception e) {
			e.printStackTrace();
			CustomMethods.logError(e);
			return null;
		}
	}

	public CaseDetails getCaseDetailByCaseId(long caseID) {
		try {
			sql = "SELECT * FROM case_lists a where a.caseId = ?";
			List<CaseDetails> caseDetail = this.template.query(sql, new Object[] { caseID },
					(ResultSet rs, int rowCount) -> {
						CaseDetails detail = new CaseDetails();
						detail.setCaseId(rs.getLong("caseId"));
						detail.setPolicyNumber(rs.getString("policyNumber"));
						detail.setNatureOfInvestigationId(rs.getInt("nature_of_investigationId"));
						detail.setInsuredName(rs.getString("insuredName"));
						detail.setInsuredMob(rs.getString("insuredMob"));
						detail.setIssuedDate(rs.getString("issuedDate"));
						detail.setGender(rs.getString("gender"));
						detail.setInsuredDOD(rs.getString("insuredDOD"));
						detail.setInsuredDOB(rs.getString("insuredDOB"));
						detail.setDateOfDiagnosis(rs.getString("insuredDiagnosisDate"));
						detail.setSumAssured(rs.getInt("sumAssured"));
						detail.setInvestigationType(rs.getString("investigationType"));
						detail.setLocationId(rs.getInt("locationId"));
						detail.setPincode(rs.getString("pincode"));
						detail.setCaseStatus(rs.getString("caseStatus"));
						detail.setCaseSubStatus(rs.getString("caseSubStatus"));
						detail.setNotCleanCategory(rs.getString("notCleanCategory"));
						detail.setTriggerName(rs.getString("trigger_name"));
						detail.setTrigger_dept(rs.getString("trigger_dept"));
						detail.setDisposition(rs.getString("disposition_name"));
						detail.setNominee_name(rs.getString("nominee_name"));
						detail.setNomineeContactNumber(rs.getString("nominee_ContactNumber"));
						detail.setNominee_address(rs.getString("nominee_address"));
						detail.setInsured_address(rs.getString("insured_address"));
						detail.setCase_description(rs.getString("case_description"));
						detail.setLongitude(rs.getString("longitude"));
						detail.setLatitude(rs.getString("latitude"));
						detail.setCreatedDate(rs.getString("createdDate"));
						return detail;
					});
			return caseDetail.get(0);
		} catch (Exception e) {
			e.printStackTrace();
			CustomMethods.logError(e);
			return null;
		}
	}

	public String updateCaseTypeAndSubType(CaseDetails casedetail) {
		try {
			sql = "UPDATE case_lists SET notCleanCategory = ? ,caseStatus = ?, "
					+ "caseSubStatus = ?, updatedBy = ?, updatedDate = getDate() " + "where caseId = ?";
			template.update(sql, casedetail.getNotCleanCategory(), casedetail.getCaseStatus(),
					casedetail.getCaseSubStatus(), casedetail.getUpdatedBy(), casedetail.getCaseId());
		} catch (Exception e) {
			e.printStackTrace();
			CustomMethods.logError(e);
			return e.getMessage();
		}
		return "****";
	}

	public String bulkUpdateCaseTypeAndSubType(CaseDetails casedetail, String list) {
		try {
			sql = "INSERT INTO audit_case_list SELECT * FROM case_lists where caseId in(" + list + ")";
			template.update(sql);

			sql = "UPDATE case_lists SET notCleanCategory = ? ,caseStatus = ?, "
					+ "caseSubStatus = ?, updatedBy = ?, updatedDate = getDate() " + "where caseId in(" + list + ")";
			template.update(sql, casedetail.getNotCleanCategory(), casedetail.getCaseStatus(),
					casedetail.getCaseSubStatus(), casedetail.getUpdatedBy());
		} catch (Exception e) {
			e.printStackTrace();
			CustomMethods.logError(e);
			return e.getMessage();
		}
		return "****";
	}

	public String updateCaseDetails(CaseDetails casedetail) {
		try {
			sql = "INSERT INTO audit_case_list SELECT * FROM case_lists where caseId = ?";
			template.update(sql, casedetail.getCaseId());

			sql = "UPDATE case_lists SET nature_of_investigationId = ?," + "insuredName = ?," + "issuedDate = ?,"
					+ "insuredMob = ?," + "insuredDOD = ?," + "insuredDOB = ?," + "gender = ?,"
					+ "insuredDiagnosisDate = ?," + "sumAssured = ?," + "investigationType = ?," + "locationId = ?,"
					+ "pincode = ?," + "caseStatus = ?," + "caseSubStatus = ?," + "notCleanCategory = ?,"
					+ "trigger_name = ?," + "trigger_dept = ?," + "disposition_name = ?," + "nominee_Name = ?,"
					+ "nominee_ContactNumber = ?," + "nominee_address = ?," + "insured_address = ?,"
					+ "case_description = ?," + "longitude = ?," + "latitude = ?," + "updatedDate = getDate(),"
					+ "updatedBy = ? where caseId = ?";
			template.update(sql, casedetail.getNatureOfInvestigationId(), casedetail.getInsuredName(),
					casedetail.getIssuedDate(), casedetail.getInsuredMob(), casedetail.getInsuredDOD(),
					casedetail.getInsuredDOB(), casedetail.getGender(), casedetail.getDateOfDiagnosis(),
					casedetail.getSumAssured(), casedetail.getInvestigationType(), casedetail.getLocationId(),
					casedetail.getPincode(), casedetail.getCaseStatus(), casedetail.getCaseSubStatus(),
					casedetail.getNotCleanCategory(), casedetail.getTriggerName(), casedetail.getTrigger_dept(),
					casedetail.getDisposition(), casedetail.getNominee_name(), casedetail.getNomineeContactNumber(),
					casedetail.getNominee_address(), casedetail.getInsured_address(), casedetail.getCase_description(),
					casedetail.getLongitude(), casedetail.getLatitude(), casedetail.getUpdatedBy(),
					casedetail.getCaseId());
		} catch (Exception e) {
			e.printStackTrace();
			CustomMethods.logError(e);
			return e.getMessage();
		}
		return "****";
	}

	@Transactional
	public String readCaseXlsx(String filename, UserDetails fromUser, String user_role,String assigneeId) {
		try {
			Set<String> value = new TreeSet<String>();
			File error_file = new File(config.getUpload_directory() + "error_log.xlsx");
			if (error_file.exists())
				error_file.delete();
			File file = new File(config.getUpload_directory() + filename);
			// File not found error won't occur
			FileInputStream fis = new FileInputStream(file);
			XSSFWorkbook wb = new XSSFWorkbook(fis);
			XSSFSheet sheet = wb.getSheetAt(0);
			Iterator<Row> itr = sheet.iterator(); // iterating over excel file
			itr.hasNext();
			String error_message = sanityCheck(itr.next());			
			if (!error_message.equals("****")) {
				wb.close();
				return error_message;
			}
			CaseSubStatus status = caseDao.getCaseStatus(fromUser.getAccount_type(),user_role, "Approved");
			List<NatureOfInvestigation> investigationNature_list = natureOfInvestigationDaoImpl.getActiveNatureOfInvestigationList();
			List<String> investigation_list = investigationTypeDao.getActiveInvestigationTypeStringList();
			List<Location> location_list = locationDao.getActiveLocationList();
			List<String> trigger_list = triggerDao.getTriggerList();
			List<String> triggerDept_list = triggerDao.getTriggerDeptList();
			UserDetails userDetails = new UserDetails();
			String DONESTAUTS = "";
			String name = "";
			if(assigneeId != null)
				userDetails = userDao.getUserDetails(assigneeId);
			Map<CaseDetails, String> error_case = new HashMap<CaseDetails, String>();
			while (itr.hasNext()) {
				error_message = "";
				String intimationType = "";
				Row row = itr.next();
				System.out.println(row.getPhysicalNumberOfCells());
				if(row.getPhysicalNumberOfCells()>17) {
				System.out.println(row.getPhysicalNumberOfCells());
				//Iterator<Cell> cellIterator = row.cellIterator(); // iterating over each column
				CaseDetails caseDetails = new CaseDetails();
				Cell cell = row.getCell(0);
				
				//Policy Number
				caseDetails.setPolicyNumber(readCellStringValue(cell).toUpperCase().trim());		
				if(!caseDetails.getPolicyNumber().matches("[CU]{1}[0-9]{9}")) 
					error_message += "Invalid Policy Number, ";	
				if(caseDetails.getPolicyNumber().contains("=")) 
					error_message += "Policy Number cannot contain =, ";
				 
				//Nature of Investigation
			    cell = row.getCell(1);
				String investigationCategory = readCellStringValue(cell);
				caseDetails.setNatureOfInvestigationCategory(investigationCategory);
			
				for (NatureOfInvestigation investigation : investigationNature_list) 
				{
					if (investigation.getNature_of_investigationType().equals(investigationCategory)) 
					{
						caseDetails.setNatureOfInvestigationId(investigation.getNature_of_investigationId());
						break;
					}
				}
				
				if (caseDetails.getNatureOfInvestigationId() == 0) {
					error_message += "Invalid Nature Of Investigation, ";
				}
				else {
				if (assigneeId != null) 
				{
					if(!investigationCategory.equals("Document Pickup")) {
						error_message += "Nature Of Investigation Should Document Pickup, ";
					}
				}
				else {
					if(investigationCategory.equals("Document Pickup")) {
						error_message += "Nature Of Investigation Cannot Document Pickup, ";	
					}
				}
				}
				
				//Investigation Type {
				cell = row.getCell(2);
				caseDetails.setInvestigationType(readCellStringValue(cell).trim());
				if (!investigation_list.contains(caseDetails.getInvestigationType()))
					error_message += "Invalid Investigation Type,";					
				if (assigneeId != null) 
				{
					if(!caseDetails.getInvestigationType().equals("CDP"))
						error_message += "Investigation Type should be CDP, ";
					intimationType = caseDetails.getInvestigationType().trim().toUpperCase();
				}
				else
				{
					if(caseDetails.getInvestigationType().equals("CDP"))
						error_message += "Investigation Type cannot be CDP, ";
					intimationType = caseDetails.getInvestigationType().trim().toUpperCase();
				}
				//Issued Date
				cell = row.getCell(3);
				try 
				{
					caseDetails.setIssuedDate(readCellDateValue(cell));
					if(caseDetails.getIssuedDate().contains("=")) 
						error_message += "Issued Date cannot contain =, ";
				} 
				catch (Exception e) 
				{	
					error_message += "Issued Date is mandatory, ";
				}

				//Insured Name
				cell = row.getCell(4);
				caseDetails.setInsuredName(readCellStringValue(cell).trim());
				if (caseDetails.getInsuredName().equals("")) 
					error_message += "Insured Name is mandatory, ";
				if (caseDetails.getInsuredName().contains("=")) 
					error_message += "Insured Name cannot contain =, ";
					
				//Insured Contact Number
				cell = row.getCell(5);
				try 
				{
					long contact_number = readCellLongValue(cell);
					caseDetails.setInsuredMob(contact_number == 0 ? "" : String.valueOf(contact_number).trim());
					if (caseDetails.getInsuredMob().contains("=")) 
						error_message += "Insured Contact Number cannot contain =, ";	
					if(caseDetails.getInsuredMob().equals(""))
					{
						if (!intimationType.equals("CDP"))
							error_message += "Insured Contact Number is mandatory, ";
					}
				} 
				catch (Exception e) 
				{
					error_message += "Invalid Insured Contact number, ";
					CustomMethods.logError(e);
					e.printStackTrace();
				}
				//Insured DOD
				cell = row.getCell(6);
				if (intimationType.equals("CDP"))
					{
						try 
						{	
						caseDetails.setInsuredDOD(readCellDateValue(cell));
						caseDetails.setDateOfDiagnosis("");
						if (caseDetails.getInsuredDOD().contains("=")) 
							error_message += "Insured DOD cannot contain =, ";
						
						} 
						catch (Exception ex) 
						{error_message += "Insured DOD is mandatory, ";}		
					}
					else
					{
						try 
						{
						caseDetails.setInsuredDOD(readCellDateValue(cell));
						caseDetails.setDateOfDiagnosis("");
						if (caseDetails.getInsuredDOD().contains("=")) 
							error_message += "Insured DOD cannot contain =, ";
						}
						catch (Exception ex) 
						{caseDetails.setInsuredDOD("");}	
						
					}
				

				//Insured DOB
				cell = row.getCell(7);
				try 
				{
					caseDetails.setInsuredDOB(readCellDateValue(cell));
					if (caseDetails.getInsuredDOB().contains("=")) 
						error_message += "Insured DOB cannot contain =, ";
				} 
				catch (Exception e) 
				{	
					error_message += "Insured DOB is mandatory, ";
				}

				//gender
				cell = row.getCell(8);
				caseDetails.setGender(readCellStringValue(cell));
				if (!caseDetails.getGender().equals("")) {		
					if(!(caseDetails.getGender().trim().equals("M") || caseDetails.getGender().trim().equals("F") || caseDetails.getGender().equals("O")))
						error_message += "Invalid Gender, ";
				}		

				//Sum Assured                   
				cell = row.getCell(9);
				try 
				{
					if(readCellStringValue(cell).contains(("=")))
					error_message += "Sum Assured cannot contain =,";
							
                    double sumAssured = readCellStringValue(cell).equals("") ? 0 :readCellLongValue(cell);
					System.out.println("sumAssured"+sumAssured);
                    caseDetails.setSumAssured(sumAssured);
					
				} 
				catch (Exception e) 
				{
					error_message += "Invalid Sum Assured, ";
					caseDetails.setSumAssured(0);
				}
				//Claimant City
				cell = row.getCell(10);
				caseDetails.setClaimantCity(readCellStringValue(cell));
				if (caseDetails.getClaimantCity().equals(""))
					error_message += "City cannot be blank, ";
				if(caseDetails.getClaimantCity().contains(("=")))
					error_message += "City  cannot contain =,";
				else
				{
					for (Location list : location_list)
					{
						if (caseDetails.getClaimantCity().equalsIgnoreCase(list.getCity()))
						{
							caseDetails.setLocationId(list.getLocationId());
							caseDetails.setClaimantState(list.getState());
							caseDetails.setClaimantZone(list.getZone());
							break;
						}
					}
						
					if(fromUser.getAccount_type().equals("CLAMAN"))
					{
						if(!caseDetails.getClaimantCity().equalsIgnoreCase(userDetails.getCity()))
							error_message = "Agent city is not same as Claimant City, ";
					}
					
					if (caseDetails.getClaimantState().equals(""))
						error_message = "City not present in database, ";
				}					
				//Nominee Name		
				cell = row.getCell(11);
				caseDetails.setNominee_name(readCellStringValue(cell));
				if (caseDetails.getNominee_name().contains("=")) {
					error_message += "Nominee Name cannot contain =, ";
				}
				if (caseDetails.getNominee_name().equals("")) 
				{
					if (intimationType.equals("CDP")) {
						error_message += "Nominee Name is mandatory, ";
					}
				}
				//Nominee Contact Number
				cell = row.getCell(12);
				try 
				{
					long contact_number = readCellLongValue(cell);
					
					caseDetails.setNomineeContactNumber(contact_number == 0 ? "" : 
						String.valueOf(contact_number));
					if(caseDetails.getNomineeContactNumber().contains("="))
						error_message += "Nominee Contact Number cannot contain =, ";
					
					if(caseDetails.getNomineeContactNumber().equals(""))
					{
						if(intimationType.equals("CDP")) {
							error_message += "Nominee Contact Number is mandatory, ";}
					}
				} 
				catch (Exception e) 
				{
					error_message += "Invalid Nominee Contact number, ";
					CustomMethods.logError(e);
					e.printStackTrace();
				}
				//Nominee Address
				cell = row.getCell(13);
				caseDetails.setNominee_address(readCellStringValue(cell));
				if(caseDetails.getNominee_address().equals("")) 
				{
					if (intimationType.equalsIgnoreCase("CDP")) {
						error_message += "Nominee Address is mandatory, ";}
				}
				if(caseDetails.getNominee_address().contains("=")) {
					error_message += "Nominee Address cannot contain =, ";
				}
				//added by kk
				if(CustomMethods.isStringContainsSpecialCharacter(readCellStringValue(cell))) {
					error_message += "Nominee Address Remove Special charchters "+CustomMethods.sepcical_char+", ";
				}	
				//Nominee Pincode
				cell = row.getCell(14);
				if (readCellStringValue(cell).equals("")) {
					error_message += "Please provide Pincode  ,  ";
				}
				if (readCellStringValue(cell).contains("=")) 
				{
						error_message += "Pincode  cannot contain =,  ";
				}
				else 
				{
					try
					{
						if(!Pattern.matches("[0-9]{6}", String.valueOf(readCellLongValue(cell)).trim()))
							error_message += "Pincode should be of 6 digits, ";
						else
							caseDetails.setPincode(String.valueOf(readCellLongValue(cell)));
					}
					catch(Exception e)
					{
						error_message += "Invalid Pincode, ";
					}
				}
				//Insured Address
				cell = row.getCell(15);
				caseDetails.setInsured_address(readCellStringValue(cell).trim());
				if(caseDetails.getInsured_address().equals("")) {
				error_message += "Insured Address is mandatory, ";
				}
				//added by kk
				if(CustomMethods.isStringContainsSpecialCharacter(readCellStringValue(cell))) {
					error_message += "Insured address Remove Special charchters "+CustomMethods.sepcical_char+", ";
				}
				//Trigger Name
				cell = row.getCell(16);
				caseDetails.setTriggerName(readCellStringValue(cell).trim());
				if(!caseDetails.getTriggerName().equals(""))
				{
					if (!trigger_list.contains(caseDetails.getTriggerName())) 
						error_message += "Invalid Trigger name entered, ";	
				}
				//added by kk
				if(CustomMethods.isStringContainsSpecialCharacter(readCellStringValue(cell))) {
					error_message += "Trigger name Remove Special charchters "+CustomMethods.sepcical_char+", ";
				}
				//Trigger Department
				cell = row.getCell(17);
				caseDetails.setTrigger_dept(readCellStringValue(cell));
				if(!caseDetails.getTrigger_dept().equals("")&& !caseDetails.getInvestigationType().equals("CDP"))
				{
					if (!triggerDept_list.contains(caseDetails.getTrigger_dept()))
						error_message += "Invalid Trigger Department entered, ";		
				}	
				
				if(!caseDetails.getInvestigationType().equals("CDP"))
				{
					if(caseDetails.getTriggerName().equals(""))
						error_message += "Trigger name is mandatory, ";
					
					if(caseDetails.getTrigger_dept().equals(""))
						error_message += "Trigger Department is mandatory, ";	
				}
				//added by kk
				if(CustomMethods.isStringContainsSpecialCharacter(readCellStringValue(cell))) {
					error_message += "Trigger Department Remove Special charchters "+CustomMethods.sepcical_char+", ";
				}
				//Remarks
				cell = row.getCell(18);
				caseDetails.setAssignerRemarks(readCellStringValue(cell).trim());
				if(caseDetails.getNatureOfInvestigationCategory().contains("Re") && caseDetails.getAssignerRemarks().equals(""))
					error_message += "Re-Investigation remark is mandatory";
				if(caseDetails.getNatureOfInvestigationCategory().contains("="))
					error_message += "cannot contain =, ";
				//added by kk
				if(CustomMethods.isStringContainsSpecialCharacter(readCellStringValue(cell))) {
					error_message += "Re-Investigation remark Remove Special charchters "+CustomMethods.sepcical_char+", ";
				}
				if (checkPolicyNumberWIP(caseDetails)) {
					CaseHistory history = case_movementDao.getauditCaseMovement(caseDetails);
//					  if(history!=null)
					name = history.getCaseId()!= 0 ? "and assigned to "+history.getFromUserName()+"," : ".,";
					 
					error_message += "Case is already in WIP "+ name;
					
				}
						else if (checkPolicyNumberotherthanCDP(caseDetails)
							&&caseDetails.getNatureOfInvestigationId()==1
							&&!caseDetails.getInvestigationType().equalsIgnoreCase("CDP"))
						{
							 CaseHistory historydate =  case_movementDao.getauditCaseMovementdate(caseDetails); 
							  System.out.println(historydate.getCaseId());
							 DONESTAUTS =historydate.getCaseId()!=0 ?
							  ""+historydate.getCreatedDate()+" done on"+historydate.getUpdatedDate()
							  +" name of investigator was "+historydate.getFromUserName()
							  +" case need second investigation select the investigation type as Re-Investigation,"
							  :",";
							  error_message += DONESTAUTS;
						}
						else if (checkPolicyNumberCDP(caseDetails)
							&&caseDetails.getNatureOfInvestigationId()==1
							&&caseDetails.getInvestigationType().equalsIgnoreCase("CDP"))
						{
							 CaseHistory historydate =
									  case_movementDao.getauditCaseMovementdate(caseDetails); 
							  DONESTAUTS =historydate.getCaseId()!=0 ?
							  ""+historydate.getCreatedDate()+" done on"+historydate.getUpdatedDate()
							  +" name of investigator was "+historydate.getFromUserName()
							  +" case need second investigation select the investigation type as Re-Investigation,"
							  :",";	 
							  error_message += DONESTAUTS;
						}
				
				if (error_message.equals("")) 
				{
					caseDetails.setCaseStatus(status.getCase_status());
					caseDetails.setCaseSubStatus(status.getCaseSubStatus());
					value.add(caseDetails.getClaimantZone());
					long caseId = addcase(caseDetails);
						System.out.println(caseId);
						caseDetails.setCaseId(caseId);
						CaseMovement caseMovement = new CaseMovement();
						caseMovement.setCaseId(caseId);
						caseMovement.setFromId(fromUser.getUsername());
						caseMovement.setToRole(user_role);
						caseMovement.setRemarks(caseDetails.getAssignerRemarks());
						if (assigneeId != null)
							caseMovement.setToId(assigneeId);
						caseMovement.setZone(caseDetails.getClaimantZone());
						case_movementDao.CreatecaseMovement(caseMovement);
						userDao.activity_log("CASE HISTORY", caseDetails.getPolicyNumber(), "ADD CASE", 
								fromUser.getUsername());
						
						if (assigneeId != null) 
						{
						  UserDetails toUser = userDao.getUserDetails(assigneeId);
						  MailConfig mail = mailConfigDao.getActiveConfig();
						  mail.setSubject("New Case Assigned - Claims");
						  String message_body ="Dear <User>, \n Your are required to take action on new cases\n\n";
						  message_body = message_body.replace("<User>", toUser.getFull_name());
						  message_body += "Thanks & Regards,\n Claims";
						  mail.setMessageBody(message_body); 
						  mail.setReceipent(toUser.getUser_email());
						  if(toUser.getAccount_type().equals("AGNSUP")) 
						  {
							  String AppointmentPath = config.getTemplate_directory() + "Appointment Letter.docx";
							  String AuthorizationPath = config.getTemplate_directory() + "Authorization Letter.docx";
							  caseDetails.setCreatedDate(LocalDateTime.now().toString());
							  mailConfigDao.textReplaceForAppointment(AppointmentPath, caseDetails,toUser);
							  mailConfigDao.textReplaceForAuthorization(AuthorizationPath, caseDetails,toUser);
					
							  mail.setAppointmentPath(config.getUpload_directory() + caseId + "_Appointment Letter.docx");
							  mail.setAuthorizationPath(config.getUpload_directory() + caseId + "_Authorization Letter.docx");
							  mailConfigDao.sendMail(mail);
						  }	
						
					   } 
					
					
					
				}
				else 
				{
					error_message = error_message.trim();
					error_message = error_message.substring(0, error_message.length() - 1);
					error_case.put(caseDetails, error_message);
				}
			}
		}
			wb.close();
			if (assigneeId == null) 
			{
				for(String val :value) 
					getExcelMail(val);
			}
			
			// Error File
			//if (error_case.size() != 0)
			writeErrorCase(error_case, fromUser);
			return "****";
		}catch(Exception e)
	{
//		e.printStackTrace();
		CustomMethods.logError(e);
		return e.getMessage();
	}
	}

	public List<CaseDetails> getCaseList() {
		String query = "SELECT * FROM case_lists";
		return template.query(query, (ResultSet rs, int rowNum) -> {
			CaseDetails detail = new CaseDetails();
			detail.setCaseId(rs.getLong("caseId"));
			detail.setPolicyNumber(rs.getString("policyNumber"));
			detail.setNatureOfInvestigationId(rs.getInt("nature_of_investigationId"));
			detail.setInsuredName(rs.getString("insuredName"));
			detail.setInsuredDOD(rs.getString("insuredDOD"));
			detail.setInsuredDOB(rs.getString("insuredDOB"));
			detail.setDateOfDiagnosis(rs.getString("insuredDiagnosisDate"));
			detail.setSumAssured(rs.getInt("sumAssured"));
			detail.setInvestigationType(rs.getString("investigationType"));
			detail.setLocationId(rs.getInt("locationId"));
			detail.setPincode(rs.getString("pincode"));
			detail.setCaseStatus(rs.getString("caseStatus"));
			detail.setCaseSubStatus(rs.getString("caseSubStatus"));
			detail.setNotCleanCategory(rs.getString("notCleanCategory"));
			detail.setTriggerName(rs.getString("trigger_name"));
			detail.setTrigger_dept(rs.getString("trigger_dept"));
			detail.setDisposition(rs.getString("disposition_name"));
			detail.setNominee_name(rs.getString("nominee_name"));
			detail.setNomineeContactNumber(rs.getString("nominee_ContactNumber"));
			detail.setNominee_address(rs.getString("nominee_address"));
			detail.setInsured_address(rs.getString("insured_address"));
			detail.setCase_description(rs.getString("case_description"));
			detail.setLongitude(rs.getString("longitude"));
			detail.setLatitude(rs.getString("latitude"));
			detail.setCreatedDate(rs.getString("createdDate"));
			return detail;
		});
	}

	public void getExcelMail(String zone) {
		try {
			MailConfig mail = mailConfigDao.getActiveConfig();
			if (mail != null) {
				List<UserDetails> toUser = userDao.getUserRoleList(zone);
				for (UserDetails toMailId : toUser) {
					mail.setSubject("New Cases Assigned From Bulk-upload - Claims");
					String message_body = "Dear <User>, \n Your are required to take action on new cases\n\n";
					message_body = message_body.replace("<User>", toMailId.getFull_name());
					message_body += "Thanks & Regards,\n Claims";
					mail.setMessageBody(message_body);
					mail.setReceipent(toMailId.getUser_email());
//					mailConfigDao.sendMail(mail);
				}
			}
		} catch (Exception e) {
			CustomMethods.logError(e);
		}
	}

	public String readCellStringValue(Cell cell) {
		if (cell == null)
			return "";
		switch (cell.getCellType()) {
		case STRING:
			return cell.getStringCellValue().trim();
		case NUMERIC: // field that represents number cell type
			return String.valueOf(cell.getNumericCellValue()).trim();
		default:
			return "";
		}
	}

	public String readCellDateValue(Cell cell) {
		if (cell == null)
			return "";
		Date date = Date.valueOf(cell.getDateCellValue().toInstant().atZone(ZoneId.systemDefault()).toLocalDate());
		return date.toString();
	}

	public long readCellLongValue(Cell cell) {
		if (cell == null)
			return 0;
		switch (cell.getCellType()) {
		case STRING:
			return Integer.parseInt(cell.getStringCellValue());
		case NUMERIC: // field that represents number cell type
			return (long) cell.getNumericCellValue();
		default:
			return 0;
		}
	}

	public String sanityCheck(Row row) {
		Iterator<Cell> cellIterator = row.cellIterator(); // iterating over each column
		Cell cell;
		List<String> headerList = CustomMethods.importCaseHeader();
		while (cellIterator.hasNext()) {
			cell = cellIterator.next();
			if (!headerList.contains(readCellStringValue(cell).trim()))
				return "Invalid File Format";
		}
		return "****";
	}

	public String deleteCase(int caseId) {
		try

		{
			sql = "DELETE FROM case_lists where caseId = ?";
			this.template.update(sql, caseId);

			sql = "DELETE FROM case_movement where caseId = ?";
			this.template.update(sql, caseId);

			sql = "DELETE FROM audit_case_movement where caseId = ?";
			this.template.update(sql, caseId);
		} catch (Exception e) {
			e.printStackTrace();
			CustomMethods.logError(e);
			return e.getMessage();
		}

		return "****";
	}

	private void writeErrorCase(Map<CaseDetails, String> error_case, UserDetails fromUser) {
		// File error_file = new File(config.getUpload_directory() + "error_log.xlsx");
		try {
			XSSFWorkbook error_wb = new XSSFWorkbook();
			XSSFSheet error_sheet = error_wb.createSheet("Error Log");
			int rowNum = 0;
			Row newRow = error_sheet.createRow(rowNum);
			List<String> headerList;
			if (fromUser.getAccount_type().equals(config.getCLAIMS()))
				headerList = CustomMethods.importCDPCaseHeader();
			else
				headerList = CustomMethods.importCaseHeader();
			int colNum = 0;

			for (String header : headerList) {
				Cell cell = newRow.createCell(colNum);
				cell.setCellValue(header);
				colNum++;
			}
			Cell cell = newRow.createCell(colNum);
			colNum++;
			cell.setCellValue("Error Description");
			rowNum++;
			newRow = error_sheet.createRow(rowNum);
			for (Map.Entry<CaseDetails, String> entry : error_case.entrySet()) {
				colNum = 0;
				cell = newRow.createCell(colNum);
				cell.setCellValue(entry.getKey().getPolicyNumber());
				colNum++;
				cell = newRow.createCell(colNum);
				cell.setCellValue(entry.getKey().getNatureOfInvestigationCategory());
				colNum++;
				cell = newRow.createCell(colNum);
				cell.setCellValue(entry.getKey().getInvestigationType());
				colNum++;
				cell = newRow.createCell(colNum);
				cell.setCellValue(entry.getKey().getIssuedDate());
				colNum++;
				cell = newRow.createCell(colNum);
				cell.setCellValue(entry.getKey().getInsuredName());
				colNum++;
				cell = newRow.createCell(colNum);
				cell.setCellValue(entry.getKey().getInsuredMob());
				colNum++;
				cell = newRow.createCell(colNum);
				if (!entry.getKey().getInsuredDOD().equals(""))
					cell.setCellValue(entry.getKey().getInsuredDOD());
				else
					cell.setCellValue(entry.getKey().getDateOfDiagnosis());
				colNum++;
				cell = newRow.createCell(colNum);
				cell.setCellValue(entry.getKey().getInsuredDOB());
				colNum++;
				cell = newRow.createCell(colNum);
				cell.setCellValue(entry.getKey().getGender());
				colNum++;
				cell = newRow.createCell(colNum);
				cell.setCellValue(entry.getKey().getSumAssured());
				colNum++;
				cell = newRow.createCell(colNum);
				cell.setCellValue(entry.getKey().getClaimantCity());
				colNum++;
				cell = newRow.createCell(colNum);
				cell.setCellValue(entry.getKey().getNominee_name());
				colNum++;
				cell = newRow.createCell(colNum);
				cell.setCellValue(entry.getKey().getNomineeContactNumber());
				colNum++;
				cell = newRow.createCell(colNum);
				cell.setCellValue(entry.getKey().getNominee_address());
				colNum++;
				cell = newRow.createCell(colNum);
				cell.setCellValue(entry.getKey().getPincode());
				colNum++;
				cell = newRow.createCell(colNum);
				cell.setCellValue(entry.getKey().getInsured_address());
				if (headerList.contains("Trigger Name")) {
					colNum++;
					cell = newRow.createCell(colNum);
					cell.setCellValue(entry.getKey().getTriggerName());
					colNum++;
					cell = newRow.createCell(colNum);
					cell.setCellValue(entry.getKey().getTrigger_dept());
				}
				// Case Remarks
				colNum++;
				cell = newRow.createCell(colNum);
				cell.setCellValue(entry.getKey().getAssignerRemarks());
				// Error Description
				colNum++;
				cell = newRow.createCell(colNum);
				cell.setCellValue(entry.getValue());
				rowNum++;
				newRow = error_sheet.createRow(rowNum);
			}
			FileOutputStream outputStream = new FileOutputStream(config.getUpload_directory() + "error_log.xlsx");
			error_wb.write(outputStream);
			error_wb.close();
		} catch (Exception e) {
			e.printStackTrace();
			CustomMethods.logError(e);
		}

		return;
	}

	public List<CaseDetails> getLiveCaseList(String username) {
		try {
			sql = "SELECT * FROM case_lists a where caseStatus <> 'Closed' and "
					+ "longitude <> '' and latitude <> '' and caseId in "
					+ "(select caseId from audit_case_movement where toId = ?)";
			List<CaseDetails> caseDetail = this.template.query(sql, new Object[] { username },
					(ResultSet rs, int rowCount) -> {
						CaseDetails detail = new CaseDetails();
						detail.setCaseId(rs.getLong("caseId"));
						detail.setPolicyNumber(rs.getString("policyNumber"));
						detail.setLongitude(rs.getString("longitude"));
						detail.setLatitude(rs.getString("latitude"));
						return detail;
					});

			return caseDetail;

		} catch (Exception e) {
			e.printStackTrace();
			CustomMethods.logError(e);
			return null;
		}
	}

	public User_locations getLiveUserList(String username) {
		try {
			String sql = "SELECT user_locations.*,admin_user.full_name as fullname "
					+ "FROM user_locations with (nolock) INNER JOIN admin_user "
					+ "ON user_locations.userName = admin_user.username "
					+ "where longitude <> '' and latitude <> '' and user_locations.userName = ?";
			List<User_locations> userDetail = this.template.query(sql, new Object[] { username },
					(ResultSet rs, int rowCount) -> {
						User_locations detail = new User_locations();
						detail.setUsername(rs.getString("userName"));
						detail.setLongitude(rs.getString("longitude"));
						detail.setLatitude(rs.getString("latitude"));
						detail.setFullname(rs.getString("fullname"));
						return detail;
					});

			if (userDetail.size() > 0)
				return userDetail.get(0);

		} catch (Exception e) {
			e.printStackTrace();
			CustomMethods.logError(e);
			return null;
		}

		return null;
	}

	public CaseSubStatus getCaseStatus(String fromRole, String user_role, String user_action) {
		try {
			CaseSubStatus detail = new CaseSubStatus();
			sql = "SELECT * FROM case_substatus where fromRole =? and toRole = ? and user_action = ? ";
			template.query(sql, new Object[] { fromRole, user_role, user_action }, (ResultSet rs, int rowCount) -> {
				detail.setId(rs.getLong("id"));
				detail.setFromRole(rs.getString("fromRole"));
				detail.setToRole(rs.getString("toRole"));
				detail.setCase_status(rs.getString("Case_status"));
				detail.setCaseSubStatus(rs.getString("caseSubStatus"));
				detail.setUser_action(rs.getString("user_action"));
				return detail;
			});
			return detail;
		} catch (Exception e) {
			e.printStackTrace();
			CustomMethods.logError(e);
			return null;
		}
	}

	public boolean checkPolicyNumber(CaseDetails case_detail) {
		sql = "SELECT count(*) FROM case_lists " + "where policyNumber = '" + case_detail.getPolicyNumber() + "'"
				+ " and caseStatus <> 'Closed' and " + "investigationType = '" + case_detail.getInvestigationType()
				+ "'";

		if (template.queryForObject(sql, Integer.class) == 0)
			return false;

		return true;
	}
	
	public boolean checkPolicyNumberWIP(CaseDetails case_detail) {
		
		sql = "SELECT count(*) FROM case_lists " + "where policyNumber = '" + case_detail.getPolicyNumber() + "'"
				+ " and caseStatus <> 'Closed'";

		if (template.queryForObject(sql, Integer.class) == 0)
			return false;

		return true;
	}
	
	public boolean checkPolicyNumberotherthanCDP(CaseDetails case_detail) {
		
		sql = "SELECT count(*) FROM case_lists " + "where policyNumber = '" + case_detail.getPolicyNumber() + "'"
				+ " and caseStatus = 'Closed' and investigationType <> 'CDP'";

		if (template.queryForObject(sql, Integer.class) == 0)
			return false;

		return true;
	}
	
	public boolean checkPolicyNumberCDP(CaseDetails case_detail) {
		
		sql = "SELECT count(*) FROM case_lists " + "where policyNumber = '" + case_detail.getPolicyNumber() + "'"
				+ " and caseStatus = 'Closed' and investigationType = 'CDP'";

		if (template.queryForObject(sql, Integer.class) == 0)
			return false;

		return true;
	}

	public String updateCandidateDoc(long caseId, String filename, String type, String createdBy) {
		try {
			sql = "insert into case_docs (doc_type,doc_name,caseId,created_by,created_on) values( ?, ?, ?, ?, getDate())";
			template.update(sql, new Object[] { type, filename, caseId, createdBy });
			return "****";
		} catch (Exception e) {
			e.printStackTrace();
			CustomMethods.logError(e);
			return e.getMessage();
		}

	}
public void deletepiv(CaseDetails case_detail,UserDetails to ,UserDetails from) {
		
		
//		sql="select count(*) from audit_case_movement where caseId ='" + case_detail.getCaseId()+"'"
//				+ "and fromId in(select username from admin_user where role_name ='REGMAN' and username ='" + from.getUsername()+ "')\n" + 
//				"and toId in(select username from admin_user where role_name ='AGNSUP' and username='" + to.getUsername()+ "') ";
	if(from.getAccount_type().equals("REGMAN")) {
		sql= "select count(*) from audit_case_movement where caseId ='" + case_detail.getCaseId()+"'"
				+ " and fromId='" + from.getUsername()+ "' and toId ='" + to.getUsername()+ "'and updatedDate =( \n" + 
		"select max(updatedDate) from audit_case_movement where caseId ='" + case_detail.getCaseId()+"' and \n" + 
		" fromId in(select username from admin_user where role_name ='REGMAN' )\n" + 
		"and toId  in(select username from admin_user where role_name ='AGNSUP' )) ";
	}
	if(from.getAccount_type().equals("AGNSUP")) {
		sql= "select count(*) from audit_case_movement where caseId ='" + case_detail.getCaseId()+"'"
				+ " and fromId='" + from.getUsername()+ "' and toId ='" + to.getUsername()+ "'and updatedDate =( \n" + 
		"select max(updatedDate) from audit_case_movement where caseId ='" + case_detail.getCaseId()+"' and \n" + 
		" fromId in(select username from admin_user where role_name ='AGNSUP' )\n" + 
		"and toId  in(select username from admin_user where role_name ='INV' )) ";
	}
		if (template.queryForObject(sql, Integer.class) == 0) {
			System.out.println("enter");
			String sql = "delete from case_pivform where caseId = ?";
		this.template.update(sql,case_detail.getCaseId());
		
		}
		
	}

}
