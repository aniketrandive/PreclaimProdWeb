package com.preclaim.dao;

import java.sql.ResultSet;
import java.util.HashMap;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.preclaim.config.CustomMethods;
import com.preclaim.models.NatureOfInvestigation;
import com.preclaim.models.NatureOfInvestigationList;

@Component
public class NatureOfInvestigationDao {

	@Autowired
	DataSource datasource;

	@Autowired
	JdbcTemplate template;

	public void setTemplate(JdbcTemplate template) {
		this.template = template;
	}

	String sql = "";
	
	public String addNatureOfInvestigation(NatureOfInvestigation NatureOfInvestigation) {
		try 
		{
			sql = "SELECT COUNT(*) FROM  nature_of_investigation where nature_of_investigationType"
				+ " = '" + NatureOfInvestigation.getNature_of_investigationType()+ "'";
			int count = this.template.queryForObject(sql,Integer.class);
			if(count > 0)
				return "Nature of Investigation already exists";
			
			sql = "INSERT INTO nature_of_investigation(nature_of_investigationType, createdBy, createdDate,"
					+ " status) values(?, ?, getdate(), ?)";
			this.template.update(sql,NatureOfInvestigation.getNature_of_investigationType(), 
					NatureOfInvestigation.getCreatedBy(), 0);
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
			CustomMethods.logError(e);
			return e.getMessage();
		}

		return "****";
	}


	public List<NatureOfInvestigationList> getNatureOfInvestigationList(int status) {
		String query = "";
		if (status == 0)
			query = "SELECT * FROM nature_of_investigation WHERE status = " + status;
		else
			query = "select * from nature_of_investigation where status = 1 or status = 2";
		return template.query(query, (ResultSet rs, int rowNum) -> {
			NatureOfInvestigationList NatureOfInvestigationList = new NatureOfInvestigationList();
			NatureOfInvestigationList.setSrNo(rowNum + 1);
			NatureOfInvestigationList.setNature_of_investigationId(rs.getInt("nature_of_investigationId"));
			NatureOfInvestigationList.setNature_of_investigationType(rs.getString("nature_of_investigationType"));
			NatureOfInvestigationList.setStatus(rs.getInt("status"));
			return NatureOfInvestigationList;
		});
	}
	
	
	public List<NatureOfInvestigation> getActiveNatureOfInvestigationList() {
		String query = "SELECT * FROM nature_of_investigation WHERE status = 1";
		return template.query(query, (ResultSet rs, int rowNum) -> {
			NatureOfInvestigation NatureOfInvestigationList = new NatureOfInvestigation();
			NatureOfInvestigationList.setNature_of_investigationId(rs.getInt("nature_of_investigationId"));
			NatureOfInvestigationList.setNature_of_investigationType(rs.getString("nature_of_investigationType"));
			return NatureOfInvestigationList;
		});
	}

	public String updateNatureOfInvestigationStatus(int nature_of_investigationId, int status) 
	{
		try 
		{
			sql = "INSERT INTO audit_nature_of_investigation select * from nature_of_investigation"
					+ " where nature_of_investigationId = ?";
			this.template.update(sql, nature_of_investigationId);
			sql = "UPDATE nature_of_investigation SET status = ? where nature_of_investigationId = ?";
			this.template.update(sql, status, nature_of_investigationId);
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
			CustomMethods.logError(e);
			return e.getMessage();
	    }
		return "****";
	}

	
	public String deleteNatureOfInvestigation(int nature_of_investigationId) {
		try 
		{
			sql = "INSERT INTO audit_nature_of_investigation select * from nature_of_investigation"
					+ " where nature_of_investigationId = ?";
			this.template.update(sql, nature_of_investigationId);
			
			sql = "DELETE FROM nature_of_investigation WHERE nature_of_investigationId = ?";
			this.template.update(sql, nature_of_investigationId);
		}
		catch(Exception e) 
		{
			e.printStackTrace();
			CustomMethods.logError(e);
			return e.getMessage();	
		}
		return "****";	
	}
	
	
	public String updateNatureOfInvestigation(String nature_of_investigationType, int nature_of_investigationId) 
	{
		try
		{
			sql = "INSERT INTO audit_nature_of_investigation select * from nature_of_investigation"
					+ " where nature_of_investigationId = ?";
			this.template.update(sql, nature_of_investigationId);
			
			sql = "SELECT COUNT(*) FROM  nature_of_investigation where nature_of_investigationType"
					+ " = '" + nature_of_investigationType+ "' AND nature_of_investigationId <> '" + nature_of_investigationId + "'";
			int count = this.template.queryForObject(sql,Integer.class);
			if(count > 0)
				return "Nature of Investigation already exists";
			sql = "UPDATE nature_of_investigation SET nature_of_investigationType = ? where nature_of_investigationId = ?";
			template.update(sql, nature_of_investigationType, nature_of_investigationId);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			CustomMethods.logError(e);
			return e.getMessage();
		}
		return "****";
	}

	
	public List<String> getActiveNature_of_investigationStringList() {
		String query = "SELECT * FROM nature_of_investigationType WHERE status = 1";
		return template.query(query, (ResultSet rs, int rowNum) -> {
			return rs.getString("nature_of_investigationType");
		});
	}
	
	
	public HashMap<Integer,String> getActiveNatureOfInvestigationMapping() {
		String query = "SELECT * FROM nature_of_investigation WHERE status = 1";
		return template.query(query, (ResultSet rs, int rowNum) -> {
			HashMap<Integer,String> mapping = new HashMap<Integer,String>();
			mapping.put(rs.getInt("nature_of_investigationId"), rs.getString("nature_of_investigationType"));
			while(rs.next())
				mapping.put(rs.getInt("nature_of_investigationId"), rs.getString("nature_of_investigationType"));
			return mapping;
		}).get(0);
	}

	
	public String getNature_of_investigationById(int nature_of_investigationId) {
		String sql = "SELECT nature_of_investigation from nature_of_investigationType where nature_of_investigationId = " 
					+ nature_of_investigationId;
		return template.queryForObject(sql, String.class);
	}
}
