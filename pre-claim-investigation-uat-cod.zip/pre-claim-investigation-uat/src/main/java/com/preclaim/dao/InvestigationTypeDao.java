package com.preclaim.dao;

import java.sql.ResultSet;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.preclaim.config.CustomMethods;
import com.preclaim.models.InvestigationType;
import com.preclaim.models.InvestigationTypeList;

@Component
public class InvestigationTypeDao{

	@Autowired
	DataSource datasource;

	@Autowired
	private JdbcTemplate template;

	public void setTemplate(JdbcTemplate template) {
		this.template = template;
	}

	String sql = "";

	public String add_investigationType(InvestigationType investigationType) {
		try 
		{
			String InvestigationTypeCheck = "select count(*) from investigation_type where investigationName='" 
					+ investigationType.getInvestigationName() + "'";
			int investigationTypeCount = this.template.queryForObject(InvestigationTypeCheck, Integer.class);
			/* System.out.println(intimationType.toString()); */
			if (investigationTypeCount == 0) 
			{
				String sql = "INSERT INTO investigation_type(investigationName, createdBy, createdDate, status) values(?, ? , getdate(), ?)";
				template.update(sql, investigationType.getInvestigationName(), investigationType.getCreatedBy(),
						        investigationType.getStatus());
			}
			else
				return "Investigation Type already exists";
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			return e.getMessage();
		}
		return "****";
	}

	
	public List<InvestigationTypeList> investigationType_list(int status) {		
		if(status == 0) 
			sql = "SELECT * FROM investigation_type WHERE status = " + status;
		else 
			sql = "SELECT * FROM investigation_type WHERE status = 1 or status = 2";
		return this.template.query(sql, (ResultSet rs, int rowNum) -> {
			InvestigationTypeList investigationTypeList = new InvestigationTypeList();
			investigationTypeList.setInvestigationId(rs.getInt("investigationId"));
			investigationTypeList.setSrNo(rowNum + 1);
			investigationTypeList.setInvestigationName(rs.getString("investigationName"));
			investigationTypeList.setCreatedDate(rs.getString("createdDate"));
			investigationTypeList.setStatus(rs.getInt("status"));
			return investigationTypeList;
		});
	}

	
	public String deleteInvestigationType(int investigationId) {
		try 
		{
			sql = "INSERT INTO audit_investigation_type select * from investigation_type where investigationId = ?";
			template.update(sql,investigationId); 
			
			sql = "DELETE FROM investigation_type WHERE investigationId = ?";
			template.update(sql, investigationId);

		} 
		catch (Exception e) 
		{
			e.printStackTrace();
			CustomMethods.logError(e);
			return e.getMessage();
		}
		return "****";
	}

	
	public String updateInvestigationType(int investigationId, String investigationType) {
		try {
			String InvestigationTypeCheck = "select count(*) from investigation_type where investigationName='" + investigationType + "'";
			int InvestigationTypeCount = this.template.queryForObject(InvestigationTypeCheck, Integer.class);
			if(InvestigationTypeCount > 0)
				return "Investigation Type already exists";
			
			sql = "INSERT INTO audit_investigation_type select * from investigation_type where investigationId = ?";
            template.update(sql,investigationId);
		    
            sql = "UPDATE investigation_type SET investigationName = ? WHERE investigationId = ?";
			template.update(sql, investigationType,investigationId);
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
			CustomMethods.logError(e);
			return e.getMessage();
		}
		return "****";
	}


	public String updateInvestigationTypeStatus(int investigationId, int status) {
		try 
		{ 
			sql = "INSERT INTO audit_investigation_type select * from investigation_type where investigationId = ?";
            template.update(sql, investigationId);
		    
		    sql = "UPDATE investigation_type SET status = ? WHERE investigationId = ?";       
			template.update(sql, status, investigationId);	
           return  "****";
		}
		catch(Exception e)
		{
			e.printStackTrace();
			CustomMethods.logError(e);
			return e.getMessage();
		}
	}
		
	
	public List<InvestigationType> getActiveInvestigationType()
	{
		sql = "SELECT * FROM investigation_type where status = 1";
		return template.query(sql,
				(ResultSet rs, int rowNum) ->
				{
				
					InvestigationType investigationType = new InvestigationType();
					investigationType.setInvestigationId(rs.getInt("investigationId"));
					investigationType.setInvestigationName(rs.getString("investigationName"));
					return investigationType;
				}
				);
	}


	public List<String> getActiveInvestigationTypeStringList() {
	    sql = "SELECT * FROM investigation_type where status = 1";
		return template.query(sql, (ResultSet rs, int rowNum) ->
				{return rs.getString("investigationName");});
	}
	

}
