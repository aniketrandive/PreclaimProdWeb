package com.preclaim.models;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class MessageList {

	private int srNo = 0;
	private long msgID = 0;
	private String msgTitleEng = "";
	private String msgTitleHin = "";
	private int regionId = 0;
	private String regionName = "";
	private int groupId = 0;
	private String groupName = "";
	private int categoryId = 0;
	private String categoryName = "";
	private int channelId = 0;
	private String channelName = "";
	private String createdDate = "";
	private String expiryDate = "";
	private int status = 0;
}
