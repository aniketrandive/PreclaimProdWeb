package com.preclaim.models;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class InvestigationTypeList {

	private int srNo = 0;
	private String investigationName = "";
	private String createdDate = "";
	private String createdBy = "";
	private int status = 0;
	private int investigationId = 0;
}
