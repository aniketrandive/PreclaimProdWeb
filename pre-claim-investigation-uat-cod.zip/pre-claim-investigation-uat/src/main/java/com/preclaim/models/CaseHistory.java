package com.preclaim.models;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class CaseHistory {

	private long caseId = 0;
	private String fromId  = "";
	private String fromUserName = "";
	private String role = "";
	private String toId = "";
	private String caseStatus = "";
	private String remarks = "";
	private String createdDate = "";
	private String updatedDate = "";
}
