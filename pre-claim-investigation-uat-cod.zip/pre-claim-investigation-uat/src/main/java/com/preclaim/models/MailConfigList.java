package com.preclaim.models;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class MailConfigList {

	private int mailConfigId  = 0;
	private String username = "";
	private String password = "";
	private String outgoingServer = "";
	private int outgoingPort = 0;
	private String encryptionType = "";
	private int status = 0;
	private String createdBy = "";
	private String updatedBy = "";		
}
