package com.preclaim.models;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@ToString
public class VendorwiseList {
	
	private String month = "";
	private int clean = 0;
	private int notClean = 0;
	private int cleanRate = 0;
	private int notCleanRate = 0;
	private int total = 0;
	
	public VendorwiseList(String month, int clean, int notClean)
	{
		this.month = month;
		this.clean = clean;
		this.notClean = notClean;
		total = clean + notClean;
		cleanRate = clean*100/total;
		notCleanRate = notClean*100/total;
	}
	

}
