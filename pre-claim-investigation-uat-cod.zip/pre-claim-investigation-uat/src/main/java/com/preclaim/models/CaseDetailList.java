package com.preclaim.models;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class CaseDetailList {

	private int srNo = 0;
	private long caseId = 0;
	private String policyNumber = "";
	private String insuredName = "";
	private int natureOfInvestigationId = 0;
	private String natureOfInvestigationCategory = "";
	private String investigationType = "";
	private double sumAssured = 0;
	private int assigneeId  = 0;
	private String assigneeName = "";
	private String caseStatus = "";
	private String caseSubStatus = "";
	private String notCleanCategory = "";
	private String paymentApproved = "";
	private String zone = "";
	private String createdDate = "";	
	private String updatedDate = "";
}
