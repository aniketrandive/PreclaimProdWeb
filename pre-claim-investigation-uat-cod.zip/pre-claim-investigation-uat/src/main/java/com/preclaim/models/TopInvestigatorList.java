package com.preclaim.models;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class TopInvestigatorList {
	
	private String investigator = "";
	private int clean = 0;
	private int notClean = 0;
	private int total = 0;
	private float notCleanRate = 0;
	
	public TopInvestigatorList(String investigator, int clean, int notClean) {
		super();
		this.investigator = investigator;
		this.clean = clean;
		this.notClean = notClean;
		this.total = clean + notClean;
		this.notCleanRate = notClean*100/total;
	}
}
