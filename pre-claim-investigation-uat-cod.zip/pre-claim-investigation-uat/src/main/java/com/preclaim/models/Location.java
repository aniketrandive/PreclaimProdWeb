package com.preclaim.models;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class Location {

	private int locationId = 0;
	private String city = "";
	private String state = "";
	private String zone = "";
	private String createdBy = "";
	private int status = 0;
	}
