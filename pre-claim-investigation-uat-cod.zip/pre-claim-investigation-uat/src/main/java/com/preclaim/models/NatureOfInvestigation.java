package com.preclaim.models;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class NatureOfInvestigation {
	private int nature_of_investigationId = 0;
	private String nature_of_investigationType = "";
	private String createdBy = "";
	private String updatedBy = "";
	private int status = 0;

	public NatureOfInvestigation(int nature_of_investigationId, String nature_of_investigationType) {
		
		this.nature_of_investigationId = nature_of_investigationId;
		this.nature_of_investigationType = nature_of_investigationType;
		createdBy = "";
		updatedBy = "";
		status = 0;
	}
}
