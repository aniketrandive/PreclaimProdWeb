package com.preclaim.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.preclaim.entity.BulkSchedulerData;
import com.preclaim.entity.Case_lists;

@Repository
public interface BulkSchedulerDataRepositry extends JpaRepository<BulkSchedulerData, Long> {
	
	
	@Query(value = "select top 10 * from Bulk_Scheduler_Data where flag = 0 and Responce =''", nativeQuery = true)
	List<BulkSchedulerData> getDocCreationData();
	
	@Query(value = "select top 10 * from Bulk_Scheduler_Data where flag = 2 and Responce like '%assigned%'", nativeQuery = true)
	List<BulkSchedulerData> getMailSendData();
	
	@Query(value = "select top 10 * from Bulk_Scheduler_Data where flag = 1 and Responce  like '%Docsucses%' or Responce like '%Docpass%'", nativeQuery = true)
	List<BulkSchedulerData> getBulkCaseAssign();


}
