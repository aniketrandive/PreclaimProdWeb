package com.preclaim.config;

import java.io.UnsupportedEncodingException;

import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

import org.apache.commons.codec.binary.Base64;
import org.apache.http.entity.StringEntity;
public class test {
	
	
	
	
	private static final String AES_KEY = "tata123456789123";
	private static final String AES_INIT_VECTOR = "RandomInitVector";

	public static String decrypt(String encrypted) {

		try {
			IvParameterSpec iv = new IvParameterSpec(AES_INIT_VECTOR.getBytes("UTF-8"));
			SecretKeySpec skeySpec = new SecretKeySpec(AES_KEY.getBytes("UTF-8"), "AES");

			Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5PADDING");
			cipher.init(Cipher.DECRYPT_MODE, skeySpec, iv);

		
			byte[] original = cipher.doFinal(Base64.decodeBase64(encrypted));
			return new String(original);
		}catch (Exception ex) {
			
			ex.printStackTrace();
		}

		return null;
	}

	public static String encrypt(String value) {
	
		try {
			IvParameterSpec iv = new IvParameterSpec(AES_INIT_VECTOR.getBytes("UTF-8"));
			SecretKeySpec skeySpec = new SecretKeySpec(AES_KEY.getBytes("UTF-8"), "AES");

			Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5PADDING");
			cipher.init(Cipher.ENCRYPT_MODE, skeySpec, iv);

			byte[] encrypted = cipher.doFinal(value.getBytes());
			System.out.println("encrypted string: "
					+ Base64.encodeBase64String(encrypted));

			return Base64.encodeBase64String(encrypted);
		} catch (Exception ex) {
		
			ex.printStackTrace();
		}
		return null;
	}

	public static void main(String[] args) throws UnsupportedEncodingException {
		// TODO Auto-generated method stub
		
		/*
		 * String encodedPassword =
		 * Base64.getEncoder().encodeToString("password".getBytes());
		 * System.out.println(encodedPassword);
		 */
		StringEntity input = new StringEntity("{\"appId\":\"GCUBE\",\"userId\":\"osaah02\",\"password\":\"zZC3lKhgGFJ1OvCry6R1sg==\"}");
//		System.out.println(input.g);
//		System.out.println(decrypt("e7lDR2FxB2XKVElE5kAoSA=="));
//		System.out.println(encrypt("Anupma@123"));
		
	}

}
