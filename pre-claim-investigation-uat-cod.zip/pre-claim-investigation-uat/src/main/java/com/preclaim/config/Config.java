package com.preclaim.config;

import org.springframework.boot.context.properties.ConfigurationProperties;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter @Setter @ToString
@ConfigurationProperties
public class Config {

	private String site_name;
	private String version;
	private String upload_directory;
	private String template_directory;
	private String upload_url;
	private String template_url;
	
	//LDAP Server Details
	private String LDAP_AUTHENTICATION;
	private String INITIAL_CONTEXT_FACTORY;
	private String PROVIDER_URL;
	private String SECURITY_PRINCIPAL;
	
	//Designation
	private String ADMIN;
	private String RCUTEAM;
	private String REGIONAL_MANAGER;
	private String SUPERVISOR;
	private String INVESTIGATOR;
	private String CLAIMS;
	private String UNDERWRITER;
	private String TALIC_MANAGER;
}
