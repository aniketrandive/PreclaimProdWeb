package com.preclaim.controller;

import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.preclaim.config.CustomMethods;
import com.preclaim.dao.DispositionDao;
import com.preclaim.dao.PIVFormDao;
import com.preclaim.dao.UserDAO;
import com.preclaim.models.Disposition;
import com.preclaim.models.ScreenDetails;
import com.preclaim.models.UserDetails;



@Controller
@RequestMapping(value = "/disposition")
public class DispositionController {
	
	@Autowired
	DispositionDao disPositionDao;
	
	@Autowired
	UserDAO userDao;
	
	@Autowired
    PIVFormDao  pivFormDao;
	
	@RequestMapping(value = "/addDisposition", method = RequestMethod.GET)
	public String Disposition(HttpSession session,HttpServletRequest request) {
		UserDetails user = (UserDetails) session.getAttribute("User_Login");
		if(user == null)
			return "redirect:/login";

		Cookie[] cookies = request.getCookies();
		if(!CustomMethods.iscookiesandsessionisvalid(user,cookies)) {
			return "redirect:/login";
		}


		List<String> permission =(ArrayList<String>)session.getAttribute("user_permission");
		if(!permission.contains("disposition"))
			return "common/login";
		session.removeAttribute("ScreenDetails");
		ScreenDetails details = new ScreenDetails();
		details.setScreen_title("Add  Disposition");
		try {
			details.setScreen_name("../Disposition/addDisposition.jsp");

			details.setMain_menu("Disposition");
			details.setSub_menu1("Add Disposition");
			details.setSub_menu2("Manage Disposition");
			//details.setSub_menu2_path("/Trigger/addTriggerName");
			if(session.getAttribute("success_message") != null)
			{
				details.setSuccess_message1((String)session.getAttribute("success_message"));
				session.removeAttribute("success_message");
			}		
			if (request.getParameter("dispositionName") !=null) {
				String disPositionName = request.getParameter("dispositionName");
				Disposition dispositionName = new Disposition(disPositionName);
				session.setAttribute("DisPositionName", dispositionName);
			}
			session.setAttribute("disPositionList", disPositionDao.getAllDisPositionList());


		}catch(Exception e) {
			details.setScreen_name("../message/error.jsp");
			details.setError_message1("Contct Administrator error :-"+e.getMessage());	
			CustomMethods.logError(e);
		}
		session.setAttribute("ScreenDetails", details);
		return "common/templatecontent";
	}
	
	@RequestMapping(value = "/Questionaire", method = RequestMethod.GET)
	public String ErrorFileRecords(HttpSession session,HttpServletRequest request) {
		session.removeAttribute("ScreenDetails");
		UserDetails user = (UserDetails) session.getAttribute("User_Login");
		if (user == null)
			return "redirect:/login";

		Cookie[] cookies = request.getCookies();
		if(!CustomMethods.iscookiesandsessionisvalid(user,cookies)) {
			return "redirect:/login";
		}
		/*
		 * List<String> permission = (ArrayList<String>)
		 * session.getAttribute("user_permission"); if
		 * (!permission.contains("messages")) return "common/login";
		 */

		ScreenDetails details = new ScreenDetails();
		details.setScreen_title("Questionarie");
		try {
			details.setScreen_name("../Disposition/Questionarie.jsp");
			details.setMain_menu("Disposition");
			details.setSub_menu1("Disposition");
			if (session.getAttribute("success_message") != null) {
				details.setSuccess_message1((String) session.getAttribute("success_message"));
				session.removeAttribute("success_message");
			}	


			session.setAttribute("AllCasePivDetails", pivFormDao.getPivFormDetails(Long.parseLong(request.getParameter("caseId"))));



		}catch(Exception e) {
			details.setScreen_name("../message/error.jsp");
			details.setError_message1("Contct Administrator error :-"+e.getMessage());	
			CustomMethods.logError(e);
		}
		session.setAttribute("ScreenDetails", details);
		return "common/templatecontent";
		
	}
	
	
	@RequestMapping(value = "/add", method = RequestMethod.POST)
	public @ResponseBody String add(HttpSession session, HttpServletRequest request) {
		
		UserDetails user = (UserDetails) session.getAttribute("User_Login");
		   Disposition  dispositionName = new Disposition();
		
		   dispositionName.setDisposition_name(request.getParameter("dispositionName"));
		   dispositionName.setCreated_by(user.getUsername());
		   if (CustomMethods.isStringContainsSpecialCharacter(request.getParameter("dispositionName")))
				return "dispositionName Remove Special charchters [-?*'\'<>{}/+$?()=%]";
	
			else {
		   
		   String message = disPositionDao.addDispositonName(dispositionName);   
		
		
		if (message.equals("****")) {
			session.setAttribute("success_message", "DisPosition Name added successfully");
			userDao.activity_log("DISPOSITION", dispositionName.getDisposition_name(),"ADD",user.getUsername());
		}
		return message;
			}
	}
	
	@RequestMapping(value ="/updateDisPosition", method = RequestMethod.POST )
    public @ResponseBody String updateDisPostion(HttpSession session, HttpServletRequest request) {
     String dispositionName = request.getParameter("dispositionName");		
	 String dispositionId = request.getParameter("dispositionId");

	  if (CustomMethods.isStringContainsSpecialCharacter(request.getParameter("dispositionName")))
			return "dispositionName Remove Special charchters [-?*'\'<>{}/+$?()=%]";
	  if (CustomMethods.isStringContainsSpecialCharacter(request.getParameter("dispositionId")))
			return "dispositionId Remove Special charchters [-?*'\'<>{}/+$?()=%]";
	  else {
	 String message = disPositionDao.updateDispositionName(dispositionName,dispositionId);
	 UserDetails user = (UserDetails) session.getAttribute("User_Login");
     if(message.equals("****"))
	 {
		 session.setAttribute("success_message", "Disposition updated successfully");
		 userDao.activity_log("Disposition NAME", dispositionName, "UPDATE", user.getUsername());
	 }
	 return message;
	}
	}
	
	@RequestMapping(value ="/deleteDisPosition",method = RequestMethod.POST )
    public @ResponseBody String deleteDisPosition(HttpSession session, HttpServletRequest request) {
     String dispositionName = request.getParameter("dispositionName");
	 String message = disPositionDao.deleteDisPositionName(dispositionName);
	 UserDetails user = (UserDetails) session.getAttribute("User_Login");
     if(message.equals("****"))
	 {
		 session.setAttribute("success_message", "Disposition deletd successfully");
		 userDao.activity_log("DISPOSITION NAME", dispositionName, "Delete", user.getUsername());
	 }
	 return "****";
	}
	
	
	
	@RequestMapping(value = "/updateDisPositionStatus", method = RequestMethod.POST)
	public @ResponseBody String updateDisPostionStatus(HttpSession session, HttpServletRequest request) {
		String status = request.getParameter("status");
		String dispositionName = request.getParameter("dispositionName");
		if (CustomMethods.isStringContainsSpecialCharacter(request.getParameter("dispositionName")))
			return "dispositionName Remove Special charchters [-?*'\'<>{}/+$?()=%]";
		if (CustomMethods.isStringContainsSpecialCharacter(request.getParameter("status")))
			return "status Remove Special charchters [-?*'\'<>{}/+$?()=%]";
		{
		UserDetails user = (UserDetails) session.getAttribute("User_Login");		 
		String message = disPositionDao.updateDisPositionNameStatus(dispositionName, status);
		if(message.equals("****"))
		{
			session.setAttribute("success_message", "Disposition status changed successfully");
			userDao.activity_log("DISPOSITION NAME", dispositionName, status.equals("1") ? "ACTIVE" : "DEACTIVE", 
				user.getUsername());
		}
		return message;
	}
	}
	
	@RequestMapping(value = "/updateQuestionaire", method = RequestMethod.POST)
	public @ResponseBody String updateQuestionaire(HttpSession session, HttpServletRequest request) {
		String message = "";
		Enumeration<String> formId = request.getParameterNames();
		while(formId.hasMoreElements())
		{
			String parameterName = formId.nextElement();
			
			int Id= Integer.parseInt(parameterName); 
			String remark = request.getParameterValues(parameterName)[0];
			if (CustomMethods.isStringContainsSpecialCharacter(remark))
				return "remark Remove Special charchters [-?*'\'<>{}/+$?()=%]";
			else {
			message = pivFormDao.updatePivFormRemark(Id, remark);	
			}
		}	
         if(!message.equals("****"))
        	 return "Error while updating remarks";
		
         return message;
	}
	
	
	
}
