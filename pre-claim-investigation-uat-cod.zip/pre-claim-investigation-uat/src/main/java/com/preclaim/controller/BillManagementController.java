package com.preclaim.controller;


import java.io.FileOutputStream;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Enumeration;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.poi.ss.usermodel.BorderStyle;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.google.gson.Gson;
import com.preclaim.config.Config;
import com.preclaim.config.CustomMethods;
import com.preclaim.dao.BillingManagementDao;
import com.preclaim.models.BillManagementList;
import com.preclaim.models.Case_payment;
import com.preclaim.models.ScreenDetails;
import com.preclaim.models.UserDetails;

@Controller
@RequestMapping(value = "/billManagement")
public class BillManagementController {
		
	@Autowired 
	BillingManagementDao billingDao;
	
	@Autowired
	Config config;
	
	@RequestMapping(value = "/bill_enquiry", method = RequestMethod.GET)  
	public String pending_message(HttpSession session,HttpServletRequest request) 
	{  	  
		UserDetails user = (UserDetails) session.getAttribute("User_Login");
		if(user == null)
			return "redirect:/login";


		Cookie[] cookies = request.getCookies();
		if(!CustomMethods.iscookiesandsessionisvalid(user,cookies)) {
			return "redirect:/login";
		}

		List<String> permission =(ArrayList<String>)session.getAttribute("user_permission");
		if(!permission.contains("billingManagement"))
			return "common/login";

		session.removeAttribute("ScreenDetails");
		ScreenDetails details = new ScreenDetails();
		details.setScreen_title("Bill Enquiry Lists");
		try{
			details.setScreen_name("../billManagement/bill_enquiry.jsp");		
			details.setMain_menu("Billing Management");			
			details.setSub_menu1("Bill Enquiry");

			if(session.getAttribute("success_message") != null)
			{
				details.setSuccess_message1((String)session.getAttribute("success_message"));	
				session.removeAttribute("success_message");
			}
			session.setAttribute("billingEnquiryList",billingDao.billEnquiryList());


		}catch(Exception e) {
			details.setScreen_name("../message/error.jsp");
			details.setError_message1("Contct Administrator error :-"+e.getMessage());	
			CustomMethods.logError(e);
		}
		session.setAttribute("ScreenDetails", details);
		return "common/templatecontent";     
	}
	
	  @RequestMapping(value = "/bill_payment",method = RequestMethod.GET)	
	  public String bill_payment(HttpSession session, HttpServletRequest request) 
	  {	
		  UserDetails user = (UserDetails) session.getAttribute("User_Login");	
		  if(user == null)
			  return "redirect:/login";
		  List<String> permission =(ArrayList<String>)session.getAttribute("user_permission");
		  if(!permission.contains("billingManagement"))
			  return "common/login";

		  Cookie[] cookies = request.getCookies();
		  if(!CustomMethods.iscookiesandsessionisvalid(user,cookies)) {
			  return "redirect:/login";
		  }

		  session.removeAttribute("ScreenDetails");
		  ScreenDetails details=new ScreenDetails();
		  details.setScreen_title("Bill Payment Lists");
		  try {
			  details.setScreen_name("../billManagement/bill_payment.jsp");
			  details.setScreen_title("Bill Payment Lists");
			  details.setMain_menu("Billing Management");
			  details.setSub_menu1("Bill Payment");
			  if(session.getAttribute("success_message") != null)
			  {
				  details.setSuccess_message1((String)session.getAttribute("success_message"));
				  session.removeAttribute("success_message");
			  }
			  session.setAttribute("billingPendingList",billingDao.billPaymentList());


		  }catch(Exception e) {
			  details.setScreen_name("../message/error.jsp");
			  details.setError_message1("Contct Administrator error :-"+e.getMessage());	
			  CustomMethods.logError(e);
		  }
		  session.setAttribute("ScreenDetails", details);
		  return "common/templatecontent";
	  } 
	  
	  @RequestMapping(value = "/getCheckboxValue",method = RequestMethod.POST)
	  public @ResponseBody String getCheckboxValue(HttpSession session, HttpServletRequest request) throws IOException 
	  {
		  UserDetails user = (UserDetails) session.getAttribute("User_Login");   
		  Enumeration<String> tempStr = request.getParameterNames();
		  List<Case_payment> className = new ArrayList<Case_payment>();
		  while(tempStr.hasMoreElements()) {
			  String[] value = request.getParameterValues(tempStr.nextElement());
			  for(String values: value) {
					
			  System.out.println("value"+value);
		      Gson gson = new Gson();
		      Case_payment case_payment = new Case_payment();
			  case_payment = Arrays.asList(gson.fromJson(values, Case_payment.class)).get(0);
			  case_payment.setCreated_by(user.getUsername());
			  System.out.println(case_payment);
			  billingDao.UpdateFees(case_payment);		 
			  className.add(case_payment);    
		  }
		  } 
		  
		  //Create blank workbook
		  XSSFWorkbook workbook = new XSSFWorkbook();  
		  XSSFCellStyle style1 = workbook.createCellStyle();
		  //Create a blank sheet        
		  XSSFSheet spreadsheet = workbook.createSheet( "Claims Info");       
		  //Create row object         
		  XSSFRow row;


		  //This data needs to be written (Object[])         
		  Map<Integer, Object[]> empinfo = billingDao.billPaymentList(className);   
		  //Iterate over data and write to sheet
	        
		  Set<Integer> keyid = empinfo.keySet();
		  int rowid = 0;
		  for (Integer key : keyid) 
		  { 
			  row = spreadsheet.createRow(rowid++); 
			  Object [] objectArr = empinfo.get(key); 
			  int cellid = 0;
		   
		      for (Object obj : objectArr)		    
		      { 
		    	  XSSFCell cell = row.createCell(cellid++);
		    	    style1.setBorderLeft(BorderStyle.THIN);  
		            style1.setRightBorderColor(IndexedColors.BLACK.getIndex());
		            style1.setBorderRight(BorderStyle.THIN);  
		            style1.setRightBorderColor(IndexedColors.BLACK.getIndex());
		            style1.setBorderTop(BorderStyle.THIN);  
		            style1.setRightBorderColor(IndexedColors.BLACK.getIndex());
		            style1.setBorderBottom(BorderStyle.THIN);  
		            style1.setRightBorderColor(IndexedColors.BLACK.getIndex());
					cell.setCellStyle(style1);
		    	  cell.setCellValue(obj.toString()); 
		      } 
		  }
		  
		  spreadsheet.autoSizeColumn(1);
		  spreadsheet.autoSizeColumn(2);
		  spreadsheet.autoSizeColumn(3);
		  spreadsheet.autoSizeColumn(4);
		  spreadsheet.autoSizeColumn(5);
		  spreadsheet.autoSizeColumn(6);
		  spreadsheet.autoSizeColumn(7);
		  spreadsheet.autoSizeColumn(8);
		  spreadsheet.autoSizeColumn(9);
		  spreadsheet.autoSizeColumn(10);
		  spreadsheet.autoSizeColumn(11);
		  spreadsheet.autoSizeColumn(12);
		  spreadsheet.autoSizeColumn(13);
		  spreadsheet.autoSizeColumn(14);
		  spreadsheet.autoSizeColumn(15);
		  spreadsheet.autoSizeColumn(16);
		  spreadsheet.autoSizeColumn(17);
		  spreadsheet.autoSizeColumn(18);
		  spreadsheet.autoSizeColumn(19);
		  String currentDate = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd-MM-yyyy hh-mm-ss"));
		  
		  //Write the workbook in file system
		  String filename = "Bill Payment_" + currentDate + ".xlsx";
		  FileOutputStream out = new FileOutputStream(config.getUpload_directory() + filename);
		  
		  workbook.write(out); 
		  out.close();
		  workbook.close();
		  session.setAttribute("success_message", "Payment generated successfully");
		  return filename; 
	  }	
	  
	  @RequestMapping(value = "/getFilter", method = RequestMethod.POST)
		public @ResponseBody List<BillManagementList> getFilter(HttpServletRequest request, HttpSession session) {
			String startdate = request.getParameter("startdate");
			String enddate = request.getParameter("enddate");
			
			return billingDao.billPaymentList(startdate,enddate);

		}
} 
	  

