package com.preclaim.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.preclaim.config.CustomMethods;
import com.preclaim.dao.LocationDao;
import com.preclaim.dao.UserDAO;
import com.preclaim.models.Location;
import com.preclaim.models.ScreenDetails;
import com.preclaim.models.UserDetails;

@Controller
@RequestMapping(value = "/location")
public class LocationController{

	@Autowired
	private LocationDao locationDao;
	@Autowired
	private UserDAO userDao;
	
	@RequestMapping(value = "/add",method = RequestMethod.GET)
	public String add_location(HttpSession session,HttpServletRequest request) {
		UserDetails user = (UserDetails) session.getAttribute("User_Login");
		if(user == null)
			return "redirect:/login";

		Cookie[] cookies = request.getCookies();
		if(!CustomMethods.iscookiesandsessionisvalid(user,cookies)) {
			return "redirect:/login";
		}

		List<String> permission =(ArrayList<String>)session.getAttribute("user_permission");
		if(!permission.contains("location"))
			return "common/login";
		session.removeAttribute("ScreenDetails");
		ScreenDetails details=new ScreenDetails();
		details.setScreen_title("Add Location");
		try {
			details.setScreen_name("../location/addLocation.jsp");
			details.setMain_menu("Location");
			details.setSub_menu1("Add Location");
			details.setSub_menu2("Manage Locations");
			details.setSub_menu2_path("/location/pending");
			if(session.getAttribute("success_message") != null)
			{
				details.setSuccess_message1((String)session.getAttribute("success_message"));
				session.removeAttribute("success_message");
			}


		}catch(Exception e) {
			details.setScreen_name("../message/error.jsp");
			details.setError_message1("Contct Administrator error :-"+e.getMessage());	
			CustomMethods.logError(e);
		}
		session.setAttribute("ScreenDetails", details);
		return "common/templatecontent";
	}
	
	@RequestMapping(value = "/pending",method = RequestMethod.GET)
	public String pending_location(HttpSession session, HttpServletRequest request) {
		UserDetails user = (UserDetails) session.getAttribute("User_Login");
		if(user == null)
			return "redirect:/login";


		Cookie[] cookies = request.getCookies();
		if(!CustomMethods.iscookiesandsessionisvalid(user,cookies)) {
			return "redirect:/login";
		}

		List<String> permission =(ArrayList<String>)session.getAttribute("user_permission");
		if(!permission.contains("location"))
			return "common/login";
		session.removeAttribute("ScreenDetails");
		ScreenDetails details=new ScreenDetails();
		details.setScreen_title("Pending Location");
		try {
			details.setScreen_name("../location/pendingLocation.jsp");

			details.setMain_menu("Location");
			details.setSub_menu1("Pending Location");
			if(session.getAttribute("success_message") != null)
			{
				details.setSuccess_message1((String)session.getAttribute("success_message"));
				session.removeAttribute("success_message");
			}

			session.setAttribute("pending_location", locationDao.locationList(0));

			if(request.getParameter("locationId")!= null)
				session.setAttribute("location", 
						locationDao.getLocationById(Integer.parseInt(request.getParameter("locationId"))));


		}catch(Exception e) {
			details.setScreen_name("../message/error.jsp");
			details.setError_message1("Contct Administrator error :-"+e.getMessage());	
			CustomMethods.logError(e);
		}
		session.setAttribute("ScreenDetails", details);
		return "common/templatecontent";
	}
	
	@RequestMapping(value = "/active",method = RequestMethod.GET)
	public String active_location(HttpSession session,HttpServletRequest request) {
		UserDetails user = (UserDetails) session.getAttribute("User_Login");
		if(user == null)
			return "redirect:/login";

		Cookie[] cookies = request.getCookies();
		if(!CustomMethods.iscookiesandsessionisvalid(user,cookies)) {
			return "redirect:/login";
		}

		List<String> permission =(ArrayList<String>)session.getAttribute("user_permission");
		if(!permission.contains("location"))
			return "common/login";
		session.removeAttribute("ScreenDetails");
		ScreenDetails details=new ScreenDetails();
		details.setScreen_title("Active Location");
		try {
			details.setScreen_name("../location/activeLocation.jsp");
			details.setMain_menu("Location");
			details.setSub_menu1("Active Location");
			if(session.getAttribute("success_message") != null)
			{
				details.setSuccess_message1((String)session.getAttribute("success_message"));
				session.removeAttribute("success_message");
			}
			session.setAttribute("active_location", locationDao.locationList(1));


		}catch(Exception e) {
			details.setScreen_name("../message/error.jsp");
			details.setError_message1("Contct Administrator error :-"+e.getMessage());	
			CustomMethods.logError(e);
		}
		session.setAttribute("ScreenDetails", details);
		return "common/templatecontent";
	}
	
	@RequestMapping(value = "/deleteLocation",method = RequestMethod.POST)
	public @ResponseBody String deleteRegion(HttpSession session, HttpServletRequest request) {
	
		UserDetails user = (UserDetails) session.getAttribute("User_Login");
		if(user == null)
			return "redirect:/login";
		
		Cookie[] cookies = request.getCookies();
		if(!CustomMethods.iscookiesandsessionisvalid(user,cookies)) {
			return "redirect:/login";
		}
		List<String> permission =(ArrayList<String>)session.getAttribute("user_permission");
		if(!permission.contains("location"))
			return "common/login";
		int locationId = Integer.parseInt(request.getParameter("locationId"));
		String message = locationDao.deleteLocation(locationId);
		if(message.equals("****"))
		{
			session.setAttribute("success_message", "Location deleted successfully");
	    	userDao.activity_log("LOCATION", String.valueOf(locationId), "DELETE", user.getUsername()); 
		}
		return message;
	}
	
	@RequestMapping(value = "/addLocation",method = RequestMethod.POST)
	public @ResponseBody String addRegion(HttpSession session, HttpServletRequest request) 
	{	
		UserDetails user = (UserDetails) session.getAttribute("User_Login");
		if(user == null)
			return "redirect:/login";
		
		Cookie[] cookies = request.getCookies();
		if(!CustomMethods.iscookiesandsessionisvalid(user,cookies)) {
			return "redirect:/login";
		}
		
		List<String> permission =(ArrayList<String>)session.getAttribute("user_permission");
		if(!permission.contains("location"))
			return "common/login";
		Location location = new Location();
		if (CustomMethods.isStringContainsSpecialCharacter(request.getParameter("city")))
			return "city Remove Special charchters [-?*'\'<>{}/+$?()=%]";
		location.setCity(request.getParameter("city"));
		
		if (CustomMethods.isStringContainsSpecialCharacter(request.getParameter("state")))
			return "state Remove Special charchters [-?*'\'<>{}/+$?()=%]";
		location.setState(request.getParameter("state"));
		if (CustomMethods.isStringContainsSpecialCharacter(request.getParameter("zone")))
			return "zone Remove Special charchters [-?*'\'<>{}/+$?()=%]";
		location.setZone(request.getParameter("zone"));
		
		location.setCreatedBy(user.getUsername());
		String message = locationDao.addLocation(location);
		if(message.equals("****"))
		{
			session.setAttribute("success_message", "Location added successfully");
			userDao.activity_log("LOCATION" ,location.getCity(), "ADD", user.getUsername());
			userDao.activity_log("LOCATION" ,location.getState(), "ADD", user.getUsername());
			userDao.activity_log("LOCATION" ,location.getZone(), "ADD", user.getUsername());
		}
		return message;
	}
	
	@RequestMapping(value = "/updateLocation",method = RequestMethod.POST)
	public @ResponseBody String updateRegion(HttpSession session, HttpServletRequest request) 
	{	
		UserDetails user = (UserDetails) session.getAttribute("User_Login");
		if(user == null)
			return "redirect:/login";
		
		Cookie[] cookies = request.getCookies();
		if(!CustomMethods.iscookiesandsessionisvalid(user,cookies)) {
			return "redirect:/login";
		}
		
		List<String> permission =(ArrayList<String>)session.getAttribute("user_permission");
		if(!permission.contains("location"))
			return "common/login";
		if (CustomMethods.isStringContainsSpecialCharacter(request.getParameter("locationId")))
			return "locationId Remove Special charchters [-?*'\'<>{}/+$?()=%]";
		if (CustomMethods.isStringContainsSpecialCharacter(request.getParameter("city")))
			return "city Remove Special charchters [-?*'\'<>{}/+$?()=%]";
		if (CustomMethods.isStringContainsSpecialCharacter(request.getParameter("state")))
			return "state Remove Special charchters [-?*'\'<>{}/+$?()=%]";
		if (CustomMethods.isStringContainsSpecialCharacter(request.getParameter("zone")))
			return "zone Remove Special charchters [-?*'\'<>{}/+$?()=%]";
		
		int locationId=Integer.parseInt(request.getParameter("locationId"));		
	    String city = request.getParameter("city");
        String state = request.getParameter("state");
        String zone = request.getParameter("zone");
 
 
        String message = locationDao.updateLocation(locationId, city, state, zone);
        if(message.equals("****"))
        {
        	session.setAttribute("success_message", "Location updated successfully");
	    	userDao.activity_log("LOCATION", String.valueOf(locationId), "UPDATE", user.getUsername());
        }
        return message;
	}
	
	@RequestMapping(value = "/updateLocationStatus",method = RequestMethod.POST)
	public @ResponseBody String updateRegionStatus(HttpSession session, HttpServletRequest request)
	{
		UserDetails user = (UserDetails) session.getAttribute("User_Login");
		if(user == null)
			return "redirect:/login";
		List<String> permission =(ArrayList<String>)session.getAttribute("user_permission");
		if(!permission.contains("location"))
			return "common/login";
		int locationId=Integer.parseInt(request.getParameter("locationId"));
		int locationStatus=Integer.parseInt(request.getParameter("status"));
	    String message= locationDao.updateLocationStatus(locationId, locationStatus); 
	    if(message.equals("****"))
	    {
	    	session.setAttribute("success_message", "Location status changed successfully");
	    	userDao.activity_log("LOCATION", String.valueOf(locationId), 
	    			locationStatus == 1 ? "ACTIVE" : "DEACTIVE", user.getUsername());
	    }
	    return message;
    }
}


