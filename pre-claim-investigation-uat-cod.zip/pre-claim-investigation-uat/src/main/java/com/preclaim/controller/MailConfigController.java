package com.preclaim.controller;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.preclaim.config.CustomMethods;
import com.preclaim.dao.MailConfigDao;
import com.preclaim.dao.UserDAO;
import com.preclaim.models.MailConfigList;
import com.preclaim.models.ScreenDetails;
import com.preclaim.models.UserDetails;

@Controller
@RequestMapping(value = "/mailConfig")
public class MailConfigController{

	@Autowired
	private MailConfigDao mailConfigDao;
	@Autowired
	private UserDAO userDao;
	
	@RequestMapping(value = "/add",method = RequestMethod.GET)
	public String add(HttpSession session,HttpServletRequest request) {
		UserDetails user = (UserDetails) session.getAttribute("User_Login");
		if(user == null)
			return "redirect:/login";

		Cookie[] cookies = request.getCookies();
		if(!CustomMethods.iscookiesandsessionisvalid(user,cookies)) {
			return "redirect:/login";
		}

		List<String> permission =(ArrayList<String>)session.getAttribute("user_permission");
		if(!permission.contains("mailConfig"))
			return "common/login";
		session.removeAttribute("ScreenDetails");
		ScreenDetails details=new ScreenDetails();
		details.setScreen_title("Add Mail Config");
		try {
			details.setScreen_name("../mailConfig/addConfig.jsp");

			details.setMain_menu("Mail Config");
			details.setSub_menu1("Add Mail Config");
			details.setSub_menu2("Manage Mail Config");
			details.setSub_menu2_path("/mailConfig/pendingConfig");
			if(session.getAttribute("success_message") != null)
			{
				details.setSuccess_message1((String)session.getAttribute("success_message"));
				session.removeAttribute("success_message");
			}


		}catch(Exception e) {
			details.setScreen_name("../message/error.jsp");
			details.setError_message1("Contct Administrator error :-"+e.getMessage());	
			CustomMethods.logError(e);
		}
		session.setAttribute("ScreenDetails", details);
		return "common/templatecontent";
	}
	
	@RequestMapping(value = "/edit/{mailConfigId}",method = RequestMethod.GET)
	public String edit(@PathVariable("mailConfigId") int mailConfigId, HttpSession session,HttpServletRequest request) {
		UserDetails user = (UserDetails) session.getAttribute("User_Login");
		if(user == null)
			return "redirect:/login";

		Cookie[] cookies = request.getCookies();
		if(!CustomMethods.iscookiesandsessionisvalid(user,cookies)) {
			return "redirect:/login";
		}

		List<String> permission =(ArrayList<String>)session.getAttribute("user_permission");
		if(!permission.contains("mailConfig"))
			return "common/login";
		session.removeAttribute("ScreenDetails");
		ScreenDetails details = new ScreenDetails();
		details.setScreen_title("Add Mail Config");
		try {
			details.setScreen_name("../mailConfig/editConfig.jsp");

			details.setMain_menu("Mail Config");
			details.setSub_menu1("Add Mail Config");
			details.setSub_menu2("Manage Mail Config");
			details.setSub_menu2_path("/mailConfig/pendingConfig");
			session.setAttribute("editMailConfig", mailConfigDao.getMailConfigListById(mailConfigId));


		}catch(Exception e) {
			details.setScreen_name("../message/error.jsp");
			details.setError_message1("Contct Administrator error :-"+e.getMessage());	
			CustomMethods.logError(e);
		}
		session.setAttribute("ScreenDetails", details);
		return "common/templatecontent";
	}
	@RequestMapping(value = "/pending",method = RequestMethod.GET)
	public String pending(HttpSession session, HttpServletRequest request) {
		UserDetails user = (UserDetails) session.getAttribute("User_Login");
		if(user == null)
			return "redirect:/login";

		Cookie[] cookies = request.getCookies();
		if(!CustomMethods.iscookiesandsessionisvalid(user,cookies)) {
			return "redirect:/login";
		}

		List<String> permission =(ArrayList<String>)session.getAttribute("user_permission");
		if(!permission.contains("mailConfig"))
			return "common/login";
		session.removeAttribute("ScreenDetails");
		ScreenDetails details = new ScreenDetails();
		details.setScreen_title("Pending Mail Config");
		try {
			details.setScreen_name("../mailConfig/pendingConfig.jsp");

			details.setMain_menu("Mail Config");
			details.setSub_menu1("Pending Mail Config");
			if(session.getAttribute("success_message") != null)
			{
				details.setSuccess_message1((String)session.getAttribute("success_message"));
				session.removeAttribute("success_message");
			}
			session.setAttribute("pendingConfig", mailConfigDao.getMailConfigList(0));


		}catch(Exception e) {
			details.setScreen_name("../message/error.jsp");
			details.setError_message1("Contct Administrator error :-"+e.getMessage());	
			CustomMethods.logError(e);
		}
		session.setAttribute("ScreenDetails", details);
		
		return "common/templatecontent";
	}
	
	@RequestMapping(value = "/active",method = RequestMethod.GET)
	public String active(HttpSession session,HttpServletRequest request) {
		UserDetails user = (UserDetails) session.getAttribute("User_Login");
		if(user == null)
			return "redirect:/login";

		Cookie[] cookies = request.getCookies();
		if(!CustomMethods.iscookiesandsessionisvalid(user,cookies)) {
			return "redirect:/login";
		}

		List<String> permission =(ArrayList<String>)session.getAttribute("user_permission");
		if(!permission.contains("mailConfig"))
			return "common/login";
		session.removeAttribute("ScreenDetails");
		ScreenDetails details = new ScreenDetails();
		details.setScreen_title("Active mailConfig");
		try {
			details.setScreen_name("../mailConfig/activeConfig.jsp");
			details.setMain_menu("Mail Config");
			details.setSub_menu1("Active Mail Config");
			if(session.getAttribute("success_message") != null)
			{
				details.setSuccess_message1((String)session.getAttribute("success_message"));
				session.removeAttribute("success_message");
			}
			session.setAttribute("activeConfig", mailConfigDao.getMailConfigList(1));


		}catch(Exception e) {
			details.setScreen_name("../message/error.jsp");
			details.setError_message1("Contct Administrator error :-"+e.getMessage());	
			CustomMethods.logError(e);
		}
		session.setAttribute("ScreenDetails", details);
		return "common/templatecontent";
	}
	
	@RequestMapping(value = "/delete",method = RequestMethod.POST)
	public @ResponseBody String delete(HttpSession session, HttpServletRequest request) {
	
		UserDetails user = (UserDetails) session.getAttribute("User_Login");
		if(user == null)
			return "redirect:/login";
		
		Cookie[] cookies = request.getCookies();
		if(!CustomMethods.iscookiesandsessionisvalid(user,cookies)) {
			return "redirect:/login";
		}
		
		List<String> permission =(ArrayList<String>)session.getAttribute("user_permission");
		if(!permission.contains("mailConfig"))
			return "common/login";
		int mailConfigId = Integer.parseInt(request.getParameter("mailConfigId"));
		String message = mailConfigDao.delete(mailConfigId);
		if(message.equals("****"))
		{
			session.setAttribute("success_message", "Mail Configuration deleted successfully");
			userDao.activity_log("MAIL", String.valueOf(mailConfigId), "DELETE", user.getUsername());
		}
		return message;
	}
	
	@RequestMapping(value = "/addMailConfig",method = RequestMethod.POST)
	public @ResponseBody String addmailConfig(HttpServletRequest request,HttpSession session) 
	{	
		UserDetails user = (UserDetails) session.getAttribute("User_Login");
		if(user == null)
			return "redirect:/login";
		
		Cookie[] cookies = request.getCookies();
		if(!CustomMethods.iscookiesandsessionisvalid(user,cookies)) {
			return "redirect:/login";
		}
		
		List<String> permission =(ArrayList<String>)session.getAttribute("user_permission");
		if(!permission.contains("mailConfig"))
			return "common/login";
		if (CustomMethods.isStringContainsSpecialCharacter(request.getParameter("username")))
			return "username Remove Special charchters "+CustomMethods.sepcical_char+"";
		if (CustomMethods.isStringContainsSpecialCharacter(request.getParameter("password")))
			return "password Remove Special charchters "+CustomMethods.sepcical_char+"";
		if (CustomMethods.isStringContainsSpecialCharacter(request.getParameter("outgoingServer")))
			return "outgoingServer Remove Special charchters "+CustomMethods.sepcical_char+"";
		if (CustomMethods.isStringContainsSpecialCharacter(request.getParameter("outgoingPort")))
			return "outgoingPort Remove Special charchters "+CustomMethods.sepcical_char+"";
		else {
		MailConfigList mailConfig = new MailConfigList();
		mailConfig.setUsername(request.getParameter("username"));
		mailConfig.setPassword(request.getParameter("password"));
		mailConfig.setOutgoingServer(request.getParameter("outgoingServer"));
		mailConfig.setOutgoingPort(Integer.parseInt(request.getParameter("outgoingPort")));
		mailConfig.setEncryptionType(request.getParameter("encryptionType"));
		mailConfig.setCreatedBy(user.getUsername());
		String message = mailConfigDao.add(mailConfig);		
		if(message.equals("****"))
		{
			session.setAttribute("success_message", "Mail Configuration added successfully");
			userDao.activity_log("MAIL", "", "ADD", user.getUsername());
		}
		return message;
		}
	}
	
	@RequestMapping(value = "/update",method = RequestMethod.POST)
	public @ResponseBody String update(HttpSession session, HttpServletRequest request) 
	{	
		UserDetails user = (UserDetails) session.getAttribute("User_Login");
		if(user == null)
			return "redirect:/login";
		
		Cookie[] cookies = request.getCookies();
		if(!CustomMethods.iscookiesandsessionisvalid(user,cookies)) {
			return "redirect:/login";
		}
		
		List<String> permission =(ArrayList<String>)session.getAttribute("user_permission");
		if(!permission.contains("mailConfig"))
			return "common/login";
		
		if (CustomMethods.isStringContainsSpecialCharacter(request.getParameter("username")))
			return "username Remove Special charchters "+CustomMethods.sepcical_char+"";
		if (CustomMethods.isStringContainsSpecialCharacter(request.getParameter("password")))
			return "password Remove Special charchters "+CustomMethods.sepcical_char+"";
		if (CustomMethods.isStringContainsSpecialCharacter(request.getParameter("outgoingServer")))
			return "outgoingServer Remove Special charchters "+CustomMethods.sepcical_char+"";
		if (CustomMethods.isStringContainsSpecialCharacter(request.getParameter("outgoingPort")))
			return "outgoingPort Remove Special charchters "+CustomMethods.sepcical_char+"";
		else {
		MailConfigList mailConfig = new MailConfigList();
		mailConfig.setMailConfigId(Integer.parseInt(request.getParameter("mailConfigId")));
		mailConfig.setUsername(request.getParameter("username"));
		mailConfig.setPassword(request.getParameter("password"));
		mailConfig.setOutgoingServer(request.getParameter("outgoingServer"));
		mailConfig.setOutgoingPort(Integer.parseInt(request.getParameter("outgoingPort")));
		mailConfig.setEncryptionType(request.getParameter("encryptionType"));
		mailConfig.setUpdatedBy(user.getUsername());
		String message = mailConfigDao.update(mailConfig);	
		if(message.equals("****"))
		{
			session.setAttribute("success_message", "Mail Configuration updated successfully");
			userDao.activity_log("MAIL", String.valueOf(mailConfig.getMailConfigId()), "UPDATE", user.getUsername());
		}
		return message;
	}
	}
	
	@RequestMapping(value = "/updateStatus",method = RequestMethod.POST)
	public @ResponseBody String updateStatus(HttpSession session, HttpServletRequest request)
	{
		UserDetails user = (UserDetails) session.getAttribute("User_Login");
		if(user == null)
			return "redirect:/login";
		
		Cookie[] cookies = request.getCookies();
		if(!CustomMethods.iscookiesandsessionisvalid(user,cookies)) {
			return "redirect:/login";
		}
		
		List<String> permission =(ArrayList<String>)session.getAttribute("user_permission");
		if(!permission.contains("mailConfig"))
			return "common/login";
		int mailConfigId = Integer.parseInt(request.getParameter("mailConfigId"));
		int mailConfigStatus = Integer.parseInt(request.getParameter("status"));
		if (CustomMethods.isStringContainsSpecialCharacter(request.getParameter("mailConfigId")))
			return "username Remove Special charchters "+CustomMethods.sepcical_char+"";
		if (CustomMethods.isStringContainsSpecialCharacter(request.getParameter("status")))
			return "password Remove Special charchters "+CustomMethods.sepcical_char+"";
		else {
	    String message = mailConfigDao.updateStatus(mailConfigId, mailConfigStatus , user.getUsername()); 
	    if(message.equals("****"))
	    {
	    	session.setAttribute("success_message", "Mail Configuration status changed successfully");
	    	userDao.activity_log("MAIL", String.valueOf(mailConfigId), 
	    			mailConfigStatus == 1 ? "ACTIVE" : "DEACTIVE", user.getUsername());
	    }
	    return message;
    }
	}
}


