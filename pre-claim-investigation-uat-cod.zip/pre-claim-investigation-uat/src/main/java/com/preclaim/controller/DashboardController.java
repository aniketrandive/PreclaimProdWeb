package com.preclaim.controller;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.preclaim.config.CustomMethods;
import com.preclaim.dao.DashboardDao;
import com.preclaim.models.ScreenDetails;
import com.preclaim.models.UserDetails;

@Controller
public class DashboardController {

	@Autowired
	DashboardDao dashboardDao;
	
	@RequestMapping(value = "/dashboard", method = RequestMethod.GET)
    public String dashboard(HttpSession session,HttpServletRequest request,HttpServletResponse response) {
		UserDetails user = (UserDetails) session.getAttribute("User_Login");

		if(user == null)
			return "redirect:/login";

		Cookie[] cookies = request.getCookies();
		if(!CustomMethods.iscookiesandsessionisvalid(user,cookies)) {
			return "redirect:/login";
		}


		request.changeSessionId();
		ScreenDetails details = new ScreenDetails();
		details.setScreen_title("Dashboard");
		try {
			details.setScreen_name("dashboard.jsp");

			details.setMain_menu("Dashboard");

			session.setAttribute("Dashboard Count", dashboardDao.getCaseCount(user));


		}catch(Exception e) {
			details.setScreen_name("../message/error.jsp");
			details.setError_message1("Contct Administrator error :-"+e.getMessage());	
			CustomMethods.logError(e);
		}
		session.setAttribute("ScreenDetails", details);
    	return "common/templatecontent";
    }
}
