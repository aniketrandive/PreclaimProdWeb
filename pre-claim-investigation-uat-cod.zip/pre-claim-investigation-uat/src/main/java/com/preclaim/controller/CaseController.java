package com.preclaim.controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletContext;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import com.preclaim.config.Config;
import com.preclaim.config.CustomMethods;
import com.preclaim.dao.CaseCategoryDao;
import com.preclaim.dao.CaseDao;
import com.preclaim.dao.CaseStatusDao;
import com.preclaim.dao.Case_docsDao;
import com.preclaim.dao.Case_movementDao;
import com.preclaim.dao.DispositionDao;
import com.preclaim.dao.InvestigationTypeDao;
import com.preclaim.dao.LocationDao;
import com.preclaim.dao.LoginDAO;
import com.preclaim.dao.MailConfigDao;
import com.preclaim.dao.NatureOfInvestigationDao;
import com.preclaim.dao.TriggerDao;
import com.preclaim.dao.UserDAO;
import com.preclaim.entity.Case_lists;
import com.preclaim.entity.Data;
import com.preclaim.entity.LoginRequest;
import com.preclaim.entity.pagingdata;
import com.preclaim.models.CaseDetailList;
import com.preclaim.models.CaseDetails;
import com.preclaim.models.CaseHistory;
import com.preclaim.models.CaseMovement;
import com.preclaim.models.CaseSubStatus;
import com.preclaim.models.Location;
import com.preclaim.models.MailConfig;
import com.preclaim.models.ScreenDetails;
import com.preclaim.models.UserDetails;
import com.preclaim.models.UserRole;
import com.preclaim.repository.CaselistsRepository;
import com.preclaim.service.BulkCaseService;
import com.preclaim.service.PDFGenration;
import com.preclaim.service.PaginationService;

@Controller
@RequestMapping(value = "/message")
public class CaseController {

	@Autowired
	CaseDao caseDao;

	@Autowired
	LoginDAO dao;

	@Autowired
	UserDAO userDao;

	@Autowired
	private NatureOfInvestigationDao natureOfInvestigationDaoImpl;

	@Autowired
	InvestigationTypeDao investigationTypeDao;

	@Autowired
	LocationDao locationDao;

	@Autowired
	Case_movementDao caseMovementDao;

	@Autowired
	MailConfigDao mailConfigDao;

	@Autowired
	CaseStatusDao caseStatusDao;

	@Autowired
	CaseCategoryDao caseCategoryDao;

	@Autowired
	Case_docsDao caseDocsDao;

	@Autowired
	TriggerDao triggerDao;

	@Autowired
	DispositionDao dispositionDao;

	@Autowired
	Config config;
	
	@Autowired
	PDFGenration pdf;
	
	@Autowired
	CaselistsRepository caserepo;
	
	@Autowired
	BulkCaseService BulkCaseService;
	
	@Autowired
	PaginationService PaginationService;
	

	List<CaseDetailList> CaseDetailList= null ;
	List<Case_lists> CaseDetailList1= null ;

	@RequestMapping(value = "/import_case", method = RequestMethod.GET)
	public String import_case(HttpSession session, HttpServletRequest request) {
		UserDetails user = (UserDetails) session.getAttribute("User_Login");
		if (user == null)
			return "common/login";

		Cookie[] cookies = request.getCookies();
		if (!CustomMethods.iscookiesandsessionisvalid(user, cookies)) {
			return "redirect:/login";
		}

		List<String> permission = (ArrayList<String>) session.getAttribute("user_permission");
		if (!permission.contains("messages"))
			return "common/login";

		session.removeAttribute("ScreenDetails");
		ScreenDetails details = new ScreenDetails();
		details.setScreen_title("Import Case");
		try {
		details.setScreen_name("../message/import_case.jsp");
		details.setMain_menu("Case Management");
		details.setSub_menu1("Bulk case uploads");
		details.setSub_menu2("App Users");
		details.setSub_menu2_path("/app_user/app_user");
		if (session.getAttribute("success_message") != null) {
			details.setSuccess_message1((String) session.getAttribute("success_message"));
			session.removeAttribute("success_message");
		}
		session.setAttribute("userRole", userDao.getUserRole_lists(user.getAccount_type(), "Approved"));
		session.setAttribute("directory", config.getUpload_directory());
		}
		catch(Exception e) {
			details.setScreen_name("../message/error.jsp");
			details.setError_message1("Contct Administrator error :-"+e.getMessage());	
			CustomMethods.logError(e);	
		}
		session.setAttribute("ScreenDetails", details);
		return "common/templatecontent";
	}

	@RequestMapping(value = "/add_message", method = RequestMethod.GET)
	public String add_message(HttpSession session, HttpServletRequest request) {
		UserDetails user = (UserDetails) session.getAttribute("User_Login");
		System.out.println("user" + user);
		if (user == null)
			return "redirect:/login";

		Cookie[] cookies = request.getCookies();
		if (!CustomMethods.iscookiesandsessionisvalid(user, cookies)) {
			return "redirect:/login";
		}

		List<String> permission = (ArrayList<String>) session.getAttribute("user_permission");
		if (!permission.contains("messages"))
			return "common/login";

		session.removeAttribute("ScreenDetails");

		ScreenDetails details = new ScreenDetails();
		details.setScreen_title("Add Cases");
		try {
			details.setScreen_name("../message/add_message.jsp");
			details.setMain_menu("Case Management");
			details.setSub_menu1("Create Case");
			details.setSub_menu2("Manage Cases");
			details.setSub_menu2_path("../message/pending_message.jsp");
			session.setAttribute("userRole", userDao.getUserRole_lists(user.getAccount_type(), "Approved"));
			session.setAttribute("natureOfInvestigation_list",
					natureOfInvestigationDaoImpl.getActiveNatureOfInvestigationList());
			session.setAttribute("investigationList", investigationTypeDao.getActiveInvestigationType());
			session.setAttribute("ActiveTriggerNameList", triggerDao.getActiveTriggerNameList());
			session.setAttribute("ActiveTriggerDepartmentList", triggerDao.getActiveTriggerDepartmentList());
			session.setAttribute("ActiveDispositionList", dispositionDao.getActiveDispositionList());
			session.setAttribute("location_list", locationDao.getActiveLocationList());
			
		}catch(Exception e) {
			details.setScreen_name("../message/error.jsp");
			details.setError_message1("Contct Administrator error :-"+e.getMessage());	
			CustomMethods.logError(e);
		}
		session.setAttribute("ScreenDetails", details);

		return "common/templatecontent";
	}

	@RequestMapping(value = "/pending_message", method = RequestMethod.GET)
	public String pending_message(Model model,HttpSession session, HttpServletRequest request) {
		UserDetails user = (UserDetails) session.getAttribute("User_Login");
		if (user == null)
			return "redirect:/login";

		Cookie[] cookies = request.getCookies();
		if (!CustomMethods.iscookiesandsessionisvalid(user, cookies)) {
			return "redirect:/login";
		}

		List<String> permission = (ArrayList<String>) session.getAttribute("user_permission");
		if (!permission.contains("messages"))
			return "common/login";
		session.removeAttribute("ScreenDetails");
		ScreenDetails details = new ScreenDetails();
		details.setScreen_title("Pending Cases Lists");

		try {
			if(user.getAccount_type().equalsIgnoreCase(config.getSUPERVISOR())) {
			details.setScreen_name("../message/pending_messageagnsup.jsp");}
			else {
				details.setScreen_name("../message/pending_message.jsp");}
			
			
//			details.setScreen_name("../message/pending_messagetemplate.jsp");
			
			//details.setScreen_name("../message/datatable.jsp");

			details.setMain_menu("Case Management");
			details.setSub_menu1("Pending Cases");
			if (session.getAttribute("success_message") != null) {
				details.setSuccess_message1((String) session.getAttribute("success_message"));
				session.removeAttribute("success_message");
			}

			Location location = locationDao.getActiveLocationList(user.getCity());

			//		CaseDetailList =caseDao.getPendingCaseList(user.getAccount_type(), location.getZone(), user.getUsername());
			//session.setAttribute("pendingCaseList",CaseDetailList);
//			CaseDetailList1 =caserepo.getCaselists();
			
			Pageable Page=	PageRequest.of(0, 25);
			
		Page<Case_lists>  case1 = caserepo.getCaselistsAdmin(Page);
//			pagingdata data1 = new pagingdata ();
			CaseDetailList1 =case1.getContent();

//			 model.addAttribute("messages",CaseDetailList1);
			model.addAttribute("edit", request.getContextPath()+"/message/edit?caseId=");
			model.addAttribute("case_history", request.getContextPath()+"/message/case_history?caseId=");
			model.addAttribute("currentPage", case1.getNumber());
			model.addAttribute("totalPages", case1.getTotalPages());
			//System.err.println("CaseDetailList1"+CaseDetailList1.indexOf(1));
			session.setAttribute("natureOfInvestigation_list",natureOfInvestigationDaoImpl.getActiveNatureOfInvestigationList());
			session.setAttribute("investigationList", investigationTypeDao.getActiveInvestigationType());
			session.setAttribute("ActiveTriggerNameList", triggerDao.getActiveTriggerNameList());
			session.setAttribute("ActiveTriggerDepartmentList", triggerDao.getActiveTriggerDepartmentList());
			session.setAttribute("ActiveDispositionList", dispositionDao.getActiveDispositionList());
			new Exception("dynamic");
		}
		catch(Exception e) {
			details.setScreen_name("../message/error.jsp");
			details.setError_message1("Contct Administrator error :-"+e.getMessage());	
			CustomMethods.logError(e);
		}
		session.setAttribute("ScreenDetails", details);
		return "common/templatecontent";
	}
//
	
	  @RequestMapping(value = "/getPedingData", method = RequestMethod.POST)
		public @ResponseBody Data getPedingData(HttpServletRequest request, HttpSession session) {
			
			  UserDetails user = (UserDetails) session.getAttribute("User_Login");
			  Location location = locationDao.getActiveLocationList(user.getCity());
			 
			List<Case_lists>  case1 =null;
			if (user.getAccount_type().equalsIgnoreCase(config.getADMIN())) {
				System.err.println("inside ADMIN");
		    case1 = caserepo.getCaselistsAdmin();
		}
			else if (user.getAccount_type().equalsIgnoreCase(config.getREGIONAL_MANAGER())) {
				System.err.println("inside REGIONAL_MANAGER");
				System.err.println("user.getUsername(), user.getAccount_type(), location.getZone()"+user.getUsername()+" "+user.getAccount_type()+" "+ location.getZone());
			   case1 = caserepo.getCaselistsRM(user.getUsername(), user.getAccount_type(), location.getZone());
				//case1 = caserepo.getCaselistsRM(user.getUsername(),location.getZone());
			}
			else {
				System.err.println("inside user");
				 case1 = caserepo.getCaselists(user.getUsername());
			}
			Data data1 = new Data ();
			data1.setData(case1);
			//UserDetails user = (UserDetails) session.getAttribute("User_Login");
			//Location location = locationDao.getActiveLocationList(user.getCity());
			 return data1;
			 

		}

	  @RequestMapping(value = "/getPedingData1", method = RequestMethod.POST)
		public @ResponseBody Page<Case_lists> getPedingDatapagination(@RequestBody LoginRequest  pagenumber,HttpSession session
				) {
			
			/*
			 * UserDetails user = (UserDetails) session.getAttribute("User_Login"); Location
			 * location = locationDao.getActiveLocationList(user.getCity());
			 */
				System.err.println("inside ADMIN");
				int pagen = pagenumber.getPagenumber();
				Pageable Page=	PageRequest.of(pagen, 25);
				
				Page<Case_lists>  case1 = caserepo.getCaselistsAdmin(Page);
			  Data data1 = new Data ();
			
			 return case1;
		}
		
		 @RequestMapping(value = "/getPedingData2", method = RequestMethod.POST)
			public @ResponseBody pagingdata getPedingDatapaginat(Model model,HttpServletRequest request, HttpSession session) {
				
				
			  	  UserDetails user = (UserDetails) session.getAttribute("User_Login"); Location
				  location = locationDao.getActiveLocationList(user.getCity());
				 
			          String pagenu =request.getParameter("cuurentpageno");
					System.err.println("inside ADMIN"+pagenu);
					Pageable Page;
					if(pagenu!=null) {
					int pagen = Integer.parseInt(pagenu)+1;
					
					 Page=	PageRequest.of(pagen, 25);
					}
					else {
					Page =PageRequest.of(0, 25);}		
					Page<Case_lists>  case1 = PaginationService.getCaselist(Page,request,user);
//					Page<Case_lists>  case1 = caserepo.getCaselistsAdmin(Page);
					pagingdata data1 = new pagingdata ();
					data1.setData(case1.getContent());
					data1.setPage(case1.getNumber());
					data1.setTotalpagespage(case1.getTotalPages());				
				 return data1;
			}
 
		  @RequestMapping(value = "/getPedingDataN", method = RequestMethod.POST)
			public @ResponseBody pagingdata getPedingDatapaginatNext(Model model,HttpServletRequest request, HttpSession session) {
				
				
			  	  UserDetails user = (UserDetails) session.getAttribute("User_Login"); Location
				  location = locationDao.getActiveLocationList(user.getCity());
				 
			          String pagenu =request.getParameter("cuurentpageno");
					System.err.println("inside ADMIN"+pagenu);
					Pageable Page;
					if(pagenu!=null) {
					int pagen = Integer.parseInt(pagenu)+1;
					
					 Page=	PageRequest.of(pagen, 25);
					}
					else {
					Page =PageRequest.of(0, 25);}
					Page<Case_lists>  case1 = PaginationService.getCaselist(Page,request,user);
					pagingdata data1 = new pagingdata ();
					data1.setData(case1.getContent());
					data1.setPage(case1.getNumber());
					data1.setTotalpagespage(case1.getTotalPages());				
				 return data1;
			}
	  
		  
		  @RequestMapping(value = "/getPedingDatap", method = RequestMethod.POST)
			public @ResponseBody pagingdata getPedingDatapaginatPre(Model model,HttpServletRequest request, HttpSession session) {
				
				
			  	  UserDetails user = (UserDetails) session.getAttribute("User_Login"); 
			  	  Location location = locationDao.getActiveLocationList(user.getCity());
				 
			          String pagenu =request.getParameter("cuurentpageno");
					System.err.println("inside ADMIN"+pagenu);
					Pageable Page;
					if(pagenu!=null) {
					int pagen = Integer.parseInt(pagenu)-1;
					
					 Page=	PageRequest.of(pagen, 25);
					}
					else {
					Page =PageRequest.of(0, 25);}
					Page<Case_lists>  case1 = PaginationService.getCaselist(Page,request,user);
					pagingdata data1 = new pagingdata ();
					data1.setData(case1.getContent());
					data1.setPage(case1.getNumber());
					data1.setTotalpagespage(case1.getTotalPages());				
				 return data1;
			}
	  
	  
	@RequestMapping(value = "/active_message", method = RequestMethod.GET)
	public String active_message(HttpSession session, HttpServletRequest request) {
		UserDetails user = (UserDetails) session.getAttribute("User_Login");
		if (user == null)
			return "redirect:/login";

		Cookie[] cookies = request.getCookies();
		if (!CustomMethods.iscookiesandsessionisvalid(user, cookies)) {
			return "redirect:/login";
		}

		List<String> permission = (ArrayList<String>) session.getAttribute("user_permission");
		if (!permission.contains("messages"))
			return "common/login";
		session.removeAttribute("ScreenDetails");

		ScreenDetails details = new ScreenDetails();
		details.setScreen_title("Active Cases Lists");
		try {		
			details.setScreen_name("../message/active_message.jsp");

			details.setMain_menu("Case Management");
			details.setSub_menu1("Case Lists");
			session.setAttribute("assignCaseList", caseDao.getAssignedCaseList(user.getAccount_type(), user.getUsername()));
			session.setAttribute("natureOfInvestigation_list",
					natureOfInvestigationDaoImpl.getActiveNatureOfInvestigationList());
			session.setAttribute("investigationList", investigationTypeDao.getActiveInvestigationType());
		}catch(Exception e) {
			details.setScreen_name("../message/error.jsp");
			details.setError_message1("Contct Administrator error :-"+e.getMessage());	
			CustomMethods.logError(e);
		}
		session.setAttribute("ScreenDetails", details);

		return "common/templatecontent";
	}

	@RequestMapping(value = "/importData", method = RequestMethod.POST)
	public @ResponseBody String importData(@RequestParam("userfile") ArrayList<MultipartFile> userfile,
			HttpSession session, HttpServletRequest request) {
		UserDetails user = (UserDetails) session.getAttribute("User_Login");
		String role = request.getParameter("roleName");
		String assigneeId = request.getParameter("assigneeId");
		String message = "";
		// File Uploading Routine
		if (userfile != null) {
			try {
				byte[] temp = userfile.get(0).getBytes();
				String filename = userfile.get(0).getOriginalFilename();
				filename = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH-mm-SS")) + "_"
						+ filename;
				Path path = Paths.get(config.getUpload_directory() + filename);
				Files.write(path, temp);

				message = caseDao.addBulkUpload(filename, user, role, assigneeId);
				if (message.equals("****")) {
					userDao.activity_log("RCUTEAM", "Excel", "BULKUPLOAD", user.getUsername());
					session.setAttribute("success_message", "File Uploaded successfully");
					try {
						MailConfig mail = mailConfigDao.getActiveConfig();
						if (mail != null) {
							// From ID
							mail.setSubject("Case Assigned - Claims");
							String message_body = "Dear <User>, \n Case has been assigned successfully\n\n";
							message_body = message_body.replaceAll("<User>", user.getFull_name());
							message_body += "Thanks & Regards,\n Claims";
							mail.setMessageBody(message_body);
							mail.setReceipent(user.getUser_email());
//							mailConfigDao.sendMail(mail);
						}
					} catch (Exception e) {
						CustomMethods.logError(e);
					}
				} else
					return message;
			} catch (Exception e) {
				e.printStackTrace();
				CustomMethods.logError(e);
				return e.getMessage();
			}
		}
		return message;
	}

	@RequestMapping(value = "/addMessage", method = RequestMethod.POST)
	public @ResponseBody String addMessage(HttpSession session, HttpServletRequest request) {
		UserDetails user = (UserDetails) session.getAttribute("User_Login");

		if (user == null)
			return "redirect:/login";

		Cookie[] cookies = request.getCookies();
		if (!CustomMethods.iscookiesandsessionisvalid(user, cookies)) {
			return "redirect:/login";
		}
		//		List<String> permission = (ArrayList<String>) session.getAttribute("user_permission");
		//		
		//		if (!permission.contains("messages"))
		//			return "common/login";

		// Numeric Field Validation
		try {
			if (!request.getParameter("pincode").equals(""))
				Integer.parseInt(request.getParameter("pincode"));
		} catch (Exception e) {
			return "Invalid Pincode format. Pincode should be of 6 digits";
		}
		try {
			Double.parseDouble(request.getParameter("sumAssured"));
		} catch (Exception e) {
			return "Invalid Sum Assured";
		}
		try {
			if (!request.getParameter("nomineeMob").equals(""))
				Long.parseLong(request.getParameter("nomineeMob"));
		} catch (Exception e) {
			return "Invalid Mob Number format. Mob no should be of 10 digits";
		}
		CaseDetails caseDetail = new CaseDetails();
		// Add Details
		if (CustomMethods.isStringContainsSpecialCharacter(request.getParameter("policyNumber")))
			return "policyNumber Remove Special charchters "+CustomMethods.sepcical_char+"";
		caseDetail.setPolicyNumber(request.getParameter("policyNumber"));
		if (CustomMethods.isStringContainsSpecialCharacter(request.getParameter("msgCategory")))
			return "msgCategory Remove Special charchters  "+CustomMethods.sepcical_char+"";
		caseDetail.setNatureOfInvestigationId(Integer.parseInt(request.getParameter("msgCategory")));
		if (CustomMethods.isStringContainsSpecialCharacter(request.getParameter("insuredName")))
			return "insuredName Remove Special charchters  "+CustomMethods.sepcical_char+"";
		caseDetail.setInsuredName(request.getParameter("insuredName"));
		if (CustomMethods.isStringContainsSpecialCharacter(request.getParameter("insuredMob")))
			return "insuredMob Remove Special charchters "+CustomMethods.sepcical_char+"";
		caseDetail.setInsuredMob(request.getParameter("insuredMob"));
		caseDetail.setInsuredDOD(request.getParameter("insuredDOD"));
		caseDetail.setInsuredDOB(request.getParameter("insuredDOB"));
		if (CustomMethods.isStringContainsSpecialCharacter(request.getParameter("sumAssured")))
			return "sumAssured Remove Special charchters "+CustomMethods.sepcical_char+"";
		caseDetail.setSumAssured(Double.parseDouble(request.getParameter("sumAssured")));

		caseDetail.setInvestigationType(request.getParameter("msgInvestigationType"));
		caseDetail.setTriggerName(request.getParameter("triggerName"));
		caseDetail.setTrigger_dept(request.getParameter("triggerDepartment"));
		if (CustomMethods.isStringContainsSpecialCharacter(request.getParameter("insuredDODIA")))
			return "insuredDODIA Remove Special charchters "+CustomMethods.sepcical_char+"";
		caseDetail.setDateOfDiagnosis(request.getParameter("insuredDODIA"));
		if (CustomMethods.isStringContainsSpecialCharacter(request.getParameter("dispositionName")))
			return "dispositionName Remove Special charchters "+CustomMethods.sepcical_char+"";
		caseDetail.setDisposition(request.getParameter("dispositionName"));
		caseDetail.setLocationId(Integer.parseInt(request.getParameter("claimantCity")));

		if (CustomMethods.isStringContainsSpecialCharacter(request.getParameter("nomineeName")))
			return "nomineeName Remove Special charchters "+CustomMethods.sepcical_char+"";
		caseDetail.setNominee_name(request.getParameter("nomineeName"));
		if (CustomMethods.isStringContainsSpecialCharacter(request.getParameter("nomineeMob")))
			return "nomineeMob Remove Special charchters "+CustomMethods.sepcical_char+"";
		caseDetail.setNomineeContactNumber(request.getParameter("nomineeMob"));
		if (CustomMethods.isStringContainsSpecialCharacter(request.getParameter("nomineeAdd")))
			return "nomineeAdd Remove Special charchters "+CustomMethods.sepcical_char+"";
		caseDetail.setNominee_address(request.getParameter("nomineeAdd"));
		if (CustomMethods.isStringContainsSpecialCharacter(request.getParameter("insuredAdd")))
			return "insuredAdd Remove Special charchters "+CustomMethods.sepcical_char+"";
		caseDetail.setInsured_address(request.getParameter("insuredAdd"));
		if (CustomMethods.isStringContainsSpecialCharacter(request.getParameter("pincode")))
			return "pincode Remove Special charchters "+CustomMethods.sepcical_char+"";
		caseDetail.setPincode(request.getParameter("pincode"));
		caseDetail.setCreatedBy(user.getUsername());
		if (CustomMethods.isStringContainsSpecialCharacter(request.getParameter("pincode")))
			return "pincode Remove Special charchters "+CustomMethods.sepcical_char+"";
		caseDetail.setIssuedDate(request.getParameter("issuedDate"));
		if (CustomMethods.isStringContainsSpecialCharacter(request.getParameter("gender")))
			return "gender Remove Special charchters "+CustomMethods.sepcical_char+"";
		caseDetail.setGender(request.getParameter("gender"));
		if (CustomMethods.isStringContainsSpecialCharacter(request.getParameter("assigneeId")))
			return "assigneeId Remove Special charchters "+CustomMethods.sepcical_char+"";
		String assigneeId = request.getParameter("assigneeId");
		if (CustomMethods.isStringContainsSpecialCharacter(request.getParameter("toRemarks")))
			return "toRemarks Remove Special charchters "+CustomMethods.sepcical_char+"";
		String toRemarks = request.getParameter("toRemarks");

		if (CustomMethods.isStringContainsSpecialCharacter(request.getParameter("claimantZone")))
			return "claimantZone Remove Special charchters "+CustomMethods.sepcical_char+"";
		if (CustomMethods.isStringContainsSpecialCharacter(request.getParameter("roleName")))
			return "roleName Remove Special charchters "+CustomMethods.sepcical_char+"";
		if (CustomMethods.isStringContainsSpecialCharacter(request.getParameter("assigneeId")))
			return "assigneeId Remove Special charchters "+CustomMethods.sepcical_char+"";
		else {
			// Get Case Status
			CaseSubStatus status = caseDao.getCaseStatus(user.getAccount_type(), request.getParameter("roleName"),
					"Approved");
			if (status.getId() == 0)
				return "Case status & sub-Status not configured. Kindly contact system administrator";

			caseDetail.setCaseStatus(status.getCase_status());
			caseDetail.setCaseSubStatus(status.getCaseSubStatus());
			System.out.println(caseDetail.toString());
			long caseId = caseDao.addcase(caseDetail);
			String zone = request.getParameter("claimantZone");

			String DONESTAUTS = "";
			String name = "";

			if (caseId == 0)
				return "Error adding case";
			else if (caseId == -1) {

				CaseHistory history = caseMovementDao.getauditCaseMovement(caseDetail);
				//			  if(history!=null)
				name = history.getCaseId() != 0 ? "and assigned to " + history.getFromUserName() : ".";

				return "Case is already in WIP " + name;
			} else if (caseId == -2) {

				CaseHistory historydate = caseMovementDao.getauditCaseMovementdate(caseDetail);
				DONESTAUTS = historydate.getCaseId() != 0
						? "" + historydate.getCreatedDate() + " done on" + historydate.getUpdatedDate()
						+ " name of investigator was " + historydate.getFromUserName()
						+ " case need second investigation select the investigation type as Re-Investigation"
						: "";

				return DONESTAUTS;
			} else if (caseId == -3) {

				CaseHistory historydate = caseMovementDao.getauditCaseMovementdate(caseDetail);
				DONESTAUTS = historydate.getCaseId() != 0
						? "" + historydate.getCreatedDate() + " done on" + historydate.getUpdatedDate()
						+ " name of investigator was " + historydate.getFromUserName()
						+ " case need second investigation select the investigation type as Re-Investigation"
						: "";

				return DONESTAUTS;
			}
			// Case Movement & Audit Case Movement
			CaseMovement caseMovement = new CaseMovement();
			caseMovement.setCaseId(caseId);
			caseMovement.setFromId(caseDetail.getCreatedBy());
			caseMovement.setZone(zone);
			caseMovement.setToRole(request.getParameter("roleName"));
			caseMovement.setToId(request.getParameter("assigneeId"));
			caseMovement.setRemarks(toRemarks);
			String message = caseMovementDao.CreatecaseMovement(caseMovement);
			if (message.equals("****")) {
				userDao.activity_log("CASE HISTORY", caseDetail.getPolicyNumber(), "ADD CASE", user.getUsername());
				try {
					MailConfig mail = mailConfigDao.getActiveConfig();
					if (mail != null) {
						// From ID
						mail.setSubject("Case Assigned - Claims");
						String message_body = "Dear <User>, \n Case has been assigned successfully\n\n";
						message_body = message_body.replaceAll("<User>", user.getFull_name());
						message_body += "Thanks & Regards,\n Claims";
						mail.setMessageBody(message_body);
						mail.setReceipent(user.getUser_email());
						//					mailConfigDao.sendMail(mail);

						mail.setSubject("New Case Assigned - Claims");
						message_body = "Dear <User>, \n Your are required to take action on new cases\n\n";
						// To ID
						if (!(assigneeId.equals("") || assigneeId == null)) {
							UserDetails toUserRole = userDao.getUserDetails(assigneeId);
							if ((toUserRole.getAccount_type().equals(config.getSUPERVISOR())
									|| toUserRole.getAccount_type().equals(config.getINVESTIGATOR()))
									&& user.getAccount_type().equals(config.getCLAIMS())) {
								message_body = message_body.replace("<User>", toUserRole.getFull_name());
								message_body += "Thanks & Regards,\n Claims";
								mail.setMessageBody(message_body);
								mail.setReceipent(toUserRole.getUser_email());

								String AppointmentPath = config.getTemplate_directory() + "Appointment Letter.docx";
								String AuthorizationPath = config.getTemplate_directory() + "Authorization Letter.docx";
								CaseDetails casdetail = caseDao.getCaseDetail(caseId);
								mailConfigDao.textReplaceForAppointment(AppointmentPath, casdetail, toUserRole);
								mailConfigDao.textReplaceForAuthorization(AuthorizationPath, casdetail, toUserRole);

								mail.setAppointmentPath(
										config.getUpload_directory() + caseId + "_Appointment Letter.docx");
								mail.setAuthorizationPath(
										config.getUpload_directory() + caseId + "_Authorization Letter.docx");
								mailConfigDao.sendMail(mail);
							}
						} else {
							List<UserDetails> toUser = userDao.getUserRoleList(zone);
							for (UserDetails toMailId : toUser) {
								message_body = message_body.replace("<User>", toMailId.getFull_name());
								message_body += "Thanks & Regards,\n Claims";
								mail.setMessageBody(message_body);
								mail.setReceipent(toMailId.getUser_email());
								mailConfigDao.sendMail(mail);
							}
						}
					}
				} catch (Exception e) {
					e.printStackTrace();
					CustomMethods.logError(e);
				}
			}
			return message;
		}
	}

	@RequestMapping(value = "/deleteMessage", method = RequestMethod.POST)
	public @ResponseBody String deleteMessage(HttpServletRequest request, HttpSession session) {
		UserDetails user = (UserDetails) session.getAttribute("User_Login");
		int caseId = Integer.parseInt(request.getParameter("msgId"));
		String message ="";
		try {

			message = caseDao.deleteCase(caseId);
			if (message.equals("****")) {
				session.setAttribute("success_message", "Case deleted successfully");
				userDao.activity_log("CASE HISTORY", String.valueOf(caseId), "DELETE CASE", user.getUsername());
			}
		}catch(Exception e) {
			CustomMethods.logError(e);
		}
		return message;
	}

	@RequestMapping(value = "/edit", method = RequestMethod.GET)
	public String edit(HttpSession session, HttpServletRequest request) {
		UserDetails user = (UserDetails) session.getAttribute("User_Login");
		if (user == null)
			return "redirect:/login";

		Cookie[] cookies = request.getCookies();
		if (!CustomMethods.iscookiesandsessionisvalid(user, cookies)) {
			return "redirect:/login";
		}

		List<String> permission = (ArrayList<String>) session.getAttribute("user_permission");
		if (!permission.contains("messages"))
			return "common/login";
		session.removeAttribute("ScreenDetails");
		ScreenDetails details = new ScreenDetails();
		details.setScreen_title("Edit Case");
		try {
			details.setScreen_name("../message/edit_message.jsp");

			details.setMain_menu("Case Management");
			details.setSub_menu1("Create Case");
			details.setSub_menu2("Manage Cases");
			details.setSub_menu2_path("../message/pending_message.jsp");
			session.setAttribute("location_list", locationDao.getActiveLocationList());
			session.setAttribute("userRole", userDao.getUserRole_lists(user.getAccount_type(), "Approved"));
			session.setAttribute("natureOfInvestigation_list",natureOfInvestigationDaoImpl.getActiveNatureOfInvestigationList());
			session.setAttribute("investigationList", investigationTypeDao.getActiveInvestigationType());
			session.setAttribute("case_detail", caseDao.getCaseDetail(Integer.parseInt(request.getParameter("caseId"))));
			session.setAttribute("caseDocsDao",caseDocsDao.getdoclist(Integer.parseInt(request.getParameter("caseId")), user));
			session.setAttribute("case_docs",
					caseDocsDao.getCaseDocsById(Integer.parseInt(request.getParameter("caseId"))));
			session.setAttribute("case_status", caseStatusDao.getCaseStatusByRole(user.getAccount_type()));
			session.setAttribute("ActiveTriggerNameList", triggerDao.getActiveTriggerNameList());
			session.setAttribute("ActiveTriggerDepartmentList", triggerDao.getActiveTriggerDepartmentList());
			session.setAttribute("ActiveDispositionList", dispositionDao.getActiveDispositionList());


		}catch(Exception e) {
			details.setScreen_name("../message/error.jsp");
			details.setError_message1("Contct Administrator error :-"+e.getMessage());	
			CustomMethods.logError(e);
		}
		session.setAttribute("ScreenDetails", details);

		return "common/templatecontent";
	}

	@RequestMapping(value = "/updateMessageDetails", method = RequestMethod.POST)
	public @ResponseBody String updateMessageDetails(HttpSession session, HttpServletRequest request,
			@RequestParam(name = "pdf1FilePath", required = false) ArrayList<MultipartFile> pdf1) throws FileNotFoundException, IOException {
		UserDetails user = (UserDetails) session.getAttribute("User_Login");
		if (user == null)
			return "redirect:/login";

		Cookie[] cookies = request.getCookies();
		if (!CustomMethods.iscookiesandsessionisvalid(user, cookies)) {
			return "redirect:/login";
		}

		/*
		 * List<String> permission = (ArrayList<String>)
		 * session.getAttribute("user_permission"); if
		 * (!permission.contains("messages")) return "common/login";
		 */

		// Numeric Field Validation
		try {
			if (!request.getParameter("pincode").equals(""))
				Integer.parseInt(request.getParameter("pincode"));
		} catch (Exception e) {
			return "Invalid Pincode format. Pincode should be of 6 digits";
		}
		try {
			Double.parseDouble(request.getParameter("sumAssured"));
		} catch (Exception e) {
			return "Invalid Sum Assured";
		}
		try {
			if (!request.getParameter("nomineeMob").equals(""))
				Long.parseLong(request.getParameter("nomineeMob"));
		} catch (Exception e) {
			return "Invalid Mob Number format. Mob no should be of 10 digits";
		}
		CaseDetails caseDetail = new CaseDetails();
		if (CustomMethods.isStringContainsSpecialCharacter(request.getParameter("policyNumber")))
			return "policyNumber Remove Special charchters "+CustomMethods.sepcical_char+"";
		caseDetail.setPolicyNumber(request.getParameter("policyNumber"));
		if (CustomMethods.isStringContainsSpecialCharacter(request.getParameter("msgCategory")))
			return "msgCategory Remove Special charchters "+CustomMethods.sepcical_char+"";
		caseDetail.setNatureOfInvestigationId(Integer.parseInt(request.getParameter("msgCategory")));

		caseDetail.setIssuedDate(request.getParameter("issuedDate"));
		caseDetail.setInsuredMob(request.getParameter("insuredMob"));
		if (CustomMethods.isStringContainsSpecialCharacter(request.getParameter("insuredName")))
			return "insuredName Remove Special charchters "+CustomMethods.sepcical_char+"";
		caseDetail.setInsuredName(request.getParameter("insuredName"));
		caseDetail.setInsuredDOD(request.getParameter("insuredDOD"));
		caseDetail.setDateOfDiagnosis(request.getParameter("DiagnosisDate"));
		if (CustomMethods.isStringContainsSpecialCharacter(request.getParameter("gender")))
			return "gender Remove Special charchters "+CustomMethods.sepcical_char+"";
		caseDetail.setGender(request.getParameter("gender"));
		caseDetail.setInsuredDOB(request.getParameter("insuredDOB"));
		if (CustomMethods.isStringContainsSpecialCharacter(request.getParameter("sumAssured")))
			return "sumAssured Remove Special charchters "+CustomMethods.sepcical_char+"";
		caseDetail.setSumAssured(Double.parseDouble(request.getParameter("sumAssured")));
		caseDetail.setInvestigationType(request.getParameter("msgInvestigationType"));
		caseDetail.setLocationId(Integer.parseInt(request.getParameter("locationId")));
		if (CustomMethods.isStringContainsSpecialCharacter(request.getParameter("nomineeName")))
			return "nomineeName Remove Special charchters "+CustomMethods.sepcical_char+"";
		caseDetail.setNominee_name(request.getParameter("nomineeName"));
		if (CustomMethods.isStringContainsSpecialCharacter(request.getParameter("pincode")))
			return "pincode Remove Special charchters "+CustomMethods.sepcical_char+"";
		caseDetail.setPincode(request.getParameter("pincode"));
		if (CustomMethods.isStringContainsSpecialCharacter(request.getParameter("nomineeMob")))
			return "nomineeMob Remove Special charchters "+CustomMethods.sepcical_char+"";
		caseDetail.setNomineeContactNumber(request.getParameter("nomineeMob"));
		if (CustomMethods.isStringContainsSpecialCharacter(request.getParameter("nomineeAdd")))
			return "nomineeAdd Remove Special charchters "+CustomMethods.sepcical_char+"";
		caseDetail.setNominee_address(request.getParameter("nomineeAdd"));
		if (CustomMethods.isStringContainsSpecialCharacter(request.getParameter("insuredAdd")))
			return "insuredAdd Remove Special charchters "+CustomMethods.sepcical_char+"";
		caseDetail.setInsured_address(request.getParameter("insuredAdd"));
		caseDetail.setUpdatedBy(user.getUsername());
		if (CustomMethods.isStringContainsSpecialCharacter(request.getParameter("caseId")))
			return "caseId Remove Special charchters "+CustomMethods.sepcical_char+"";
		caseDetail.setCaseId(Long.parseLong(request.getParameter("caseId")));
		if (CustomMethods.isStringContainsSpecialCharacter(request.getParameter("triggerName")))
			return "triggerName Remove Special charchters "+CustomMethods.sepcical_char+"";
		caseDetail.setTriggerName(request.getParameter("triggerName"));
		if (CustomMethods.isStringContainsSpecialCharacter(request.getParameter("triggerDept")))
			return "triggerDept Remove Special charchters "+CustomMethods.sepcical_char+"";
		caseDetail.setTrigger_dept(request.getParameter("triggerDept"));
		if (CustomMethods.isStringContainsSpecialCharacter(request.getParameter("disposition")))
			return "disposition Remove Special charchters "+CustomMethods.sepcical_char+"";
		caseDetail.setDisposition(request.getParameter("disposition"));
		if (CustomMethods.isStringContainsSpecialCharacter(request.getParameter("toRole")))
			return "toRole Remove Special charchters "+CustomMethods.sepcical_char+"";
		if (CustomMethods.isStringContainsSpecialCharacter(request.getParameter("toId")))
			return "toId Remove Special charchters "+CustomMethods.sepcical_char+"";
		if (CustomMethods.isStringContainsSpecialCharacter(request.getParameter("toStatus")))
			return "toStatus Remove Special charchters "+CustomMethods.sepcical_char+"";
		// Commenting this part as recived mail on 31/03/2022 7:42 PM from Divya Iyer

		if (CustomMethods.isStringContainsSpecialCharacter(request.getParameter("toRemarks")))
			return "toRemarks Remove Special charchters "+CustomMethods.sepcical_char+"";

		if (CustomMethods.isStringContainsSpecialCharacter(request.getParameter("caseSubstatus")))
			return "caseSubstatus Remove Special charchters "+CustomMethods.sepcical_char+"";
		if (CustomMethods.isStringContainsSpecialCharacter(request.getParameter("NotCleanCategory")))
			return "NotCleanCategory Remove Special charchters "+CustomMethods.sepcical_char+"";
		else {
			String toRole = request.getParameter("toRole");
			String toId = request.getParameter("toId");
			String fromId = user.getUsername();
			String toStatus = request.getParameter("toStatus");
			String toRemarks = request.getParameter("toRemarks");
			String caseSubStatus = request.getParameter("caseSubstatus");
			String NotCleanCategory = request.getParameter("NotCleanCategory");
			UserDetails userdat = dao.checkUser(toId);

			caseDetail.setTriggerName(request.getParameter("triggerName"));
			caseDetail.setTrigger_dept(request.getParameter("triggerDept"));

			// Get Case Status
			CaseSubStatus status = new CaseSubStatus();
			// Approved
			// 3 places these logic needs to be changed - Update, Assign & Bulk Assign
			if (toStatus.equals("Approved")) {
				if (userdat.getAccount_type().equals("AGNSUP") && user.getAccount_type().equals("REGMAN")) {
					System.out.println("enter1");
					caseDao.deletepiv(caseDetail, userdat, user);
				}
				if (userdat.getAccount_type().equals("REGMAN") && user.getAccount_type().equals("AGNSUP")) {
					System.out.println("HtmlToPdfGenration");

					String error_message = pdf.HtmlToPdfGenration(caseDetail,user);
							
					if (!error_message.equals("****"))
						return error_message;
				}
				if (userdat.getAccount_type().equals("INV") && user.getAccount_type().equals("AGNSUP")) {
					System.out.println("enter2");
					caseDao.deletepiv(caseDetail, userdat, user);
				}
				if (caseSubStatus.equals("")) {
					status = caseDao.getCaseStatus(user.getAccount_type(), toRole, toStatus);
					if (status.getId() == 0)
						return "Case status & sub-Status not configured. Kindly contact system administrator";
					caseDetail.setCaseStatus(status.getCase_status());
					caseDetail.setCaseSubStatus(status.getCaseSubStatus());
				}
				// Not Clean Category
				else {
					caseDetail.setCaseStatus("Open");
					caseDetail.setCaseSubStatus(caseSubStatus);
					caseDetail.setNotCleanCategory(NotCleanCategory);
				}
			}
			// Reopen
			else if (toStatus.equals("Reopen")) {
				caseDetail.setCaseStatus("Reopen");
				caseDetail.setCaseSubStatus("Further Requirement");
			}
			// Closed
			else if (toStatus.equals("Closed")) {
				caseDetail.setNotCleanCategory(NotCleanCategory);
				caseDetail.setCaseStatus(toStatus);
				caseDetail.setCaseSubStatus(caseSubStatus);
				toRole = "";
				toId = "";
			}

			String update = caseDao.updateCaseDetails(caseDetail);
			if (!update.equals("****"))
				return update;

			// File Upload
			if (pdf1 != null) {
				try {
					for (MultipartFile uploadFile : pdf1) {
						String filename = caseDetail.getCaseId() + "_" + uploadFile.getOriginalFilename();
						Files.write(Paths.get(config.getUpload_directory() + filename), uploadFile.getBytes());
						String error_message = caseDao.updateCandidateDoc(caseDetail.getCaseId(), filename, "pdf",
								user.getUsername());
						if (!error_message.equals("****"))
							return error_message;
						userDao.activity_log("case_docs", String.valueOf(caseDetail.getCaseId()), "ADD",
								user.getUsername());
					}

				} catch (Exception e) {
					e.printStackTrace();
					CustomMethods.logError(e);
					return e.getMessage();
				}
			}

			long caseId = caseDetail.getCaseId();
			CaseMovement case_movement = new CaseMovement(caseId, fromId, toId, toStatus, toRemarks, toRole);
			String message = caseMovementDao.updateCaseMovement(case_movement);
			if (message.equals("****")) {
				session.setAttribute("success_message", "Case Details updated successfully");
				userDao.activity_log("CASE HISTORY", caseDetail.getPolicyNumber(), "EDIT CASE", user.getUsername());
				try {
					MailConfig mail = mailConfigDao.getActiveConfig();
					if (mail != null) {
						// From ID
						mail.setSubject("Case Assigned - Claims");
						String message_body = "Dear <User>, \n Case has been assigned successfully\n\n";
						message_body = message_body.replaceAll("<User>", user.getFull_name());
						message_body += "Thanks & Regards,\n Claims";
						mail.setMessageBody(message_body);
						mail.setReceipent(user.getUser_email());
						mailConfigDao.sendMail(mail);

						// To ID
						// To ID is blank for Regional Manager and whenever case gets closed
						if (toId.length() > 0) {
							UserDetails toUser = userDao.getUserDetails(toId);
							mail.setSubject("New Case Assigned - Claims");
							message_body = "Dear <User>, \n Your are required to take action on new cases\n\n";
							message_body = message_body.replace("<User>", toUser.getFull_name());
							message_body += "Thanks & Regards,\n Claims";
							mail.setMessageBody(message_body);
							mail.setReceipent(toUser.getUser_email());

							if (toStatus.equals("Approved") && (toRole.equals(config.getSUPERVISOR())
									|| toRole.equals(config.getINVESTIGATOR()))) {
								String AppointmentPath = config.getTemplate_directory() + "Appointment Letter.docx";
								String AuthorizationPath = config.getTemplate_directory() + "Authorization Letter.docx";
								CaseDetails casdetail = caseDao.getCaseDetail(caseId);
								if (toRole.equals(config.getSUPERVISOR())) {
									mailConfigDao.textReplaceForAppointment(AppointmentPath, casdetail, toUser);
									mailConfigDao.textReplaceForAuthorization(AuthorizationPath, casdetail, toUser);
								}

								String filename = config.getUpload_directory() + caseId + "_Appointment Letter.docx";
								File investigationLetter = new File(filename);
								if (investigationLetter.isFile())
									mail.setAppointmentPath(filename);

								filename = config.getUpload_directory() + caseId + "_Authorization Letter.docx";
								investigationLetter = new File(filename);
								if (investigationLetter.isFile())
									mail.setAuthorizationPath(filename);
							}

							mailConfigDao.sendMail(mail);
						}
					}
				} catch (Exception e) {
					e.printStackTrace();
					CustomMethods.logError(e);
				}
			}
			return message;
		}
	}

	@RequestMapping(value = "/assignCase", method = RequestMethod.POST)
	public @ResponseBody String assignCase(HttpServletRequest request, HttpSession session,
			@RequestParam(name = "pdf1FilePath", required = false) ArrayList<MultipartFile> pdf1) {
		UserDetails user = (UserDetails) session.getAttribute("User_Login");
		CaseDetails caseDetail = new CaseDetails();
		if (CustomMethods.isStringContainsSpecialCharacter(request.getParameter("toRemarks")))
			return "toRemarks Remove Special charchters "+CustomMethods.sepcical_char+"";
		else {
			long caseId = Integer.parseInt(request.getParameter("caseId"));

			if (pdf1 != null) {
				try {
					for (MultipartFile uploadFile : pdf1) {
						String filename = caseId + "_" + uploadFile.getOriginalFilename();
						Files.write(Paths.get(config.getUpload_directory() + filename), uploadFile.getBytes());
						String error_message = caseDao.updateCandidateDoc(caseId, filename, "pdf", user.getCreatedBy());
						if (!error_message.equals("****"))
							return error_message;
						userDao.activity_log("case_docs", String.valueOf(caseDetail.getCaseId()), "ADD",
								user.getUsername());
					}
				} catch (Exception e) {
					e.printStackTrace();
					CustomMethods.logError(e);
					return e.getMessage();
				}
			}

			String toRole = request.getParameter("toRole");
			String toId = request.getParameter("toId");
			String fromId = user.getUsername();
			String toStatus = request.getParameter("toStatus");
			String caseSubStatus = request.getParameter("caseSubStatus");
			String NotCleanCategory = request.getParameter("NotCleanCategory");
			caseDetail.setCaseId(caseId);
			CaseSubStatus status = new CaseSubStatus();

			// Approved
			// 3 places these logic needs to be changed - Update, Assign & Bulk Assign
			if (toStatus.equals("Approved")) {

				if (caseSubStatus.equals("")) {
					status = caseDao.getCaseStatus(user.getAccount_type(), toRole, toStatus);

					if (status == null)
						status = new CaseSubStatus();
					caseDetail.setCaseStatus(status.getCase_status());
					caseDetail.setCaseSubStatus(status.getCaseSubStatus());
				} else {
					caseDetail.setCaseStatus("Open");
					caseDetail.setCaseSubStatus(caseSubStatus);
					caseDetail.setNotCleanCategory(NotCleanCategory);
				}
			}
			else if (toStatus.equals("Reopen")) {
				caseDetail.setCaseStatus("Reopen");
				// Reopen
				caseDetail.setCaseSubStatus("Further Requirement");
			}
			// Closed
			else if (toStatus.equals("Closed")) {
				caseDetail.setNotCleanCategory(NotCleanCategory);
				caseDetail.setCaseStatus(toStatus);
				caseDetail.setCaseSubStatus(caseSubStatus);
				toRole = "";
				toId = "";
			}
			caseDetail.setUpdatedBy(fromId);
			caseDao.updateCaseTypeAndSubType(caseDetail);
			String toRemarks = request.getParameter("toRemarks");
			CaseMovement case_movement = new CaseMovement(caseId, fromId, toId, toStatus, toRemarks, toRole);
			String message = caseMovementDao.updateCaseMovement(case_movement);
			if (message.equals("****")) {
				session.setAttribute("success_message", "Case assigned successfully");
				userDao.activity_log("CASE HISTORY", "", "ASSIGN CASE", user.getUsername());
				try {
					MailConfig mail = mailConfigDao.getActiveConfig();
					if (mail != null) {
						// From ID
						mail.setSubject("Case Assigned - Claims");
						String message_body = "Dear <User>, \n Case has been assigned successfully\n\n";
						message_body = message_body.replaceAll("<User>", user.getFull_name());
						message_body += "Thanks & Regards,\n Claims";
						mail.setMessageBody(message_body);
						mail.setReceipent(user.getUser_email());
						mailConfigDao.sendMail(mail);

						// To ID
						// To ID is blank for Regional Manager and whenever case gets closed
						if (toId.length() > 0) {
							UserDetails toUser = userDao.getUserDetails(toId);
							mail.setSubject("New Case Assigned - Claims");
							message_body = "Dear <User>, \n Your are required to take action on new cases\n\n";
							message_body = message_body.replace("<User>", toUser.getFull_name());
							message_body += "Thanks & Regards,\n Claims";
							mail.setMessageBody(message_body);
							mail.setReceipent(toUser.getUser_email());
							if (toStatus.equals("Approved") && (toRole.equals(config.getSUPERVISOR())
									|| toRole.equals(config.getINVESTIGATOR()))) {
								
								String AppointmentPath = "C:\\Pre-Claim Investigation\\uploads\\template\\Appointment Letter.docx";
								String AuthorizationPath = "C:\\Pre-Claim Investigation\\uploads\\template\\Authorization Letter.docx";
								
								CaseDetails casdetail = caseDao.getCaseDetail(caseId);
								if (toRole.equals(config.getSUPERVISOR())) {
									mailConfigDao.textReplaceForAppointment(AppointmentPath, casdetail, toUser);
									mailConfigDao.textReplaceForAuthorization(AuthorizationPath, casdetail, toUser);
								}

								String filename = config.getUpload_directory() + caseId + "_Appointment Letter.docx";
								File investigationLetter = new File(filename);
								if (investigationLetter.isFile())
									mail.setAppointmentPath(filename);

								filename = config.getUpload_directory() + caseId + "_Authorization Letter.docx";
								investigationLetter = new File(filename);
								if (investigationLetter.isFile())
									mail.setAuthorizationPath(
											config.getUpload_directory() + caseId + "_Authorization Letter.docx");

							}
							mailConfigDao.sendMail(mail);
						}
					}
				} catch (Exception e) {
					e.printStackTrace();
					CustomMethods.logError(e);
				}
			}
			return message;
		}
	}

	@RequestMapping(value = "/bulkAssign", method = RequestMethod.POST)
	public @ResponseBody String bulkAssign(HttpServletRequest request, HttpSession session) {
		UserDetails user = (UserDetails) session.getAttribute("User_Login");
		CaseDetails caseDetail = new CaseDetails();
		if (CustomMethods.isStringContainsSpecialCharacter(request.getParameter("toRemarks")))
			return "toRemarks Remove Special charchters "+CustomMethods.sepcical_char+"";
		else {
			long caseId = 0L;
			String selectedValues = "";
			String tempStr[] = request.getParameterValues("caseId[]");
			for (String values : tempStr)
				selectedValues += values + ",";
			selectedValues = selectedValues.substring(0, selectedValues.length() - 1);

			String toRole = request.getParameter("toRole");
			String toId = request.getParameter("toId");
			String fromId = user.getUsername();
			String toStatus = request.getParameter("toStatus");
			String caseSubStatus = request.getParameter("caseSubStatus");
			String NotCleanCategory = request.getParameter("NotCleanCategory");
			
			/* caseDetail.setCaseId(caseId); */
			CaseSubStatus status = new CaseSubStatus();
			UserDetails userdat = dao.checkUser(toId);
			// Approved
			
			String message = BulkCaseService.BulkDataShedulerInsert(user,userdat,request);
	
			if (message.equals("****")) {
				session.setAttribute("success_message", "Cases added To the queue successfully");
				userDao.activity_log("CASE HISTORY", "", "ASSIGN CASE", user.getUsername());
			}
//			if (toStatus.equals("Approved")) {
//
//				if (userdat.getAccount_type().equals("AGNSUP") && user.getAccount_type().equals("REGMAN")) {
//					System.out.println("enter1");
//					caseDao.deletepiv(caseDetail, userdat, user);
//				}
//				if (caseSubStatus.equals("")) {
//					status = caseDao.getCaseStatus(user.getAccount_type(), toRole, toStatus);
//
//					if (status == null)
//						status = new CaseSubStatus();
//					caseDetail.setCaseStatus(status.getCase_status());
//					caseDetail.setCaseSubStatus(status.getCaseSubStatus());
//				} else {
//					caseDetail.setCaseStatus("Open");
//					caseDetail.setCaseSubStatus(caseSubStatus);
//					caseDetail.setNotCleanCategory(NotCleanCategory);
//				}
//			}
//			// Reopen
//			else if (toStatus.equals("Reopen")) {
//				caseDetail.setCaseStatus("Reopen");
//				caseDetail.setCaseSubStatus("Further Requirement");
//			}
//			// Closed
//			else if (toStatus.equals("Closed")) {
//				caseDetail.setNotCleanCategory(NotCleanCategory);
//				caseDetail.setCaseStatus(toStatus);
//				caseDetail.setCaseSubStatus(caseSubStatus);
//				toRole = "";
//				toId = "";
//			}
//			caseDetail.setUpdatedBy(fromId);
//			caseDao.bulkUpdateCaseTypeAndSubType(caseDetail, selectedValues);
//			String toRemarks = request.getParameter("toRemarks");
//			CaseMovement case_movement = new CaseMovement(caseId, fromId, toId, toStatus, toRemarks, toRole);
//			String message = caseMovementDao.BulkupdateCaseMovement(case_movement, selectedValues);
//			if (message.equals("****")) {
//				session.setAttribute("success_message", "Case assigned successfully");
//				userDao.activity_log("CASE HISTORY", "", "ASSIGN CASE", user.getUsername());
//				try {
//					MailConfig mail = mailConfigDao.getActiveConfig();
//					if (mail != null) {
//						for (String values : tempStr) {
//							// From ID
//							mail.setSubject("Bulk Case Assigned - Claims");
//							String message_body = "Dear <User>, \n Bulk Case has been assigned successfully\n\n";
//							message_body = message_body.replaceAll("<User>", user.getFull_name());
//							message_body += "Thanks & Regards,\n Claims";
//							mail.setMessageBody(message_body);
//							mail.setReceipent(user.getUser_email());
//							mailConfigDao.sendMail(mail);
//
//							// To ID
//							if (toId.length() > 0) {
//								UserDetails toUser = userDao.getUserDetails(toId);
//								mail.setSubject("New Bulk Case Assigned - Claims");
//								message_body = "Dear <User>, \n Your are required to take action on new cases\n\n";
//								message_body = message_body.replace("<User>", toUser.getFull_name());
//								message_body += "Thanks & Regards,\n Claims";
//								mail.setMessageBody(message_body);
//								mail.setReceipent(toUser.getUser_email());
//								if (toStatus.equals("Approved") && (toRole.equals(config.getSUPERVISOR())|| toRole.equals(config.getINVESTIGATOR()))) {
//									String AppointmentPath = config.getTemplate_directory() + "Appointment Letter.docx";
//									String AuthorizationPath = config.getTemplate_directory()
//											+ "Authorization Letter.docx";
//									CaseDetails casdetail = caseDao.getCaseDetail(Long.parseLong(values));
//
//									if (toRole.equals(config.getSUPERVISOR())) {
//										mailConfigDao.textReplaceForAppointment(AppointmentPath, casdetail, toUser);
//										mailConfigDao.textReplaceForAuthorization(AuthorizationPath, casdetail, toUser);
//									}
//
//									String filename = config.getUpload_directory() + values
//											+ "_Appointment Letter.docx";
//									File investigationLetter = new File(filename);
//									if (investigationLetter.isFile())
//										mail.setAppointmentPath(filename);
//
//									filename = config.getUpload_directory() + values + "_Authorization Letter.docx";
//									investigationLetter = new File(filename);
//									if (investigationLetter.isFile())
//										mail.setAuthorizationPath(filename);
//
//								}
//
//								mailConfigDao.sendMail(mail);
//							}
//						}
//					}
//				} catch (Exception e) {
//					e.printStackTrace();
//					CustomMethods.logError(e);
//				}
//			}
			return message;
		}
	}

	@RequestMapping(value = "/downloadErrorReport", method = RequestMethod.GET)
	public void downloadErrorReport(HttpServletRequest request, HttpServletResponse response) {
		ServletContext context = request.getSession().getServletContext();
		String filename = config.getUpload_directory() + "error_log.xlsx";
		File downloadFile = new File(filename);
		if (!(downloadFile.isFile() && downloadFile.exists()))
			return;
		try {
			FileInputStream inputStream = new FileInputStream(downloadFile);

			response.setContentType(context.getMimeType(filename));
			response.setContentLength((int) downloadFile.length());
			response.setHeader("Content-disposition",
					String.format("attachment; filename=\"%s\"", downloadFile.getName()));
			OutputStream outStream = response.getOutputStream();

			byte[] buffer = new byte[4096];
			int bytesRead = -1;

			// write bytes read from the input stream into the output stream
			while ((bytesRead = inputStream.read(buffer)) != -1) {
				outStream.write(buffer, 0, bytesRead);
			}

			inputStream.close();
			outStream.close();
		} catch (Exception e) {
			CustomMethods.logError(e);
			return;
		}
	}

	@RequestMapping(value = "/getUserByRole", method = RequestMethod.POST)
	public @ResponseBody List<UserDetails> getUserByRole(HttpServletRequest request, HttpSession session) {
		String role_code = request.getParameter("role_code");
		try {
		userDao.getUserRole(role_code);

		String fromId = "";
		String status = "";
		String caseid = "";
		String Accounttype = "";

		fromId = request.getParameter("fromId");
		status = request.getParameter("status");
		caseid = request.getParameter("caseid");
		Accounttype = request.getParameter("Accounttype");
		if (caseid == null) {
			return userDao.getUserListByRole(role_code, fromId);
		} else {
			return userDao.getUserListByRole(role_code, fromId, status, Integer.parseInt(caseid), Accounttype);
		}
		}
		catch(Exception e) {
			CustomMethods.logError(e);	
			return null;
		}
		
	}

	@RequestMapping(value = "/case_history", method = RequestMethod.GET)
	public String timeline(HttpServletRequest request, HttpSession session) {
		UserDetails user = (UserDetails) session.getAttribute("User_Login");
		if (user == null)
			return "redirect:/login";

		Cookie[] cookies = request.getCookies();
		if (!CustomMethods.iscookiesandsessionisvalid(user, cookies)) {
			return "redirect:/login";
		}

		List<String> permission = (ArrayList<String>) session.getAttribute("user_permission");
		if (!permission.contains("messages"))
			return "common/login";



		session.removeAttribute("ScreenDetails");
		ScreenDetails details = new ScreenDetails();
		details.setScreen_title("Case History");
		try {
			long caseId = Long.parseLong(request.getParameter("caseId"));
			details.setScreen_name("../message/timeline.jsp");

			details.setMain_menu("Case Management");
			details.setSub_menu1("");
			details.setSub_menu2("");
			details.setSub_menu2_path("../message/pending_message.jsp");
			List<CaseHistory> casehistory = caseMovementDao.getCaseMovementHistory(caseId);
			CaseHistory casehistory2 = caseMovementDao.getCaseMovement(caseId);
			if (!user.getAccount_type().equals(config.getSUPERVISOR())
					&& !user.getAccount_type().equals(config.getINVESTIGATOR())
					&& !casehistory2.getCaseStatus().equals("Closed"))
				casehistory.add(casehistory2);
			//		{System.out.println("casehistory2"+casehistory2);}

			session.setAttribute("case_history", casehistory);


		}catch(Exception e) {
			details.setScreen_name("../message/error.jsp");
			details.setError_message1("Contct Administrator error :-"+e.getMessage());	
			CustomMethods.logError(e);
		}
		session.setAttribute("ScreenDetails", details);

		return "common/templatecontent";
	}

	@RequestMapping(value = "/getUserRoleBystatus", method = RequestMethod.POST)
	public @ResponseBody List<UserRole> getUserRoleBystatus(HttpServletRequest request, HttpSession session) {
		UserDetails user = (UserDetails) session.getAttribute("User_Login");
		String status = request.getParameter("status");
		return userDao.getUserRole_lists(user.getAccount_type(), status);

	}

	@RequestMapping(value = "/getCaseCategory", method = RequestMethod.POST)
	public @ResponseBody List<String> getCaseCategory(HttpServletRequest request, HttpSession session) {
		UserDetails user = (UserDetails) session.getAttribute("User_Login");
		if (user == null)
			return null;

		String case_status = request.getParameter("caseSubStatus");
		return caseCategoryDao.getCaseCategoryListByStatus(case_status);

	}
}
